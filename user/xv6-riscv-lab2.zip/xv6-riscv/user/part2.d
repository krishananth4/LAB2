user/part2.o: user/part2.c /usr/riscv64-linux-gnu/include/stdc-predef.h \
 kernel/param.h kernel/types.h kernel/stat.h user/user.h kernel/fs.h \
 kernel/fcntl.h kernel/syscall.h kernel/memlayout.h kernel/riscv.h
