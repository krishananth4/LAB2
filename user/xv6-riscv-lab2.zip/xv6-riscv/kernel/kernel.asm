
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	2d013103          	ld	sp,720(sp) # 8000a2d0 <_GLOBAL_OFFSET_TABLE_+0x8>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	04a000ef          	jal	80000060 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	stimecmp,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdad9f>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	de278793          	addi	a5,a5,-542 # 80000e62 <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    800000a2:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	715d                	addi	sp,sp,-80
    800000d2:	e486                	sd	ra,72(sp)
    800000d4:	e0a2                	sd	s0,64(sp)
    800000d6:	f84a                	sd	s2,48(sp)
    800000d8:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    800000da:	04c05263          	blez	a2,8000011e <consolewrite+0x4e>
    800000de:	fc26                	sd	s1,56(sp)
    800000e0:	f44e                	sd	s3,40(sp)
    800000e2:	f052                	sd	s4,32(sp)
    800000e4:	ec56                	sd	s5,24(sp)
    800000e6:	8a2a                	mv	s4,a0
    800000e8:	84ae                	mv	s1,a1
    800000ea:	89b2                	mv	s3,a2
    800000ec:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    800000ee:	5afd                	li	s5,-1
    800000f0:	4685                	li	a3,1
    800000f2:	8626                	mv	a2,s1
    800000f4:	85d2                	mv	a1,s4
    800000f6:	fbf40513          	addi	a0,s0,-65
    800000fa:	212020ef          	jal	8000230c <either_copyin>
    800000fe:	03550263          	beq	a0,s5,80000122 <consolewrite+0x52>
      break;
    uartputc(c);
    80000102:	fbf44503          	lbu	a0,-65(s0)
    80000106:	035000ef          	jal	8000093a <uartputc>
  for(i = 0; i < n; i++){
    8000010a:	2905                	addiw	s2,s2,1
    8000010c:	0485                	addi	s1,s1,1
    8000010e:	ff2991e3          	bne	s3,s2,800000f0 <consolewrite+0x20>
    80000112:	894e                	mv	s2,s3
    80000114:	74e2                	ld	s1,56(sp)
    80000116:	79a2                	ld	s3,40(sp)
    80000118:	7a02                	ld	s4,32(sp)
    8000011a:	6ae2                	ld	s5,24(sp)
    8000011c:	a039                	j	8000012a <consolewrite+0x5a>
    8000011e:	4901                	li	s2,0
    80000120:	a029                	j	8000012a <consolewrite+0x5a>
    80000122:	74e2                	ld	s1,56(sp)
    80000124:	79a2                	ld	s3,40(sp)
    80000126:	7a02                	ld	s4,32(sp)
    80000128:	6ae2                	ld	s5,24(sp)
  }

  return i;
}
    8000012a:	854a                	mv	a0,s2
    8000012c:	60a6                	ld	ra,72(sp)
    8000012e:	6406                	ld	s0,64(sp)
    80000130:	7942                	ld	s2,48(sp)
    80000132:	6161                	addi	sp,sp,80
    80000134:	8082                	ret

0000000080000136 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000136:	711d                	addi	sp,sp,-96
    80000138:	ec86                	sd	ra,88(sp)
    8000013a:	e8a2                	sd	s0,80(sp)
    8000013c:	e4a6                	sd	s1,72(sp)
    8000013e:	e0ca                	sd	s2,64(sp)
    80000140:	fc4e                	sd	s3,56(sp)
    80000142:	f852                	sd	s4,48(sp)
    80000144:	f456                	sd	s5,40(sp)
    80000146:	f05a                	sd	s6,32(sp)
    80000148:	1080                	addi	s0,sp,96
    8000014a:	8aaa                	mv	s5,a0
    8000014c:	8a2e                	mv	s4,a1
    8000014e:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000150:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80000154:	00012517          	auipc	a0,0x12
    80000158:	1dc50513          	addi	a0,a0,476 # 80012330 <cons>
    8000015c:	299000ef          	jal	80000bf4 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000160:	00012497          	auipc	s1,0x12
    80000164:	1d048493          	addi	s1,s1,464 # 80012330 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000168:	00012917          	auipc	s2,0x12
    8000016c:	26090913          	addi	s2,s2,608 # 800123c8 <cons+0x98>
  while(n > 0){
    80000170:	0b305d63          	blez	s3,8000022a <consoleread+0xf4>
    while(cons.r == cons.w){
    80000174:	0984a783          	lw	a5,152(s1)
    80000178:	09c4a703          	lw	a4,156(s1)
    8000017c:	0af71263          	bne	a4,a5,80000220 <consoleread+0xea>
      if(killed(myproc())){
    80000180:	760010ef          	jal	800018e0 <myproc>
    80000184:	01a020ef          	jal	8000219e <killed>
    80000188:	e12d                	bnez	a0,800001ea <consoleread+0xb4>
      sleep(&cons.r, &cons.lock);
    8000018a:	85a6                	mv	a1,s1
    8000018c:	854a                	mv	a0,s2
    8000018e:	5d9010ef          	jal	80001f66 <sleep>
    while(cons.r == cons.w){
    80000192:	0984a783          	lw	a5,152(s1)
    80000196:	09c4a703          	lw	a4,156(s1)
    8000019a:	fef703e3          	beq	a4,a5,80000180 <consoleread+0x4a>
    8000019e:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001a0:	00012717          	auipc	a4,0x12
    800001a4:	19070713          	addi	a4,a4,400 # 80012330 <cons>
    800001a8:	0017869b          	addiw	a3,a5,1
    800001ac:	08d72c23          	sw	a3,152(a4)
    800001b0:	07f7f693          	andi	a3,a5,127
    800001b4:	9736                	add	a4,a4,a3
    800001b6:	01874703          	lbu	a4,24(a4)
    800001ba:	00070b9b          	sext.w	s7,a4

    if(c == C('D')){  // end-of-file
    800001be:	4691                	li	a3,4
    800001c0:	04db8663          	beq	s7,a3,8000020c <consoleread+0xd6>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001c4:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001c8:	4685                	li	a3,1
    800001ca:	faf40613          	addi	a2,s0,-81
    800001ce:	85d2                	mv	a1,s4
    800001d0:	8556                	mv	a0,s5
    800001d2:	0f0020ef          	jal	800022c2 <either_copyout>
    800001d6:	57fd                	li	a5,-1
    800001d8:	04f50863          	beq	a0,a5,80000228 <consoleread+0xf2>
      break;

    dst++;
    800001dc:	0a05                	addi	s4,s4,1
    --n;
    800001de:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    800001e0:	47a9                	li	a5,10
    800001e2:	04fb8d63          	beq	s7,a5,8000023c <consoleread+0x106>
    800001e6:	6be2                	ld	s7,24(sp)
    800001e8:	b761                	j	80000170 <consoleread+0x3a>
        release(&cons.lock);
    800001ea:	00012517          	auipc	a0,0x12
    800001ee:	14650513          	addi	a0,a0,326 # 80012330 <cons>
    800001f2:	29b000ef          	jal	80000c8c <release>
        return -1;
    800001f6:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    800001f8:	60e6                	ld	ra,88(sp)
    800001fa:	6446                	ld	s0,80(sp)
    800001fc:	64a6                	ld	s1,72(sp)
    800001fe:	6906                	ld	s2,64(sp)
    80000200:	79e2                	ld	s3,56(sp)
    80000202:	7a42                	ld	s4,48(sp)
    80000204:	7aa2                	ld	s5,40(sp)
    80000206:	7b02                	ld	s6,32(sp)
    80000208:	6125                	addi	sp,sp,96
    8000020a:	8082                	ret
      if(n < target){
    8000020c:	0009871b          	sext.w	a4,s3
    80000210:	01677a63          	bgeu	a4,s6,80000224 <consoleread+0xee>
        cons.r--;
    80000214:	00012717          	auipc	a4,0x12
    80000218:	1af72a23          	sw	a5,436(a4) # 800123c8 <cons+0x98>
    8000021c:	6be2                	ld	s7,24(sp)
    8000021e:	a031                	j	8000022a <consoleread+0xf4>
    80000220:	ec5e                	sd	s7,24(sp)
    80000222:	bfbd                	j	800001a0 <consoleread+0x6a>
    80000224:	6be2                	ld	s7,24(sp)
    80000226:	a011                	j	8000022a <consoleread+0xf4>
    80000228:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    8000022a:	00012517          	auipc	a0,0x12
    8000022e:	10650513          	addi	a0,a0,262 # 80012330 <cons>
    80000232:	25b000ef          	jal	80000c8c <release>
  return target - n;
    80000236:	413b053b          	subw	a0,s6,s3
    8000023a:	bf7d                	j	800001f8 <consoleread+0xc2>
    8000023c:	6be2                	ld	s7,24(sp)
    8000023e:	b7f5                	j	8000022a <consoleread+0xf4>

0000000080000240 <consputc>:
{
    80000240:	1141                	addi	sp,sp,-16
    80000242:	e406                	sd	ra,8(sp)
    80000244:	e022                	sd	s0,0(sp)
    80000246:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000248:	10000793          	li	a5,256
    8000024c:	00f50863          	beq	a0,a5,8000025c <consputc+0x1c>
    uartputc_sync(c);
    80000250:	604000ef          	jal	80000854 <uartputc_sync>
}
    80000254:	60a2                	ld	ra,8(sp)
    80000256:	6402                	ld	s0,0(sp)
    80000258:	0141                	addi	sp,sp,16
    8000025a:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000025c:	4521                	li	a0,8
    8000025e:	5f6000ef          	jal	80000854 <uartputc_sync>
    80000262:	02000513          	li	a0,32
    80000266:	5ee000ef          	jal	80000854 <uartputc_sync>
    8000026a:	4521                	li	a0,8
    8000026c:	5e8000ef          	jal	80000854 <uartputc_sync>
    80000270:	b7d5                	j	80000254 <consputc+0x14>

0000000080000272 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80000272:	1101                	addi	sp,sp,-32
    80000274:	ec06                	sd	ra,24(sp)
    80000276:	e822                	sd	s0,16(sp)
    80000278:	e426                	sd	s1,8(sp)
    8000027a:	1000                	addi	s0,sp,32
    8000027c:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000027e:	00012517          	auipc	a0,0x12
    80000282:	0b250513          	addi	a0,a0,178 # 80012330 <cons>
    80000286:	16f000ef          	jal	80000bf4 <acquire>

  switch(c){
    8000028a:	47d5                	li	a5,21
    8000028c:	08f48f63          	beq	s1,a5,8000032a <consoleintr+0xb8>
    80000290:	0297c563          	blt	a5,s1,800002ba <consoleintr+0x48>
    80000294:	47a1                	li	a5,8
    80000296:	0ef48463          	beq	s1,a5,8000037e <consoleintr+0x10c>
    8000029a:	47c1                	li	a5,16
    8000029c:	10f49563          	bne	s1,a5,800003a6 <consoleintr+0x134>
  case C('P'):  // Print process list.
    procdump();
    800002a0:	0b6020ef          	jal	80002356 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002a4:	00012517          	auipc	a0,0x12
    800002a8:	08c50513          	addi	a0,a0,140 # 80012330 <cons>
    800002ac:	1e1000ef          	jal	80000c8c <release>
}
    800002b0:	60e2                	ld	ra,24(sp)
    800002b2:	6442                	ld	s0,16(sp)
    800002b4:	64a2                	ld	s1,8(sp)
    800002b6:	6105                	addi	sp,sp,32
    800002b8:	8082                	ret
  switch(c){
    800002ba:	07f00793          	li	a5,127
    800002be:	0cf48063          	beq	s1,a5,8000037e <consoleintr+0x10c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002c2:	00012717          	auipc	a4,0x12
    800002c6:	06e70713          	addi	a4,a4,110 # 80012330 <cons>
    800002ca:	0a072783          	lw	a5,160(a4)
    800002ce:	09872703          	lw	a4,152(a4)
    800002d2:	9f99                	subw	a5,a5,a4
    800002d4:	07f00713          	li	a4,127
    800002d8:	fcf766e3          	bltu	a4,a5,800002a4 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    800002dc:	47b5                	li	a5,13
    800002de:	0cf48763          	beq	s1,a5,800003ac <consoleintr+0x13a>
      consputc(c);
    800002e2:	8526                	mv	a0,s1
    800002e4:	f5dff0ef          	jal	80000240 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002e8:	00012797          	auipc	a5,0x12
    800002ec:	04878793          	addi	a5,a5,72 # 80012330 <cons>
    800002f0:	0a07a683          	lw	a3,160(a5)
    800002f4:	0016871b          	addiw	a4,a3,1
    800002f8:	0007061b          	sext.w	a2,a4
    800002fc:	0ae7a023          	sw	a4,160(a5)
    80000300:	07f6f693          	andi	a3,a3,127
    80000304:	97b6                	add	a5,a5,a3
    80000306:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    8000030a:	47a9                	li	a5,10
    8000030c:	0cf48563          	beq	s1,a5,800003d6 <consoleintr+0x164>
    80000310:	4791                	li	a5,4
    80000312:	0cf48263          	beq	s1,a5,800003d6 <consoleintr+0x164>
    80000316:	00012797          	auipc	a5,0x12
    8000031a:	0b27a783          	lw	a5,178(a5) # 800123c8 <cons+0x98>
    8000031e:	9f1d                	subw	a4,a4,a5
    80000320:	08000793          	li	a5,128
    80000324:	f8f710e3          	bne	a4,a5,800002a4 <consoleintr+0x32>
    80000328:	a07d                	j	800003d6 <consoleintr+0x164>
    8000032a:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    8000032c:	00012717          	auipc	a4,0x12
    80000330:	00470713          	addi	a4,a4,4 # 80012330 <cons>
    80000334:	0a072783          	lw	a5,160(a4)
    80000338:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000033c:	00012497          	auipc	s1,0x12
    80000340:	ff448493          	addi	s1,s1,-12 # 80012330 <cons>
    while(cons.e != cons.w &&
    80000344:	4929                	li	s2,10
    80000346:	02f70863          	beq	a4,a5,80000376 <consoleintr+0x104>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000034a:	37fd                	addiw	a5,a5,-1
    8000034c:	07f7f713          	andi	a4,a5,127
    80000350:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000352:	01874703          	lbu	a4,24(a4)
    80000356:	03270263          	beq	a4,s2,8000037a <consoleintr+0x108>
      cons.e--;
    8000035a:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    8000035e:	10000513          	li	a0,256
    80000362:	edfff0ef          	jal	80000240 <consputc>
    while(cons.e != cons.w &&
    80000366:	0a04a783          	lw	a5,160(s1)
    8000036a:	09c4a703          	lw	a4,156(s1)
    8000036e:	fcf71ee3          	bne	a4,a5,8000034a <consoleintr+0xd8>
    80000372:	6902                	ld	s2,0(sp)
    80000374:	bf05                	j	800002a4 <consoleintr+0x32>
    80000376:	6902                	ld	s2,0(sp)
    80000378:	b735                	j	800002a4 <consoleintr+0x32>
    8000037a:	6902                	ld	s2,0(sp)
    8000037c:	b725                	j	800002a4 <consoleintr+0x32>
    if(cons.e != cons.w){
    8000037e:	00012717          	auipc	a4,0x12
    80000382:	fb270713          	addi	a4,a4,-78 # 80012330 <cons>
    80000386:	0a072783          	lw	a5,160(a4)
    8000038a:	09c72703          	lw	a4,156(a4)
    8000038e:	f0f70be3          	beq	a4,a5,800002a4 <consoleintr+0x32>
      cons.e--;
    80000392:	37fd                	addiw	a5,a5,-1
    80000394:	00012717          	auipc	a4,0x12
    80000398:	02f72e23          	sw	a5,60(a4) # 800123d0 <cons+0xa0>
      consputc(BACKSPACE);
    8000039c:	10000513          	li	a0,256
    800003a0:	ea1ff0ef          	jal	80000240 <consputc>
    800003a4:	b701                	j	800002a4 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003a6:	ee048fe3          	beqz	s1,800002a4 <consoleintr+0x32>
    800003aa:	bf21                	j	800002c2 <consoleintr+0x50>
      consputc(c);
    800003ac:	4529                	li	a0,10
    800003ae:	e93ff0ef          	jal	80000240 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003b2:	00012797          	auipc	a5,0x12
    800003b6:	f7e78793          	addi	a5,a5,-130 # 80012330 <cons>
    800003ba:	0a07a703          	lw	a4,160(a5)
    800003be:	0017069b          	addiw	a3,a4,1
    800003c2:	0006861b          	sext.w	a2,a3
    800003c6:	0ad7a023          	sw	a3,160(a5)
    800003ca:	07f77713          	andi	a4,a4,127
    800003ce:	97ba                	add	a5,a5,a4
    800003d0:	4729                	li	a4,10
    800003d2:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003d6:	00012797          	auipc	a5,0x12
    800003da:	fec7ab23          	sw	a2,-10(a5) # 800123cc <cons+0x9c>
        wakeup(&cons.r);
    800003de:	00012517          	auipc	a0,0x12
    800003e2:	fea50513          	addi	a0,a0,-22 # 800123c8 <cons+0x98>
    800003e6:	3cd010ef          	jal	80001fb2 <wakeup>
    800003ea:	bd6d                	j	800002a4 <consoleintr+0x32>

00000000800003ec <consoleinit>:

void
consoleinit(void)
{
    800003ec:	1141                	addi	sp,sp,-16
    800003ee:	e406                	sd	ra,8(sp)
    800003f0:	e022                	sd	s0,0(sp)
    800003f2:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800003f4:	00007597          	auipc	a1,0x7
    800003f8:	c0c58593          	addi	a1,a1,-1012 # 80007000 <etext>
    800003fc:	00012517          	auipc	a0,0x12
    80000400:	f3450513          	addi	a0,a0,-204 # 80012330 <cons>
    80000404:	770000ef          	jal	80000b74 <initlock>

  uartinit();
    80000408:	3f4000ef          	jal	800007fc <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    8000040c:	00022797          	auipc	a5,0x22
    80000410:	4bc78793          	addi	a5,a5,1212 # 800228c8 <devsw>
    80000414:	00000717          	auipc	a4,0x0
    80000418:	d2270713          	addi	a4,a4,-734 # 80000136 <consoleread>
    8000041c:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000041e:	00000717          	auipc	a4,0x0
    80000422:	cb270713          	addi	a4,a4,-846 # 800000d0 <consolewrite>
    80000426:	ef98                	sd	a4,24(a5)
}
    80000428:	60a2                	ld	ra,8(sp)
    8000042a:	6402                	ld	s0,0(sp)
    8000042c:	0141                	addi	sp,sp,16
    8000042e:	8082                	ret

0000000080000430 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000430:	7179                	addi	sp,sp,-48
    80000432:	f406                	sd	ra,40(sp)
    80000434:	f022                	sd	s0,32(sp)
    80000436:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000438:	c219                	beqz	a2,8000043e <printint+0xe>
    8000043a:	08054063          	bltz	a0,800004ba <printint+0x8a>
    x = -xx;
  else
    x = xx;
    8000043e:	4881                	li	a7,0
    80000440:	fd040693          	addi	a3,s0,-48

  i = 0;
    80000444:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    80000446:	00007617          	auipc	a2,0x7
    8000044a:	34a60613          	addi	a2,a2,842 # 80007790 <digits>
    8000044e:	883e                	mv	a6,a5
    80000450:	2785                	addiw	a5,a5,1
    80000452:	02b57733          	remu	a4,a0,a1
    80000456:	9732                	add	a4,a4,a2
    80000458:	00074703          	lbu	a4,0(a4)
    8000045c:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000460:	872a                	mv	a4,a0
    80000462:	02b55533          	divu	a0,a0,a1
    80000466:	0685                	addi	a3,a3,1
    80000468:	feb773e3          	bgeu	a4,a1,8000044e <printint+0x1e>

  if(sign)
    8000046c:	00088a63          	beqz	a7,80000480 <printint+0x50>
    buf[i++] = '-';
    80000470:	1781                	addi	a5,a5,-32
    80000472:	97a2                	add	a5,a5,s0
    80000474:	02d00713          	li	a4,45
    80000478:	fee78823          	sb	a4,-16(a5)
    8000047c:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    80000480:	02f05963          	blez	a5,800004b2 <printint+0x82>
    80000484:	ec26                	sd	s1,24(sp)
    80000486:	e84a                	sd	s2,16(sp)
    80000488:	fd040713          	addi	a4,s0,-48
    8000048c:	00f704b3          	add	s1,a4,a5
    80000490:	fff70913          	addi	s2,a4,-1
    80000494:	993e                	add	s2,s2,a5
    80000496:	37fd                	addiw	a5,a5,-1
    80000498:	1782                	slli	a5,a5,0x20
    8000049a:	9381                	srli	a5,a5,0x20
    8000049c:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004a0:	fff4c503          	lbu	a0,-1(s1)
    800004a4:	d9dff0ef          	jal	80000240 <consputc>
  while(--i >= 0)
    800004a8:	14fd                	addi	s1,s1,-1
    800004aa:	ff249be3          	bne	s1,s2,800004a0 <printint+0x70>
    800004ae:	64e2                	ld	s1,24(sp)
    800004b0:	6942                	ld	s2,16(sp)
}
    800004b2:	70a2                	ld	ra,40(sp)
    800004b4:	7402                	ld	s0,32(sp)
    800004b6:	6145                	addi	sp,sp,48
    800004b8:	8082                	ret
    x = -xx;
    800004ba:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004be:	4885                	li	a7,1
    x = -xx;
    800004c0:	b741                	j	80000440 <printint+0x10>

00000000800004c2 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004c2:	7155                	addi	sp,sp,-208
    800004c4:	e506                	sd	ra,136(sp)
    800004c6:	e122                	sd	s0,128(sp)
    800004c8:	f0d2                	sd	s4,96(sp)
    800004ca:	0900                	addi	s0,sp,144
    800004cc:	8a2a                	mv	s4,a0
    800004ce:	e40c                	sd	a1,8(s0)
    800004d0:	e810                	sd	a2,16(s0)
    800004d2:	ec14                	sd	a3,24(s0)
    800004d4:	f018                	sd	a4,32(s0)
    800004d6:	f41c                	sd	a5,40(s0)
    800004d8:	03043823          	sd	a6,48(s0)
    800004dc:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800004e0:	00012797          	auipc	a5,0x12
    800004e4:	f107a783          	lw	a5,-240(a5) # 800123f0 <pr+0x18>
    800004e8:	f6f43c23          	sd	a5,-136(s0)
  if(locking)
    800004ec:	e3a1                	bnez	a5,8000052c <printf+0x6a>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800004ee:	00840793          	addi	a5,s0,8
    800004f2:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800004f6:	00054503          	lbu	a0,0(a0)
    800004fa:	26050763          	beqz	a0,80000768 <printf+0x2a6>
    800004fe:	fca6                	sd	s1,120(sp)
    80000500:	f8ca                	sd	s2,112(sp)
    80000502:	f4ce                	sd	s3,104(sp)
    80000504:	ecd6                	sd	s5,88(sp)
    80000506:	e8da                	sd	s6,80(sp)
    80000508:	e0e2                	sd	s8,64(sp)
    8000050a:	fc66                	sd	s9,56(sp)
    8000050c:	f86a                	sd	s10,48(sp)
    8000050e:	f46e                	sd	s11,40(sp)
    80000510:	4981                	li	s3,0
    if(cx != '%'){
    80000512:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    80000516:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    8000051a:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000051e:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000522:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000526:	07000d93          	li	s11,112
    8000052a:	a815                	j	8000055e <printf+0x9c>
    acquire(&pr.lock);
    8000052c:	00012517          	auipc	a0,0x12
    80000530:	eac50513          	addi	a0,a0,-340 # 800123d8 <pr>
    80000534:	6c0000ef          	jal	80000bf4 <acquire>
  va_start(ap, fmt);
    80000538:	00840793          	addi	a5,s0,8
    8000053c:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000540:	000a4503          	lbu	a0,0(s4)
    80000544:	fd4d                	bnez	a0,800004fe <printf+0x3c>
    80000546:	a481                	j	80000786 <printf+0x2c4>
      consputc(cx);
    80000548:	cf9ff0ef          	jal	80000240 <consputc>
      continue;
    8000054c:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000054e:	0014899b          	addiw	s3,s1,1
    80000552:	013a07b3          	add	a5,s4,s3
    80000556:	0007c503          	lbu	a0,0(a5)
    8000055a:	1e050b63          	beqz	a0,80000750 <printf+0x28e>
    if(cx != '%'){
    8000055e:	ff5515e3          	bne	a0,s5,80000548 <printf+0x86>
    i++;
    80000562:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    80000566:	009a07b3          	add	a5,s4,s1
    8000056a:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    8000056e:	1e090163          	beqz	s2,80000750 <printf+0x28e>
    80000572:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    80000576:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    80000578:	c789                	beqz	a5,80000582 <printf+0xc0>
    8000057a:	009a0733          	add	a4,s4,s1
    8000057e:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    80000582:	03690763          	beq	s2,s6,800005b0 <printf+0xee>
    } else if(c0 == 'l' && c1 == 'd'){
    80000586:	05890163          	beq	s2,s8,800005c8 <printf+0x106>
    } else if(c0 == 'u'){
    8000058a:	0d990b63          	beq	s2,s9,80000660 <printf+0x19e>
    } else if(c0 == 'x'){
    8000058e:	13a90163          	beq	s2,s10,800006b0 <printf+0x1ee>
    } else if(c0 == 'p'){
    80000592:	13b90b63          	beq	s2,s11,800006c8 <printf+0x206>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 's'){
    80000596:	07300793          	li	a5,115
    8000059a:	16f90a63          	beq	s2,a5,8000070e <printf+0x24c>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    8000059e:	1b590463          	beq	s2,s5,80000746 <printf+0x284>
      consputc('%');
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    800005a2:	8556                	mv	a0,s5
    800005a4:	c9dff0ef          	jal	80000240 <consputc>
      consputc(c0);
    800005a8:	854a                	mv	a0,s2
    800005aa:	c97ff0ef          	jal	80000240 <consputc>
    800005ae:	b745                	j	8000054e <printf+0x8c>
      printint(va_arg(ap, int), 10, 1);
    800005b0:	f8843783          	ld	a5,-120(s0)
    800005b4:	00878713          	addi	a4,a5,8
    800005b8:	f8e43423          	sd	a4,-120(s0)
    800005bc:	4605                	li	a2,1
    800005be:	45a9                	li	a1,10
    800005c0:	4388                	lw	a0,0(a5)
    800005c2:	e6fff0ef          	jal	80000430 <printint>
    800005c6:	b761                	j	8000054e <printf+0x8c>
    } else if(c0 == 'l' && c1 == 'd'){
    800005c8:	03678663          	beq	a5,s6,800005f4 <printf+0x132>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005cc:	05878263          	beq	a5,s8,80000610 <printf+0x14e>
    } else if(c0 == 'l' && c1 == 'u'){
    800005d0:	0b978463          	beq	a5,s9,80000678 <printf+0x1b6>
    } else if(c0 == 'l' && c1 == 'x'){
    800005d4:	fda797e3          	bne	a5,s10,800005a2 <printf+0xe0>
      printint(va_arg(ap, uint64), 16, 0);
    800005d8:	f8843783          	ld	a5,-120(s0)
    800005dc:	00878713          	addi	a4,a5,8
    800005e0:	f8e43423          	sd	a4,-120(s0)
    800005e4:	4601                	li	a2,0
    800005e6:	45c1                	li	a1,16
    800005e8:	6388                	ld	a0,0(a5)
    800005ea:	e47ff0ef          	jal	80000430 <printint>
      i += 1;
    800005ee:	0029849b          	addiw	s1,s3,2
    800005f2:	bfb1                	j	8000054e <printf+0x8c>
      printint(va_arg(ap, uint64), 10, 1);
    800005f4:	f8843783          	ld	a5,-120(s0)
    800005f8:	00878713          	addi	a4,a5,8
    800005fc:	f8e43423          	sd	a4,-120(s0)
    80000600:	4605                	li	a2,1
    80000602:	45a9                	li	a1,10
    80000604:	6388                	ld	a0,0(a5)
    80000606:	e2bff0ef          	jal	80000430 <printint>
      i += 1;
    8000060a:	0029849b          	addiw	s1,s3,2
    8000060e:	b781                	j	8000054e <printf+0x8c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80000610:	06400793          	li	a5,100
    80000614:	02f68863          	beq	a3,a5,80000644 <printf+0x182>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000618:	07500793          	li	a5,117
    8000061c:	06f68c63          	beq	a3,a5,80000694 <printf+0x1d2>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    80000620:	07800793          	li	a5,120
    80000624:	f6f69fe3          	bne	a3,a5,800005a2 <printf+0xe0>
      printint(va_arg(ap, uint64), 16, 0);
    80000628:	f8843783          	ld	a5,-120(s0)
    8000062c:	00878713          	addi	a4,a5,8
    80000630:	f8e43423          	sd	a4,-120(s0)
    80000634:	4601                	li	a2,0
    80000636:	45c1                	li	a1,16
    80000638:	6388                	ld	a0,0(a5)
    8000063a:	df7ff0ef          	jal	80000430 <printint>
      i += 2;
    8000063e:	0039849b          	addiw	s1,s3,3
    80000642:	b731                	j	8000054e <printf+0x8c>
      printint(va_arg(ap, uint64), 10, 1);
    80000644:	f8843783          	ld	a5,-120(s0)
    80000648:	00878713          	addi	a4,a5,8
    8000064c:	f8e43423          	sd	a4,-120(s0)
    80000650:	4605                	li	a2,1
    80000652:	45a9                	li	a1,10
    80000654:	6388                	ld	a0,0(a5)
    80000656:	ddbff0ef          	jal	80000430 <printint>
      i += 2;
    8000065a:	0039849b          	addiw	s1,s3,3
    8000065e:	bdc5                	j	8000054e <printf+0x8c>
      printint(va_arg(ap, int), 10, 0);
    80000660:	f8843783          	ld	a5,-120(s0)
    80000664:	00878713          	addi	a4,a5,8
    80000668:	f8e43423          	sd	a4,-120(s0)
    8000066c:	4601                	li	a2,0
    8000066e:	45a9                	li	a1,10
    80000670:	4388                	lw	a0,0(a5)
    80000672:	dbfff0ef          	jal	80000430 <printint>
    80000676:	bde1                	j	8000054e <printf+0x8c>
      printint(va_arg(ap, uint64), 10, 0);
    80000678:	f8843783          	ld	a5,-120(s0)
    8000067c:	00878713          	addi	a4,a5,8
    80000680:	f8e43423          	sd	a4,-120(s0)
    80000684:	4601                	li	a2,0
    80000686:	45a9                	li	a1,10
    80000688:	6388                	ld	a0,0(a5)
    8000068a:	da7ff0ef          	jal	80000430 <printint>
      i += 1;
    8000068e:	0029849b          	addiw	s1,s3,2
    80000692:	bd75                	j	8000054e <printf+0x8c>
      printint(va_arg(ap, uint64), 10, 0);
    80000694:	f8843783          	ld	a5,-120(s0)
    80000698:	00878713          	addi	a4,a5,8
    8000069c:	f8e43423          	sd	a4,-120(s0)
    800006a0:	4601                	li	a2,0
    800006a2:	45a9                	li	a1,10
    800006a4:	6388                	ld	a0,0(a5)
    800006a6:	d8bff0ef          	jal	80000430 <printint>
      i += 2;
    800006aa:	0039849b          	addiw	s1,s3,3
    800006ae:	b545                	j	8000054e <printf+0x8c>
      printint(va_arg(ap, int), 16, 0);
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	4601                	li	a2,0
    800006be:	45c1                	li	a1,16
    800006c0:	4388                	lw	a0,0(a5)
    800006c2:	d6fff0ef          	jal	80000430 <printint>
    800006c6:	b561                	j	8000054e <printf+0x8c>
    800006c8:	e4de                	sd	s7,72(sp)
      printptr(va_arg(ap, uint64));
    800006ca:	f8843783          	ld	a5,-120(s0)
    800006ce:	00878713          	addi	a4,a5,8
    800006d2:	f8e43423          	sd	a4,-120(s0)
    800006d6:	0007b983          	ld	s3,0(a5)
  consputc('0');
    800006da:	03000513          	li	a0,48
    800006de:	b63ff0ef          	jal	80000240 <consputc>
  consputc('x');
    800006e2:	07800513          	li	a0,120
    800006e6:	b5bff0ef          	jal	80000240 <consputc>
    800006ea:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006ec:	00007b97          	auipc	s7,0x7
    800006f0:	0a4b8b93          	addi	s7,s7,164 # 80007790 <digits>
    800006f4:	03c9d793          	srli	a5,s3,0x3c
    800006f8:	97de                	add	a5,a5,s7
    800006fa:	0007c503          	lbu	a0,0(a5)
    800006fe:	b43ff0ef          	jal	80000240 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    80000702:	0992                	slli	s3,s3,0x4
    80000704:	397d                	addiw	s2,s2,-1
    80000706:	fe0917e3          	bnez	s2,800006f4 <printf+0x232>
    8000070a:	6ba6                	ld	s7,72(sp)
    8000070c:	b589                	j	8000054e <printf+0x8c>
      if((s = va_arg(ap, char*)) == 0)
    8000070e:	f8843783          	ld	a5,-120(s0)
    80000712:	00878713          	addi	a4,a5,8
    80000716:	f8e43423          	sd	a4,-120(s0)
    8000071a:	0007b903          	ld	s2,0(a5)
    8000071e:	00090d63          	beqz	s2,80000738 <printf+0x276>
      for(; *s; s++)
    80000722:	00094503          	lbu	a0,0(s2)
    80000726:	e20504e3          	beqz	a0,8000054e <printf+0x8c>
        consputc(*s);
    8000072a:	b17ff0ef          	jal	80000240 <consputc>
      for(; *s; s++)
    8000072e:	0905                	addi	s2,s2,1
    80000730:	00094503          	lbu	a0,0(s2)
    80000734:	f97d                	bnez	a0,8000072a <printf+0x268>
    80000736:	bd21                	j	8000054e <printf+0x8c>
        s = "(null)";
    80000738:	00007917          	auipc	s2,0x7
    8000073c:	8d090913          	addi	s2,s2,-1840 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000740:	02800513          	li	a0,40
    80000744:	b7dd                	j	8000072a <printf+0x268>
      consputc('%');
    80000746:	02500513          	li	a0,37
    8000074a:	af7ff0ef          	jal	80000240 <consputc>
    8000074e:	b501                	j	8000054e <printf+0x8c>
    }
#endif
  }
  va_end(ap);

  if(locking)
    80000750:	f7843783          	ld	a5,-136(s0)
    80000754:	e385                	bnez	a5,80000774 <printf+0x2b2>
    80000756:	74e6                	ld	s1,120(sp)
    80000758:	7946                	ld	s2,112(sp)
    8000075a:	79a6                	ld	s3,104(sp)
    8000075c:	6ae6                	ld	s5,88(sp)
    8000075e:	6b46                	ld	s6,80(sp)
    80000760:	6c06                	ld	s8,64(sp)
    80000762:	7ce2                	ld	s9,56(sp)
    80000764:	7d42                	ld	s10,48(sp)
    80000766:	7da2                	ld	s11,40(sp)
    release(&pr.lock);

  return 0;
}
    80000768:	4501                	li	a0,0
    8000076a:	60aa                	ld	ra,136(sp)
    8000076c:	640a                	ld	s0,128(sp)
    8000076e:	7a06                	ld	s4,96(sp)
    80000770:	6169                	addi	sp,sp,208
    80000772:	8082                	ret
    80000774:	74e6                	ld	s1,120(sp)
    80000776:	7946                	ld	s2,112(sp)
    80000778:	79a6                	ld	s3,104(sp)
    8000077a:	6ae6                	ld	s5,88(sp)
    8000077c:	6b46                	ld	s6,80(sp)
    8000077e:	6c06                	ld	s8,64(sp)
    80000780:	7ce2                	ld	s9,56(sp)
    80000782:	7d42                	ld	s10,48(sp)
    80000784:	7da2                	ld	s11,40(sp)
    release(&pr.lock);
    80000786:	00012517          	auipc	a0,0x12
    8000078a:	c5250513          	addi	a0,a0,-942 # 800123d8 <pr>
    8000078e:	4fe000ef          	jal	80000c8c <release>
    80000792:	bfd9                	j	80000768 <printf+0x2a6>

0000000080000794 <panic>:

void
panic(char *s)
{
    80000794:	1101                	addi	sp,sp,-32
    80000796:	ec06                	sd	ra,24(sp)
    80000798:	e822                	sd	s0,16(sp)
    8000079a:	e426                	sd	s1,8(sp)
    8000079c:	1000                	addi	s0,sp,32
    8000079e:	84aa                	mv	s1,a0
  pr.locking = 0;
    800007a0:	00012797          	auipc	a5,0x12
    800007a4:	c407a823          	sw	zero,-944(a5) # 800123f0 <pr+0x18>
  printf("panic: ");
    800007a8:	00007517          	auipc	a0,0x7
    800007ac:	87050513          	addi	a0,a0,-1936 # 80007018 <etext+0x18>
    800007b0:	d13ff0ef          	jal	800004c2 <printf>
  printf("%s\n", s);
    800007b4:	85a6                	mv	a1,s1
    800007b6:	00007517          	auipc	a0,0x7
    800007ba:	86a50513          	addi	a0,a0,-1942 # 80007020 <etext+0x20>
    800007be:	d05ff0ef          	jal	800004c2 <printf>
  panicked = 1; // freeze uart output from other CPUs
    800007c2:	4785                	li	a5,1
    800007c4:	0000a717          	auipc	a4,0xa
    800007c8:	b2f72623          	sw	a5,-1236(a4) # 8000a2f0 <panicked>
  for(;;)
    800007cc:	a001                	j	800007cc <panic+0x38>

00000000800007ce <printfinit>:
    ;
}

void
printfinit(void)
{
    800007ce:	1101                	addi	sp,sp,-32
    800007d0:	ec06                	sd	ra,24(sp)
    800007d2:	e822                	sd	s0,16(sp)
    800007d4:	e426                	sd	s1,8(sp)
    800007d6:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    800007d8:	00012497          	auipc	s1,0x12
    800007dc:	c0048493          	addi	s1,s1,-1024 # 800123d8 <pr>
    800007e0:	00007597          	auipc	a1,0x7
    800007e4:	84858593          	addi	a1,a1,-1976 # 80007028 <etext+0x28>
    800007e8:	8526                	mv	a0,s1
    800007ea:	38a000ef          	jal	80000b74 <initlock>
  pr.locking = 1;
    800007ee:	4785                	li	a5,1
    800007f0:	cc9c                	sw	a5,24(s1)
}
    800007f2:	60e2                	ld	ra,24(sp)
    800007f4:	6442                	ld	s0,16(sp)
    800007f6:	64a2                	ld	s1,8(sp)
    800007f8:	6105                	addi	sp,sp,32
    800007fa:	8082                	ret

00000000800007fc <uartinit>:

void uartstart();

void
uartinit(void)
{
    800007fc:	1141                	addi	sp,sp,-16
    800007fe:	e406                	sd	ra,8(sp)
    80000800:	e022                	sd	s0,0(sp)
    80000802:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000804:	100007b7          	lui	a5,0x10000
    80000808:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    8000080c:	10000737          	lui	a4,0x10000
    80000810:	f8000693          	li	a3,-128
    80000814:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000818:	468d                	li	a3,3
    8000081a:	10000637          	lui	a2,0x10000
    8000081e:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000822:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80000826:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000082a:	10000737          	lui	a4,0x10000
    8000082e:	461d                	li	a2,7
    80000830:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000834:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80000838:	00006597          	auipc	a1,0x6
    8000083c:	7f858593          	addi	a1,a1,2040 # 80007030 <etext+0x30>
    80000840:	00012517          	auipc	a0,0x12
    80000844:	bb850513          	addi	a0,a0,-1096 # 800123f8 <uart_tx_lock>
    80000848:	32c000ef          	jal	80000b74 <initlock>
}
    8000084c:	60a2                	ld	ra,8(sp)
    8000084e:	6402                	ld	s0,0(sp)
    80000850:	0141                	addi	sp,sp,16
    80000852:	8082                	ret

0000000080000854 <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000854:	1101                	addi	sp,sp,-32
    80000856:	ec06                	sd	ra,24(sp)
    80000858:	e822                	sd	s0,16(sp)
    8000085a:	e426                	sd	s1,8(sp)
    8000085c:	1000                	addi	s0,sp,32
    8000085e:	84aa                	mv	s1,a0
  push_off();
    80000860:	354000ef          	jal	80000bb4 <push_off>

  if(panicked){
    80000864:	0000a797          	auipc	a5,0xa
    80000868:	a8c7a783          	lw	a5,-1396(a5) # 8000a2f0 <panicked>
    8000086c:	e795                	bnez	a5,80000898 <uartputc_sync+0x44>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000086e:	10000737          	lui	a4,0x10000
    80000872:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000874:	00074783          	lbu	a5,0(a4)
    80000878:	0207f793          	andi	a5,a5,32
    8000087c:	dfe5                	beqz	a5,80000874 <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    8000087e:	0ff4f513          	zext.b	a0,s1
    80000882:	100007b7          	lui	a5,0x10000
    80000886:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    8000088a:	3ae000ef          	jal	80000c38 <pop_off>
}
    8000088e:	60e2                	ld	ra,24(sp)
    80000890:	6442                	ld	s0,16(sp)
    80000892:	64a2                	ld	s1,8(sp)
    80000894:	6105                	addi	sp,sp,32
    80000896:	8082                	ret
    for(;;)
    80000898:	a001                	j	80000898 <uartputc_sync+0x44>

000000008000089a <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    8000089a:	0000a797          	auipc	a5,0xa
    8000089e:	a5e7b783          	ld	a5,-1442(a5) # 8000a2f8 <uart_tx_r>
    800008a2:	0000a717          	auipc	a4,0xa
    800008a6:	a5e73703          	ld	a4,-1442(a4) # 8000a300 <uart_tx_w>
    800008aa:	08f70263          	beq	a4,a5,8000092e <uartstart+0x94>
{
    800008ae:	7139                	addi	sp,sp,-64
    800008b0:	fc06                	sd	ra,56(sp)
    800008b2:	f822                	sd	s0,48(sp)
    800008b4:	f426                	sd	s1,40(sp)
    800008b6:	f04a                	sd	s2,32(sp)
    800008b8:	ec4e                	sd	s3,24(sp)
    800008ba:	e852                	sd	s4,16(sp)
    800008bc:	e456                	sd	s5,8(sp)
    800008be:	e05a                	sd	s6,0(sp)
    800008c0:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800008c2:	10000937          	lui	s2,0x10000
    800008c6:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800008c8:	00012a97          	auipc	s5,0x12
    800008cc:	b30a8a93          	addi	s5,s5,-1232 # 800123f8 <uart_tx_lock>
    uart_tx_r += 1;
    800008d0:	0000a497          	auipc	s1,0xa
    800008d4:	a2848493          	addi	s1,s1,-1496 # 8000a2f8 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    800008d8:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    800008dc:	0000a997          	auipc	s3,0xa
    800008e0:	a2498993          	addi	s3,s3,-1500 # 8000a300 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800008e4:	00094703          	lbu	a4,0(s2)
    800008e8:	02077713          	andi	a4,a4,32
    800008ec:	c71d                	beqz	a4,8000091a <uartstart+0x80>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800008ee:	01f7f713          	andi	a4,a5,31
    800008f2:	9756                	add	a4,a4,s5
    800008f4:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    800008f8:	0785                	addi	a5,a5,1
    800008fa:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    800008fc:	8526                	mv	a0,s1
    800008fe:	6b4010ef          	jal	80001fb2 <wakeup>
    WriteReg(THR, c);
    80000902:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    80000906:	609c                	ld	a5,0(s1)
    80000908:	0009b703          	ld	a4,0(s3)
    8000090c:	fcf71ce3          	bne	a4,a5,800008e4 <uartstart+0x4a>
      ReadReg(ISR);
    80000910:	100007b7          	lui	a5,0x10000
    80000914:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    80000916:	0007c783          	lbu	a5,0(a5)
  }
}
    8000091a:	70e2                	ld	ra,56(sp)
    8000091c:	7442                	ld	s0,48(sp)
    8000091e:	74a2                	ld	s1,40(sp)
    80000920:	7902                	ld	s2,32(sp)
    80000922:	69e2                	ld	s3,24(sp)
    80000924:	6a42                	ld	s4,16(sp)
    80000926:	6aa2                	ld	s5,8(sp)
    80000928:	6b02                	ld	s6,0(sp)
    8000092a:	6121                	addi	sp,sp,64
    8000092c:	8082                	ret
      ReadReg(ISR);
    8000092e:	100007b7          	lui	a5,0x10000
    80000932:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    80000934:	0007c783          	lbu	a5,0(a5)
      return;
    80000938:	8082                	ret

000000008000093a <uartputc>:
{
    8000093a:	7179                	addi	sp,sp,-48
    8000093c:	f406                	sd	ra,40(sp)
    8000093e:	f022                	sd	s0,32(sp)
    80000940:	ec26                	sd	s1,24(sp)
    80000942:	e84a                	sd	s2,16(sp)
    80000944:	e44e                	sd	s3,8(sp)
    80000946:	e052                	sd	s4,0(sp)
    80000948:	1800                	addi	s0,sp,48
    8000094a:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    8000094c:	00012517          	auipc	a0,0x12
    80000950:	aac50513          	addi	a0,a0,-1364 # 800123f8 <uart_tx_lock>
    80000954:	2a0000ef          	jal	80000bf4 <acquire>
  if(panicked){
    80000958:	0000a797          	auipc	a5,0xa
    8000095c:	9987a783          	lw	a5,-1640(a5) # 8000a2f0 <panicked>
    80000960:	efbd                	bnez	a5,800009de <uartputc+0xa4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000962:	0000a717          	auipc	a4,0xa
    80000966:	99e73703          	ld	a4,-1634(a4) # 8000a300 <uart_tx_w>
    8000096a:	0000a797          	auipc	a5,0xa
    8000096e:	98e7b783          	ld	a5,-1650(a5) # 8000a2f8 <uart_tx_r>
    80000972:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    80000976:	00012997          	auipc	s3,0x12
    8000097a:	a8298993          	addi	s3,s3,-1406 # 800123f8 <uart_tx_lock>
    8000097e:	0000a497          	auipc	s1,0xa
    80000982:	97a48493          	addi	s1,s1,-1670 # 8000a2f8 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000986:	0000a917          	auipc	s2,0xa
    8000098a:	97a90913          	addi	s2,s2,-1670 # 8000a300 <uart_tx_w>
    8000098e:	00e79d63          	bne	a5,a4,800009a8 <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    80000992:	85ce                	mv	a1,s3
    80000994:	8526                	mv	a0,s1
    80000996:	5d0010ef          	jal	80001f66 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000099a:	00093703          	ld	a4,0(s2)
    8000099e:	609c                	ld	a5,0(s1)
    800009a0:	02078793          	addi	a5,a5,32
    800009a4:	fee787e3          	beq	a5,a4,80000992 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800009a8:	00012497          	auipc	s1,0x12
    800009ac:	a5048493          	addi	s1,s1,-1456 # 800123f8 <uart_tx_lock>
    800009b0:	01f77793          	andi	a5,a4,31
    800009b4:	97a6                	add	a5,a5,s1
    800009b6:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800009ba:	0705                	addi	a4,a4,1
    800009bc:	0000a797          	auipc	a5,0xa
    800009c0:	94e7b223          	sd	a4,-1724(a5) # 8000a300 <uart_tx_w>
  uartstart();
    800009c4:	ed7ff0ef          	jal	8000089a <uartstart>
  release(&uart_tx_lock);
    800009c8:	8526                	mv	a0,s1
    800009ca:	2c2000ef          	jal	80000c8c <release>
}
    800009ce:	70a2                	ld	ra,40(sp)
    800009d0:	7402                	ld	s0,32(sp)
    800009d2:	64e2                	ld	s1,24(sp)
    800009d4:	6942                	ld	s2,16(sp)
    800009d6:	69a2                	ld	s3,8(sp)
    800009d8:	6a02                	ld	s4,0(sp)
    800009da:	6145                	addi	sp,sp,48
    800009dc:	8082                	ret
    for(;;)
    800009de:	a001                	j	800009de <uartputc+0xa4>

00000000800009e0 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009e0:	1141                	addi	sp,sp,-16
    800009e2:	e422                	sd	s0,8(sp)
    800009e4:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    800009e6:	100007b7          	lui	a5,0x10000
    800009ea:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009ec:	0007c783          	lbu	a5,0(a5)
    800009f0:	8b85                	andi	a5,a5,1
    800009f2:	cb81                	beqz	a5,80000a02 <uartgetc+0x22>
    // input data is ready.
    return ReadReg(RHR);
    800009f4:	100007b7          	lui	a5,0x10000
    800009f8:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009fc:	6422                	ld	s0,8(sp)
    800009fe:	0141                	addi	sp,sp,16
    80000a00:	8082                	ret
    return -1;
    80000a02:	557d                	li	a0,-1
    80000a04:	bfe5                	j	800009fc <uartgetc+0x1c>

0000000080000a06 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000a06:	1101                	addi	sp,sp,-32
    80000a08:	ec06                	sd	ra,24(sp)
    80000a0a:	e822                	sd	s0,16(sp)
    80000a0c:	e426                	sd	s1,8(sp)
    80000a0e:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a10:	54fd                	li	s1,-1
    80000a12:	a019                	j	80000a18 <uartintr+0x12>
      break;
    consoleintr(c);
    80000a14:	85fff0ef          	jal	80000272 <consoleintr>
    int c = uartgetc();
    80000a18:	fc9ff0ef          	jal	800009e0 <uartgetc>
    if(c == -1)
    80000a1c:	fe951ce3          	bne	a0,s1,80000a14 <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80000a20:	00012497          	auipc	s1,0x12
    80000a24:	9d848493          	addi	s1,s1,-1576 # 800123f8 <uart_tx_lock>
    80000a28:	8526                	mv	a0,s1
    80000a2a:	1ca000ef          	jal	80000bf4 <acquire>
  uartstart();
    80000a2e:	e6dff0ef          	jal	8000089a <uartstart>
  release(&uart_tx_lock);
    80000a32:	8526                	mv	a0,s1
    80000a34:	258000ef          	jal	80000c8c <release>
}
    80000a38:	60e2                	ld	ra,24(sp)
    80000a3a:	6442                	ld	s0,16(sp)
    80000a3c:	64a2                	ld	s1,8(sp)
    80000a3e:	6105                	addi	sp,sp,32
    80000a40:	8082                	ret

0000000080000a42 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a42:	1101                	addi	sp,sp,-32
    80000a44:	ec06                	sd	ra,24(sp)
    80000a46:	e822                	sd	s0,16(sp)
    80000a48:	e426                	sd	s1,8(sp)
    80000a4a:	e04a                	sd	s2,0(sp)
    80000a4c:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a4e:	03451793          	slli	a5,a0,0x34
    80000a52:	e7a9                	bnez	a5,80000a9c <kfree+0x5a>
    80000a54:	84aa                	mv	s1,a0
    80000a56:	00023797          	auipc	a5,0x23
    80000a5a:	00a78793          	addi	a5,a5,10 # 80023a60 <end>
    80000a5e:	02f56f63          	bltu	a0,a5,80000a9c <kfree+0x5a>
    80000a62:	47c5                	li	a5,17
    80000a64:	07ee                	slli	a5,a5,0x1b
    80000a66:	02f57b63          	bgeu	a0,a5,80000a9c <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a6a:	6605                	lui	a2,0x1
    80000a6c:	4585                	li	a1,1
    80000a6e:	25a000ef          	jal	80000cc8 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a72:	00012917          	auipc	s2,0x12
    80000a76:	9be90913          	addi	s2,s2,-1602 # 80012430 <kmem>
    80000a7a:	854a                	mv	a0,s2
    80000a7c:	178000ef          	jal	80000bf4 <acquire>
  r->next = kmem.freelist;
    80000a80:	01893783          	ld	a5,24(s2)
    80000a84:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a86:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a8a:	854a                	mv	a0,s2
    80000a8c:	200000ef          	jal	80000c8c <release>
}
    80000a90:	60e2                	ld	ra,24(sp)
    80000a92:	6442                	ld	s0,16(sp)
    80000a94:	64a2                	ld	s1,8(sp)
    80000a96:	6902                	ld	s2,0(sp)
    80000a98:	6105                	addi	sp,sp,32
    80000a9a:	8082                	ret
    panic("kfree");
    80000a9c:	00006517          	auipc	a0,0x6
    80000aa0:	59c50513          	addi	a0,a0,1436 # 80007038 <etext+0x38>
    80000aa4:	cf1ff0ef          	jal	80000794 <panic>

0000000080000aa8 <freerange>:
{
    80000aa8:	7179                	addi	sp,sp,-48
    80000aaa:	f406                	sd	ra,40(sp)
    80000aac:	f022                	sd	s0,32(sp)
    80000aae:	ec26                	sd	s1,24(sp)
    80000ab0:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000ab2:	6785                	lui	a5,0x1
    80000ab4:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ab8:	00e504b3          	add	s1,a0,a4
    80000abc:	777d                	lui	a4,0xfffff
    80000abe:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ac0:	94be                	add	s1,s1,a5
    80000ac2:	0295e263          	bltu	a1,s1,80000ae6 <freerange+0x3e>
    80000ac6:	e84a                	sd	s2,16(sp)
    80000ac8:	e44e                	sd	s3,8(sp)
    80000aca:	e052                	sd	s4,0(sp)
    80000acc:	892e                	mv	s2,a1
    kfree(p);
    80000ace:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ad0:	6985                	lui	s3,0x1
    kfree(p);
    80000ad2:	01448533          	add	a0,s1,s4
    80000ad6:	f6dff0ef          	jal	80000a42 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ada:	94ce                	add	s1,s1,s3
    80000adc:	fe997be3          	bgeu	s2,s1,80000ad2 <freerange+0x2a>
    80000ae0:	6942                	ld	s2,16(sp)
    80000ae2:	69a2                	ld	s3,8(sp)
    80000ae4:	6a02                	ld	s4,0(sp)
}
    80000ae6:	70a2                	ld	ra,40(sp)
    80000ae8:	7402                	ld	s0,32(sp)
    80000aea:	64e2                	ld	s1,24(sp)
    80000aec:	6145                	addi	sp,sp,48
    80000aee:	8082                	ret

0000000080000af0 <kinit>:
{
    80000af0:	1141                	addi	sp,sp,-16
    80000af2:	e406                	sd	ra,8(sp)
    80000af4:	e022                	sd	s0,0(sp)
    80000af6:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000af8:	00006597          	auipc	a1,0x6
    80000afc:	54858593          	addi	a1,a1,1352 # 80007040 <etext+0x40>
    80000b00:	00012517          	auipc	a0,0x12
    80000b04:	93050513          	addi	a0,a0,-1744 # 80012430 <kmem>
    80000b08:	06c000ef          	jal	80000b74 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b0c:	45c5                	li	a1,17
    80000b0e:	05ee                	slli	a1,a1,0x1b
    80000b10:	00023517          	auipc	a0,0x23
    80000b14:	f5050513          	addi	a0,a0,-176 # 80023a60 <end>
    80000b18:	f91ff0ef          	jal	80000aa8 <freerange>
}
    80000b1c:	60a2                	ld	ra,8(sp)
    80000b1e:	6402                	ld	s0,0(sp)
    80000b20:	0141                	addi	sp,sp,16
    80000b22:	8082                	ret

0000000080000b24 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b24:	1101                	addi	sp,sp,-32
    80000b26:	ec06                	sd	ra,24(sp)
    80000b28:	e822                	sd	s0,16(sp)
    80000b2a:	e426                	sd	s1,8(sp)
    80000b2c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b2e:	00012497          	auipc	s1,0x12
    80000b32:	90248493          	addi	s1,s1,-1790 # 80012430 <kmem>
    80000b36:	8526                	mv	a0,s1
    80000b38:	0bc000ef          	jal	80000bf4 <acquire>
  r = kmem.freelist;
    80000b3c:	6c84                	ld	s1,24(s1)
  if(r)
    80000b3e:	c485                	beqz	s1,80000b66 <kalloc+0x42>
    kmem.freelist = r->next;
    80000b40:	609c                	ld	a5,0(s1)
    80000b42:	00012517          	auipc	a0,0x12
    80000b46:	8ee50513          	addi	a0,a0,-1810 # 80012430 <kmem>
    80000b4a:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b4c:	140000ef          	jal	80000c8c <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b50:	6605                	lui	a2,0x1
    80000b52:	4595                	li	a1,5
    80000b54:	8526                	mv	a0,s1
    80000b56:	172000ef          	jal	80000cc8 <memset>
  return (void*)r;
}
    80000b5a:	8526                	mv	a0,s1
    80000b5c:	60e2                	ld	ra,24(sp)
    80000b5e:	6442                	ld	s0,16(sp)
    80000b60:	64a2                	ld	s1,8(sp)
    80000b62:	6105                	addi	sp,sp,32
    80000b64:	8082                	ret
  release(&kmem.lock);
    80000b66:	00012517          	auipc	a0,0x12
    80000b6a:	8ca50513          	addi	a0,a0,-1846 # 80012430 <kmem>
    80000b6e:	11e000ef          	jal	80000c8c <release>
  if(r)
    80000b72:	b7e5                	j	80000b5a <kalloc+0x36>

0000000080000b74 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b74:	1141                	addi	sp,sp,-16
    80000b76:	e422                	sd	s0,8(sp)
    80000b78:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b7a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b7c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b80:	00053823          	sd	zero,16(a0)
}
    80000b84:	6422                	ld	s0,8(sp)
    80000b86:	0141                	addi	sp,sp,16
    80000b88:	8082                	ret

0000000080000b8a <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b8a:	411c                	lw	a5,0(a0)
    80000b8c:	e399                	bnez	a5,80000b92 <holding+0x8>
    80000b8e:	4501                	li	a0,0
  return r;
}
    80000b90:	8082                	ret
{
    80000b92:	1101                	addi	sp,sp,-32
    80000b94:	ec06                	sd	ra,24(sp)
    80000b96:	e822                	sd	s0,16(sp)
    80000b98:	e426                	sd	s1,8(sp)
    80000b9a:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b9c:	6904                	ld	s1,16(a0)
    80000b9e:	527000ef          	jal	800018c4 <mycpu>
    80000ba2:	40a48533          	sub	a0,s1,a0
    80000ba6:	00153513          	seqz	a0,a0
}
    80000baa:	60e2                	ld	ra,24(sp)
    80000bac:	6442                	ld	s0,16(sp)
    80000bae:	64a2                	ld	s1,8(sp)
    80000bb0:	6105                	addi	sp,sp,32
    80000bb2:	8082                	ret

0000000080000bb4 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bb4:	1101                	addi	sp,sp,-32
    80000bb6:	ec06                	sd	ra,24(sp)
    80000bb8:	e822                	sd	s0,16(sp)
    80000bba:	e426                	sd	s1,8(sp)
    80000bbc:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bbe:	100024f3          	csrr	s1,sstatus
    80000bc2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000bc6:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000bc8:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80000bcc:	4f9000ef          	jal	800018c4 <mycpu>
    80000bd0:	5d3c                	lw	a5,120(a0)
    80000bd2:	cb99                	beqz	a5,80000be8 <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bd4:	4f1000ef          	jal	800018c4 <mycpu>
    80000bd8:	5d3c                	lw	a5,120(a0)
    80000bda:	2785                	addiw	a5,a5,1
    80000bdc:	dd3c                	sw	a5,120(a0)
}
    80000bde:	60e2                	ld	ra,24(sp)
    80000be0:	6442                	ld	s0,16(sp)
    80000be2:	64a2                	ld	s1,8(sp)
    80000be4:	6105                	addi	sp,sp,32
    80000be6:	8082                	ret
    mycpu()->intena = old;
    80000be8:	4dd000ef          	jal	800018c4 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000bec:	8085                	srli	s1,s1,0x1
    80000bee:	8885                	andi	s1,s1,1
    80000bf0:	dd64                	sw	s1,124(a0)
    80000bf2:	b7cd                	j	80000bd4 <push_off+0x20>

0000000080000bf4 <acquire>:
{
    80000bf4:	1101                	addi	sp,sp,-32
    80000bf6:	ec06                	sd	ra,24(sp)
    80000bf8:	e822                	sd	s0,16(sp)
    80000bfa:	e426                	sd	s1,8(sp)
    80000bfc:	1000                	addi	s0,sp,32
    80000bfe:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c00:	fb5ff0ef          	jal	80000bb4 <push_off>
  if(holding(lk))
    80000c04:	8526                	mv	a0,s1
    80000c06:	f85ff0ef          	jal	80000b8a <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c0a:	4705                	li	a4,1
  if(holding(lk))
    80000c0c:	e105                	bnez	a0,80000c2c <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c0e:	87ba                	mv	a5,a4
    80000c10:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c14:	2781                	sext.w	a5,a5
    80000c16:	ffe5                	bnez	a5,80000c0e <acquire+0x1a>
  __sync_synchronize();
    80000c18:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c1c:	4a9000ef          	jal	800018c4 <mycpu>
    80000c20:	e888                	sd	a0,16(s1)
}
    80000c22:	60e2                	ld	ra,24(sp)
    80000c24:	6442                	ld	s0,16(sp)
    80000c26:	64a2                	ld	s1,8(sp)
    80000c28:	6105                	addi	sp,sp,32
    80000c2a:	8082                	ret
    panic("acquire");
    80000c2c:	00006517          	auipc	a0,0x6
    80000c30:	41c50513          	addi	a0,a0,1052 # 80007048 <etext+0x48>
    80000c34:	b61ff0ef          	jal	80000794 <panic>

0000000080000c38 <pop_off>:

void
pop_off(void)
{
    80000c38:	1141                	addi	sp,sp,-16
    80000c3a:	e406                	sd	ra,8(sp)
    80000c3c:	e022                	sd	s0,0(sp)
    80000c3e:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c40:	485000ef          	jal	800018c4 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c44:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c48:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c4a:	e78d                	bnez	a5,80000c74 <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c4c:	5d3c                	lw	a5,120(a0)
    80000c4e:	02f05963          	blez	a5,80000c80 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000c52:	37fd                	addiw	a5,a5,-1
    80000c54:	0007871b          	sext.w	a4,a5
    80000c58:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c5a:	eb09                	bnez	a4,80000c6c <pop_off+0x34>
    80000c5c:	5d7c                	lw	a5,124(a0)
    80000c5e:	c799                	beqz	a5,80000c6c <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c60:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c64:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c68:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c6c:	60a2                	ld	ra,8(sp)
    80000c6e:	6402                	ld	s0,0(sp)
    80000c70:	0141                	addi	sp,sp,16
    80000c72:	8082                	ret
    panic("pop_off - interruptible");
    80000c74:	00006517          	auipc	a0,0x6
    80000c78:	3dc50513          	addi	a0,a0,988 # 80007050 <etext+0x50>
    80000c7c:	b19ff0ef          	jal	80000794 <panic>
    panic("pop_off");
    80000c80:	00006517          	auipc	a0,0x6
    80000c84:	3e850513          	addi	a0,a0,1000 # 80007068 <etext+0x68>
    80000c88:	b0dff0ef          	jal	80000794 <panic>

0000000080000c8c <release>:
{
    80000c8c:	1101                	addi	sp,sp,-32
    80000c8e:	ec06                	sd	ra,24(sp)
    80000c90:	e822                	sd	s0,16(sp)
    80000c92:	e426                	sd	s1,8(sp)
    80000c94:	1000                	addi	s0,sp,32
    80000c96:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c98:	ef3ff0ef          	jal	80000b8a <holding>
    80000c9c:	c105                	beqz	a0,80000cbc <release+0x30>
  lk->cpu = 0;
    80000c9e:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000ca2:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000ca6:	0310000f          	fence	rw,w
    80000caa:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000cae:	f8bff0ef          	jal	80000c38 <pop_off>
}
    80000cb2:	60e2                	ld	ra,24(sp)
    80000cb4:	6442                	ld	s0,16(sp)
    80000cb6:	64a2                	ld	s1,8(sp)
    80000cb8:	6105                	addi	sp,sp,32
    80000cba:	8082                	ret
    panic("release");
    80000cbc:	00006517          	auipc	a0,0x6
    80000cc0:	3b450513          	addi	a0,a0,948 # 80007070 <etext+0x70>
    80000cc4:	ad1ff0ef          	jal	80000794 <panic>

0000000080000cc8 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cc8:	1141                	addi	sp,sp,-16
    80000cca:	e422                	sd	s0,8(sp)
    80000ccc:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000cce:	ca19                	beqz	a2,80000ce4 <memset+0x1c>
    80000cd0:	87aa                	mv	a5,a0
    80000cd2:	1602                	slli	a2,a2,0x20
    80000cd4:	9201                	srli	a2,a2,0x20
    80000cd6:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cda:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000cde:	0785                	addi	a5,a5,1
    80000ce0:	fee79de3          	bne	a5,a4,80000cda <memset+0x12>
  }
  return dst;
}
    80000ce4:	6422                	ld	s0,8(sp)
    80000ce6:	0141                	addi	sp,sp,16
    80000ce8:	8082                	ret

0000000080000cea <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cea:	1141                	addi	sp,sp,-16
    80000cec:	e422                	sd	s0,8(sp)
    80000cee:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cf0:	ca05                	beqz	a2,80000d20 <memcmp+0x36>
    80000cf2:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000cf6:	1682                	slli	a3,a3,0x20
    80000cf8:	9281                	srli	a3,a3,0x20
    80000cfa:	0685                	addi	a3,a3,1
    80000cfc:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000cfe:	00054783          	lbu	a5,0(a0)
    80000d02:	0005c703          	lbu	a4,0(a1)
    80000d06:	00e79863          	bne	a5,a4,80000d16 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d0a:	0505                	addi	a0,a0,1
    80000d0c:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d0e:	fed518e3          	bne	a0,a3,80000cfe <memcmp+0x14>
  }

  return 0;
    80000d12:	4501                	li	a0,0
    80000d14:	a019                	j	80000d1a <memcmp+0x30>
      return *s1 - *s2;
    80000d16:	40e7853b          	subw	a0,a5,a4
}
    80000d1a:	6422                	ld	s0,8(sp)
    80000d1c:	0141                	addi	sp,sp,16
    80000d1e:	8082                	ret
  return 0;
    80000d20:	4501                	li	a0,0
    80000d22:	bfe5                	j	80000d1a <memcmp+0x30>

0000000080000d24 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d24:	1141                	addi	sp,sp,-16
    80000d26:	e422                	sd	s0,8(sp)
    80000d28:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d2a:	c205                	beqz	a2,80000d4a <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d2c:	02a5e263          	bltu	a1,a0,80000d50 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d30:	1602                	slli	a2,a2,0x20
    80000d32:	9201                	srli	a2,a2,0x20
    80000d34:	00c587b3          	add	a5,a1,a2
{
    80000d38:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d3a:	0585                	addi	a1,a1,1
    80000d3c:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdb5a1>
    80000d3e:	fff5c683          	lbu	a3,-1(a1)
    80000d42:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d46:	feb79ae3          	bne	a5,a1,80000d3a <memmove+0x16>

  return dst;
}
    80000d4a:	6422                	ld	s0,8(sp)
    80000d4c:	0141                	addi	sp,sp,16
    80000d4e:	8082                	ret
  if(s < d && s + n > d){
    80000d50:	02061693          	slli	a3,a2,0x20
    80000d54:	9281                	srli	a3,a3,0x20
    80000d56:	00d58733          	add	a4,a1,a3
    80000d5a:	fce57be3          	bgeu	a0,a4,80000d30 <memmove+0xc>
    d += n;
    80000d5e:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d60:	fff6079b          	addiw	a5,a2,-1
    80000d64:	1782                	slli	a5,a5,0x20
    80000d66:	9381                	srli	a5,a5,0x20
    80000d68:	fff7c793          	not	a5,a5
    80000d6c:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d6e:	177d                	addi	a4,a4,-1
    80000d70:	16fd                	addi	a3,a3,-1
    80000d72:	00074603          	lbu	a2,0(a4)
    80000d76:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d7a:	fef71ae3          	bne	a4,a5,80000d6e <memmove+0x4a>
    80000d7e:	b7f1                	j	80000d4a <memmove+0x26>

0000000080000d80 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d80:	1141                	addi	sp,sp,-16
    80000d82:	e406                	sd	ra,8(sp)
    80000d84:	e022                	sd	s0,0(sp)
    80000d86:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d88:	f9dff0ef          	jal	80000d24 <memmove>
}
    80000d8c:	60a2                	ld	ra,8(sp)
    80000d8e:	6402                	ld	s0,0(sp)
    80000d90:	0141                	addi	sp,sp,16
    80000d92:	8082                	ret

0000000080000d94 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d94:	1141                	addi	sp,sp,-16
    80000d96:	e422                	sd	s0,8(sp)
    80000d98:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000d9a:	ce11                	beqz	a2,80000db6 <strncmp+0x22>
    80000d9c:	00054783          	lbu	a5,0(a0)
    80000da0:	cf89                	beqz	a5,80000dba <strncmp+0x26>
    80000da2:	0005c703          	lbu	a4,0(a1)
    80000da6:	00f71a63          	bne	a4,a5,80000dba <strncmp+0x26>
    n--, p++, q++;
    80000daa:	367d                	addiw	a2,a2,-1
    80000dac:	0505                	addi	a0,a0,1
    80000dae:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000db0:	f675                	bnez	a2,80000d9c <strncmp+0x8>
  if(n == 0)
    return 0;
    80000db2:	4501                	li	a0,0
    80000db4:	a801                	j	80000dc4 <strncmp+0x30>
    80000db6:	4501                	li	a0,0
    80000db8:	a031                	j	80000dc4 <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000dba:	00054503          	lbu	a0,0(a0)
    80000dbe:	0005c783          	lbu	a5,0(a1)
    80000dc2:	9d1d                	subw	a0,a0,a5
}
    80000dc4:	6422                	ld	s0,8(sp)
    80000dc6:	0141                	addi	sp,sp,16
    80000dc8:	8082                	ret

0000000080000dca <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000dca:	1141                	addi	sp,sp,-16
    80000dcc:	e422                	sd	s0,8(sp)
    80000dce:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000dd0:	87aa                	mv	a5,a0
    80000dd2:	86b2                	mv	a3,a2
    80000dd4:	367d                	addiw	a2,a2,-1
    80000dd6:	02d05563          	blez	a3,80000e00 <strncpy+0x36>
    80000dda:	0785                	addi	a5,a5,1
    80000ddc:	0005c703          	lbu	a4,0(a1)
    80000de0:	fee78fa3          	sb	a4,-1(a5)
    80000de4:	0585                	addi	a1,a1,1
    80000de6:	f775                	bnez	a4,80000dd2 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000de8:	873e                	mv	a4,a5
    80000dea:	9fb5                	addw	a5,a5,a3
    80000dec:	37fd                	addiw	a5,a5,-1
    80000dee:	00c05963          	blez	a2,80000e00 <strncpy+0x36>
    *s++ = 0;
    80000df2:	0705                	addi	a4,a4,1
    80000df4:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000df8:	40e786bb          	subw	a3,a5,a4
    80000dfc:	fed04be3          	bgtz	a3,80000df2 <strncpy+0x28>
  return os;
}
    80000e00:	6422                	ld	s0,8(sp)
    80000e02:	0141                	addi	sp,sp,16
    80000e04:	8082                	ret

0000000080000e06 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e06:	1141                	addi	sp,sp,-16
    80000e08:	e422                	sd	s0,8(sp)
    80000e0a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e0c:	02c05363          	blez	a2,80000e32 <safestrcpy+0x2c>
    80000e10:	fff6069b          	addiw	a3,a2,-1
    80000e14:	1682                	slli	a3,a3,0x20
    80000e16:	9281                	srli	a3,a3,0x20
    80000e18:	96ae                	add	a3,a3,a1
    80000e1a:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e1c:	00d58963          	beq	a1,a3,80000e2e <safestrcpy+0x28>
    80000e20:	0585                	addi	a1,a1,1
    80000e22:	0785                	addi	a5,a5,1
    80000e24:	fff5c703          	lbu	a4,-1(a1)
    80000e28:	fee78fa3          	sb	a4,-1(a5)
    80000e2c:	fb65                	bnez	a4,80000e1c <safestrcpy+0x16>
    ;
  *s = 0;
    80000e2e:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e32:	6422                	ld	s0,8(sp)
    80000e34:	0141                	addi	sp,sp,16
    80000e36:	8082                	ret

0000000080000e38 <strlen>:

int
strlen(const char *s)
{
    80000e38:	1141                	addi	sp,sp,-16
    80000e3a:	e422                	sd	s0,8(sp)
    80000e3c:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e3e:	00054783          	lbu	a5,0(a0)
    80000e42:	cf91                	beqz	a5,80000e5e <strlen+0x26>
    80000e44:	0505                	addi	a0,a0,1
    80000e46:	87aa                	mv	a5,a0
    80000e48:	86be                	mv	a3,a5
    80000e4a:	0785                	addi	a5,a5,1
    80000e4c:	fff7c703          	lbu	a4,-1(a5)
    80000e50:	ff65                	bnez	a4,80000e48 <strlen+0x10>
    80000e52:	40a6853b          	subw	a0,a3,a0
    80000e56:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000e58:	6422                	ld	s0,8(sp)
    80000e5a:	0141                	addi	sp,sp,16
    80000e5c:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e5e:	4501                	li	a0,0
    80000e60:	bfe5                	j	80000e58 <strlen+0x20>

0000000080000e62 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e62:	1141                	addi	sp,sp,-16
    80000e64:	e406                	sd	ra,8(sp)
    80000e66:	e022                	sd	s0,0(sp)
    80000e68:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e6a:	24b000ef          	jal	800018b4 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e6e:	00009717          	auipc	a4,0x9
    80000e72:	49a70713          	addi	a4,a4,1178 # 8000a308 <started>
  if(cpuid() == 0){
    80000e76:	c51d                	beqz	a0,80000ea4 <main+0x42>
    while(started == 0)
    80000e78:	431c                	lw	a5,0(a4)
    80000e7a:	2781                	sext.w	a5,a5
    80000e7c:	dff5                	beqz	a5,80000e78 <main+0x16>
      ;
    __sync_synchronize();
    80000e7e:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000e82:	233000ef          	jal	800018b4 <cpuid>
    80000e86:	85aa                	mv	a1,a0
    80000e88:	00006517          	auipc	a0,0x6
    80000e8c:	21050513          	addi	a0,a0,528 # 80007098 <etext+0x98>
    80000e90:	e32ff0ef          	jal	800004c2 <printf>
    kvminithart();    // turn on paging
    80000e94:	080000ef          	jal	80000f14 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000e98:	6aa010ef          	jal	80002542 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000e9c:	55c040ef          	jal	800053f8 <plicinithart>
  }

  scheduler();        
    80000ea0:	6e1000ef          	jal	80001d80 <scheduler>
    consoleinit();
    80000ea4:	d48ff0ef          	jal	800003ec <consoleinit>
    printfinit();
    80000ea8:	927ff0ef          	jal	800007ce <printfinit>
    printf("\n");
    80000eac:	00006517          	auipc	a0,0x6
    80000eb0:	1cc50513          	addi	a0,a0,460 # 80007078 <etext+0x78>
    80000eb4:	e0eff0ef          	jal	800004c2 <printf>
    printf("xv6 kernel is booting\n");
    80000eb8:	00006517          	auipc	a0,0x6
    80000ebc:	1c850513          	addi	a0,a0,456 # 80007080 <etext+0x80>
    80000ec0:	e02ff0ef          	jal	800004c2 <printf>
    printf("\n");
    80000ec4:	00006517          	auipc	a0,0x6
    80000ec8:	1b450513          	addi	a0,a0,436 # 80007078 <etext+0x78>
    80000ecc:	df6ff0ef          	jal	800004c2 <printf>
    kinit();         // physical page allocator
    80000ed0:	c21ff0ef          	jal	80000af0 <kinit>
    kvminit();       // create kernel page table
    80000ed4:	2ca000ef          	jal	8000119e <kvminit>
    kvminithart();   // turn on paging
    80000ed8:	03c000ef          	jal	80000f14 <kvminithart>
    procinit();      // process table
    80000edc:	123000ef          	jal	800017fe <procinit>
    trapinit();      // trap vectors
    80000ee0:	63e010ef          	jal	8000251e <trapinit>
    trapinithart();  // install kernel trap vector
    80000ee4:	65e010ef          	jal	80002542 <trapinithart>
    plicinit();      // set up interrupt controller
    80000ee8:	4f6040ef          	jal	800053de <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000eec:	50c040ef          	jal	800053f8 <plicinithart>
    binit();         // buffer cache
    80000ef0:	4bb010ef          	jal	80002baa <binit>
    iinit();         // inode table
    80000ef4:	2ac020ef          	jal	800031a0 <iinit>
    fileinit();      // file table
    80000ef8:	058030ef          	jal	80003f50 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000efc:	5ec040ef          	jal	800054e8 <virtio_disk_init>
    userinit();      // first user process
    80000f00:	46f000ef          	jal	80001b6e <userinit>
    __sync_synchronize();
    80000f04:	0330000f          	fence	rw,rw
    started = 1;
    80000f08:	4785                	li	a5,1
    80000f0a:	00009717          	auipc	a4,0x9
    80000f0e:	3ef72f23          	sw	a5,1022(a4) # 8000a308 <started>
    80000f12:	b779                	j	80000ea0 <main+0x3e>

0000000080000f14 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000f14:	1141                	addi	sp,sp,-16
    80000f16:	e422                	sd	s0,8(sp)
    80000f18:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f1a:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f1e:	00009797          	auipc	a5,0x9
    80000f22:	3f27b783          	ld	a5,1010(a5) # 8000a310 <kernel_pagetable>
    80000f26:	83b1                	srli	a5,a5,0xc
    80000f28:	577d                	li	a4,-1
    80000f2a:	177e                	slli	a4,a4,0x3f
    80000f2c:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f2e:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f32:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f36:	6422                	ld	s0,8(sp)
    80000f38:	0141                	addi	sp,sp,16
    80000f3a:	8082                	ret

0000000080000f3c <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f3c:	7139                	addi	sp,sp,-64
    80000f3e:	fc06                	sd	ra,56(sp)
    80000f40:	f822                	sd	s0,48(sp)
    80000f42:	f426                	sd	s1,40(sp)
    80000f44:	f04a                	sd	s2,32(sp)
    80000f46:	ec4e                	sd	s3,24(sp)
    80000f48:	e852                	sd	s4,16(sp)
    80000f4a:	e456                	sd	s5,8(sp)
    80000f4c:	e05a                	sd	s6,0(sp)
    80000f4e:	0080                	addi	s0,sp,64
    80000f50:	84aa                	mv	s1,a0
    80000f52:	89ae                	mv	s3,a1
    80000f54:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000f56:	57fd                	li	a5,-1
    80000f58:	83e9                	srli	a5,a5,0x1a
    80000f5a:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000f5c:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000f5e:	02b7fc63          	bgeu	a5,a1,80000f96 <walk+0x5a>
    panic("walk");
    80000f62:	00006517          	auipc	a0,0x6
    80000f66:	14e50513          	addi	a0,a0,334 # 800070b0 <etext+0xb0>
    80000f6a:	82bff0ef          	jal	80000794 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000f6e:	060a8263          	beqz	s5,80000fd2 <walk+0x96>
    80000f72:	bb3ff0ef          	jal	80000b24 <kalloc>
    80000f76:	84aa                	mv	s1,a0
    80000f78:	c139                	beqz	a0,80000fbe <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f7a:	6605                	lui	a2,0x1
    80000f7c:	4581                	li	a1,0
    80000f7e:	d4bff0ef          	jal	80000cc8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f82:	00c4d793          	srli	a5,s1,0xc
    80000f86:	07aa                	slli	a5,a5,0xa
    80000f88:	0017e793          	ori	a5,a5,1
    80000f8c:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000f90:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffdb597>
    80000f92:	036a0063          	beq	s4,s6,80000fb2 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f96:	0149d933          	srl	s2,s3,s4
    80000f9a:	1ff97913          	andi	s2,s2,511
    80000f9e:	090e                	slli	s2,s2,0x3
    80000fa0:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fa2:	00093483          	ld	s1,0(s2)
    80000fa6:	0014f793          	andi	a5,s1,1
    80000faa:	d3f1                	beqz	a5,80000f6e <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fac:	80a9                	srli	s1,s1,0xa
    80000fae:	04b2                	slli	s1,s1,0xc
    80000fb0:	b7c5                	j	80000f90 <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000fb2:	00c9d513          	srli	a0,s3,0xc
    80000fb6:	1ff57513          	andi	a0,a0,511
    80000fba:	050e                	slli	a0,a0,0x3
    80000fbc:	9526                	add	a0,a0,s1
}
    80000fbe:	70e2                	ld	ra,56(sp)
    80000fc0:	7442                	ld	s0,48(sp)
    80000fc2:	74a2                	ld	s1,40(sp)
    80000fc4:	7902                	ld	s2,32(sp)
    80000fc6:	69e2                	ld	s3,24(sp)
    80000fc8:	6a42                	ld	s4,16(sp)
    80000fca:	6aa2                	ld	s5,8(sp)
    80000fcc:	6b02                	ld	s6,0(sp)
    80000fce:	6121                	addi	sp,sp,64
    80000fd0:	8082                	ret
        return 0;
    80000fd2:	4501                	li	a0,0
    80000fd4:	b7ed                	j	80000fbe <walk+0x82>

0000000080000fd6 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000fd6:	57fd                	li	a5,-1
    80000fd8:	83e9                	srli	a5,a5,0x1a
    80000fda:	00b7f463          	bgeu	a5,a1,80000fe2 <walkaddr+0xc>
    return 0;
    80000fde:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fe0:	8082                	ret
{
    80000fe2:	1141                	addi	sp,sp,-16
    80000fe4:	e406                	sd	ra,8(sp)
    80000fe6:	e022                	sd	s0,0(sp)
    80000fe8:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fea:	4601                	li	a2,0
    80000fec:	f51ff0ef          	jal	80000f3c <walk>
  if(pte == 0)
    80000ff0:	c105                	beqz	a0,80001010 <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000ff2:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000ff4:	0117f693          	andi	a3,a5,17
    80000ff8:	4745                	li	a4,17
    return 0;
    80000ffa:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000ffc:	00e68663          	beq	a3,a4,80001008 <walkaddr+0x32>
}
    80001000:	60a2                	ld	ra,8(sp)
    80001002:	6402                	ld	s0,0(sp)
    80001004:	0141                	addi	sp,sp,16
    80001006:	8082                	ret
  pa = PTE2PA(*pte);
    80001008:	83a9                	srli	a5,a5,0xa
    8000100a:	00c79513          	slli	a0,a5,0xc
  return pa;
    8000100e:	bfcd                	j	80001000 <walkaddr+0x2a>
    return 0;
    80001010:	4501                	li	a0,0
    80001012:	b7fd                	j	80001000 <walkaddr+0x2a>

0000000080001014 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001014:	715d                	addi	sp,sp,-80
    80001016:	e486                	sd	ra,72(sp)
    80001018:	e0a2                	sd	s0,64(sp)
    8000101a:	fc26                	sd	s1,56(sp)
    8000101c:	f84a                	sd	s2,48(sp)
    8000101e:	f44e                	sd	s3,40(sp)
    80001020:	f052                	sd	s4,32(sp)
    80001022:	ec56                	sd	s5,24(sp)
    80001024:	e85a                	sd	s6,16(sp)
    80001026:	e45e                	sd	s7,8(sp)
    80001028:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000102a:	03459793          	slli	a5,a1,0x34
    8000102e:	e7a9                	bnez	a5,80001078 <mappages+0x64>
    80001030:	8aaa                	mv	s5,a0
    80001032:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80001034:	03461793          	slli	a5,a2,0x34
    80001038:	e7b1                	bnez	a5,80001084 <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    8000103a:	ca39                	beqz	a2,80001090 <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    8000103c:	77fd                	lui	a5,0xfffff
    8000103e:	963e                	add	a2,a2,a5
    80001040:	00b609b3          	add	s3,a2,a1
  a = va;
    80001044:	892e                	mv	s2,a1
    80001046:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    8000104a:	6b85                	lui	s7,0x1
    8000104c:	014904b3          	add	s1,s2,s4
    if((pte = walk(pagetable, a, 1)) == 0)
    80001050:	4605                	li	a2,1
    80001052:	85ca                	mv	a1,s2
    80001054:	8556                	mv	a0,s5
    80001056:	ee7ff0ef          	jal	80000f3c <walk>
    8000105a:	c539                	beqz	a0,800010a8 <mappages+0x94>
    if(*pte & PTE_V)
    8000105c:	611c                	ld	a5,0(a0)
    8000105e:	8b85                	andi	a5,a5,1
    80001060:	ef95                	bnez	a5,8000109c <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001062:	80b1                	srli	s1,s1,0xc
    80001064:	04aa                	slli	s1,s1,0xa
    80001066:	0164e4b3          	or	s1,s1,s6
    8000106a:	0014e493          	ori	s1,s1,1
    8000106e:	e104                	sd	s1,0(a0)
    if(a == last)
    80001070:	05390863          	beq	s2,s3,800010c0 <mappages+0xac>
    a += PGSIZE;
    80001074:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001076:	bfd9                	j	8000104c <mappages+0x38>
    panic("mappages: va not aligned");
    80001078:	00006517          	auipc	a0,0x6
    8000107c:	04050513          	addi	a0,a0,64 # 800070b8 <etext+0xb8>
    80001080:	f14ff0ef          	jal	80000794 <panic>
    panic("mappages: size not aligned");
    80001084:	00006517          	auipc	a0,0x6
    80001088:	05450513          	addi	a0,a0,84 # 800070d8 <etext+0xd8>
    8000108c:	f08ff0ef          	jal	80000794 <panic>
    panic("mappages: size");
    80001090:	00006517          	auipc	a0,0x6
    80001094:	06850513          	addi	a0,a0,104 # 800070f8 <etext+0xf8>
    80001098:	efcff0ef          	jal	80000794 <panic>
      panic("mappages: remap");
    8000109c:	00006517          	auipc	a0,0x6
    800010a0:	06c50513          	addi	a0,a0,108 # 80007108 <etext+0x108>
    800010a4:	ef0ff0ef          	jal	80000794 <panic>
      return -1;
    800010a8:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010aa:	60a6                	ld	ra,72(sp)
    800010ac:	6406                	ld	s0,64(sp)
    800010ae:	74e2                	ld	s1,56(sp)
    800010b0:	7942                	ld	s2,48(sp)
    800010b2:	79a2                	ld	s3,40(sp)
    800010b4:	7a02                	ld	s4,32(sp)
    800010b6:	6ae2                	ld	s5,24(sp)
    800010b8:	6b42                	ld	s6,16(sp)
    800010ba:	6ba2                	ld	s7,8(sp)
    800010bc:	6161                	addi	sp,sp,80
    800010be:	8082                	ret
  return 0;
    800010c0:	4501                	li	a0,0
    800010c2:	b7e5                	j	800010aa <mappages+0x96>

00000000800010c4 <kvmmap>:
{
    800010c4:	1141                	addi	sp,sp,-16
    800010c6:	e406                	sd	ra,8(sp)
    800010c8:	e022                	sd	s0,0(sp)
    800010ca:	0800                	addi	s0,sp,16
    800010cc:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010ce:	86b2                	mv	a3,a2
    800010d0:	863e                	mv	a2,a5
    800010d2:	f43ff0ef          	jal	80001014 <mappages>
    800010d6:	e509                	bnez	a0,800010e0 <kvmmap+0x1c>
}
    800010d8:	60a2                	ld	ra,8(sp)
    800010da:	6402                	ld	s0,0(sp)
    800010dc:	0141                	addi	sp,sp,16
    800010de:	8082                	ret
    panic("kvmmap");
    800010e0:	00006517          	auipc	a0,0x6
    800010e4:	03850513          	addi	a0,a0,56 # 80007118 <etext+0x118>
    800010e8:	eacff0ef          	jal	80000794 <panic>

00000000800010ec <kvmmake>:
{
    800010ec:	1101                	addi	sp,sp,-32
    800010ee:	ec06                	sd	ra,24(sp)
    800010f0:	e822                	sd	s0,16(sp)
    800010f2:	e426                	sd	s1,8(sp)
    800010f4:	e04a                	sd	s2,0(sp)
    800010f6:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800010f8:	a2dff0ef          	jal	80000b24 <kalloc>
    800010fc:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800010fe:	6605                	lui	a2,0x1
    80001100:	4581                	li	a1,0
    80001102:	bc7ff0ef          	jal	80000cc8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001106:	4719                	li	a4,6
    80001108:	6685                	lui	a3,0x1
    8000110a:	10000637          	lui	a2,0x10000
    8000110e:	100005b7          	lui	a1,0x10000
    80001112:	8526                	mv	a0,s1
    80001114:	fb1ff0ef          	jal	800010c4 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001118:	4719                	li	a4,6
    8000111a:	6685                	lui	a3,0x1
    8000111c:	10001637          	lui	a2,0x10001
    80001120:	100015b7          	lui	a1,0x10001
    80001124:	8526                	mv	a0,s1
    80001126:	f9fff0ef          	jal	800010c4 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000112a:	4719                	li	a4,6
    8000112c:	040006b7          	lui	a3,0x4000
    80001130:	0c000637          	lui	a2,0xc000
    80001134:	0c0005b7          	lui	a1,0xc000
    80001138:	8526                	mv	a0,s1
    8000113a:	f8bff0ef          	jal	800010c4 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    8000113e:	00006917          	auipc	s2,0x6
    80001142:	ec290913          	addi	s2,s2,-318 # 80007000 <etext>
    80001146:	4729                	li	a4,10
    80001148:	80006697          	auipc	a3,0x80006
    8000114c:	eb868693          	addi	a3,a3,-328 # 7000 <_entry-0x7fff9000>
    80001150:	4605                	li	a2,1
    80001152:	067e                	slli	a2,a2,0x1f
    80001154:	85b2                	mv	a1,a2
    80001156:	8526                	mv	a0,s1
    80001158:	f6dff0ef          	jal	800010c4 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    8000115c:	46c5                	li	a3,17
    8000115e:	06ee                	slli	a3,a3,0x1b
    80001160:	4719                	li	a4,6
    80001162:	412686b3          	sub	a3,a3,s2
    80001166:	864a                	mv	a2,s2
    80001168:	85ca                	mv	a1,s2
    8000116a:	8526                	mv	a0,s1
    8000116c:	f59ff0ef          	jal	800010c4 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001170:	4729                	li	a4,10
    80001172:	6685                	lui	a3,0x1
    80001174:	00005617          	auipc	a2,0x5
    80001178:	e8c60613          	addi	a2,a2,-372 # 80006000 <_trampoline>
    8000117c:	040005b7          	lui	a1,0x4000
    80001180:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001182:	05b2                	slli	a1,a1,0xc
    80001184:	8526                	mv	a0,s1
    80001186:	f3fff0ef          	jal	800010c4 <kvmmap>
  proc_mapstacks(kpgtbl);
    8000118a:	8526                	mv	a0,s1
    8000118c:	5da000ef          	jal	80001766 <proc_mapstacks>
}
    80001190:	8526                	mv	a0,s1
    80001192:	60e2                	ld	ra,24(sp)
    80001194:	6442                	ld	s0,16(sp)
    80001196:	64a2                	ld	s1,8(sp)
    80001198:	6902                	ld	s2,0(sp)
    8000119a:	6105                	addi	sp,sp,32
    8000119c:	8082                	ret

000000008000119e <kvminit>:
{
    8000119e:	1141                	addi	sp,sp,-16
    800011a0:	e406                	sd	ra,8(sp)
    800011a2:	e022                	sd	s0,0(sp)
    800011a4:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011a6:	f47ff0ef          	jal	800010ec <kvmmake>
    800011aa:	00009797          	auipc	a5,0x9
    800011ae:	16a7b323          	sd	a0,358(a5) # 8000a310 <kernel_pagetable>
}
    800011b2:	60a2                	ld	ra,8(sp)
    800011b4:	6402                	ld	s0,0(sp)
    800011b6:	0141                	addi	sp,sp,16
    800011b8:	8082                	ret

00000000800011ba <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011ba:	715d                	addi	sp,sp,-80
    800011bc:	e486                	sd	ra,72(sp)
    800011be:	e0a2                	sd	s0,64(sp)
    800011c0:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800011c2:	03459793          	slli	a5,a1,0x34
    800011c6:	e39d                	bnez	a5,800011ec <uvmunmap+0x32>
    800011c8:	f84a                	sd	s2,48(sp)
    800011ca:	f44e                	sd	s3,40(sp)
    800011cc:	f052                	sd	s4,32(sp)
    800011ce:	ec56                	sd	s5,24(sp)
    800011d0:	e85a                	sd	s6,16(sp)
    800011d2:	e45e                	sd	s7,8(sp)
    800011d4:	8a2a                	mv	s4,a0
    800011d6:	892e                	mv	s2,a1
    800011d8:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800011da:	0632                	slli	a2,a2,0xc
    800011dc:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    800011e0:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800011e2:	6b05                	lui	s6,0x1
    800011e4:	0735ff63          	bgeu	a1,s3,80001262 <uvmunmap+0xa8>
    800011e8:	fc26                	sd	s1,56(sp)
    800011ea:	a0a9                	j	80001234 <uvmunmap+0x7a>
    800011ec:	fc26                	sd	s1,56(sp)
    800011ee:	f84a                	sd	s2,48(sp)
    800011f0:	f44e                	sd	s3,40(sp)
    800011f2:	f052                	sd	s4,32(sp)
    800011f4:	ec56                	sd	s5,24(sp)
    800011f6:	e85a                	sd	s6,16(sp)
    800011f8:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    800011fa:	00006517          	auipc	a0,0x6
    800011fe:	f2650513          	addi	a0,a0,-218 # 80007120 <etext+0x120>
    80001202:	d92ff0ef          	jal	80000794 <panic>
      panic("uvmunmap: walk");
    80001206:	00006517          	auipc	a0,0x6
    8000120a:	f3250513          	addi	a0,a0,-206 # 80007138 <etext+0x138>
    8000120e:	d86ff0ef          	jal	80000794 <panic>
      panic("uvmunmap: not mapped");
    80001212:	00006517          	auipc	a0,0x6
    80001216:	f3650513          	addi	a0,a0,-202 # 80007148 <etext+0x148>
    8000121a:	d7aff0ef          	jal	80000794 <panic>
      panic("uvmunmap: not a leaf");
    8000121e:	00006517          	auipc	a0,0x6
    80001222:	f4250513          	addi	a0,a0,-190 # 80007160 <etext+0x160>
    80001226:	d6eff0ef          	jal	80000794 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    8000122a:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000122e:	995a                	add	s2,s2,s6
    80001230:	03397863          	bgeu	s2,s3,80001260 <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    80001234:	4601                	li	a2,0
    80001236:	85ca                	mv	a1,s2
    80001238:	8552                	mv	a0,s4
    8000123a:	d03ff0ef          	jal	80000f3c <walk>
    8000123e:	84aa                	mv	s1,a0
    80001240:	d179                	beqz	a0,80001206 <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    80001242:	6108                	ld	a0,0(a0)
    80001244:	00157793          	andi	a5,a0,1
    80001248:	d7e9                	beqz	a5,80001212 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    8000124a:	3ff57793          	andi	a5,a0,1023
    8000124e:	fd7788e3          	beq	a5,s7,8000121e <uvmunmap+0x64>
    if(do_free){
    80001252:	fc0a8ce3          	beqz	s5,8000122a <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    80001256:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    80001258:	0532                	slli	a0,a0,0xc
    8000125a:	fe8ff0ef          	jal	80000a42 <kfree>
    8000125e:	b7f1                	j	8000122a <uvmunmap+0x70>
    80001260:	74e2                	ld	s1,56(sp)
    80001262:	7942                	ld	s2,48(sp)
    80001264:	79a2                	ld	s3,40(sp)
    80001266:	7a02                	ld	s4,32(sp)
    80001268:	6ae2                	ld	s5,24(sp)
    8000126a:	6b42                	ld	s6,16(sp)
    8000126c:	6ba2                	ld	s7,8(sp)
  }
}
    8000126e:	60a6                	ld	ra,72(sp)
    80001270:	6406                	ld	s0,64(sp)
    80001272:	6161                	addi	sp,sp,80
    80001274:	8082                	ret

0000000080001276 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001276:	1101                	addi	sp,sp,-32
    80001278:	ec06                	sd	ra,24(sp)
    8000127a:	e822                	sd	s0,16(sp)
    8000127c:	e426                	sd	s1,8(sp)
    8000127e:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001280:	8a5ff0ef          	jal	80000b24 <kalloc>
    80001284:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001286:	c509                	beqz	a0,80001290 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001288:	6605                	lui	a2,0x1
    8000128a:	4581                	li	a1,0
    8000128c:	a3dff0ef          	jal	80000cc8 <memset>
  return pagetable;
}
    80001290:	8526                	mv	a0,s1
    80001292:	60e2                	ld	ra,24(sp)
    80001294:	6442                	ld	s0,16(sp)
    80001296:	64a2                	ld	s1,8(sp)
    80001298:	6105                	addi	sp,sp,32
    8000129a:	8082                	ret

000000008000129c <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000129c:	7179                	addi	sp,sp,-48
    8000129e:	f406                	sd	ra,40(sp)
    800012a0:	f022                	sd	s0,32(sp)
    800012a2:	ec26                	sd	s1,24(sp)
    800012a4:	e84a                	sd	s2,16(sp)
    800012a6:	e44e                	sd	s3,8(sp)
    800012a8:	e052                	sd	s4,0(sp)
    800012aa:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    800012ac:	6785                	lui	a5,0x1
    800012ae:	04f67063          	bgeu	a2,a5,800012ee <uvmfirst+0x52>
    800012b2:	8a2a                	mv	s4,a0
    800012b4:	89ae                	mv	s3,a1
    800012b6:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    800012b8:	86dff0ef          	jal	80000b24 <kalloc>
    800012bc:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    800012be:	6605                	lui	a2,0x1
    800012c0:	4581                	li	a1,0
    800012c2:	a07ff0ef          	jal	80000cc8 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    800012c6:	4779                	li	a4,30
    800012c8:	86ca                	mv	a3,s2
    800012ca:	6605                	lui	a2,0x1
    800012cc:	4581                	li	a1,0
    800012ce:	8552                	mv	a0,s4
    800012d0:	d45ff0ef          	jal	80001014 <mappages>
  memmove(mem, src, sz);
    800012d4:	8626                	mv	a2,s1
    800012d6:	85ce                	mv	a1,s3
    800012d8:	854a                	mv	a0,s2
    800012da:	a4bff0ef          	jal	80000d24 <memmove>
}
    800012de:	70a2                	ld	ra,40(sp)
    800012e0:	7402                	ld	s0,32(sp)
    800012e2:	64e2                	ld	s1,24(sp)
    800012e4:	6942                	ld	s2,16(sp)
    800012e6:	69a2                	ld	s3,8(sp)
    800012e8:	6a02                	ld	s4,0(sp)
    800012ea:	6145                	addi	sp,sp,48
    800012ec:	8082                	ret
    panic("uvmfirst: more than a page");
    800012ee:	00006517          	auipc	a0,0x6
    800012f2:	e8a50513          	addi	a0,a0,-374 # 80007178 <etext+0x178>
    800012f6:	c9eff0ef          	jal	80000794 <panic>

00000000800012fa <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012fa:	1101                	addi	sp,sp,-32
    800012fc:	ec06                	sd	ra,24(sp)
    800012fe:	e822                	sd	s0,16(sp)
    80001300:	e426                	sd	s1,8(sp)
    80001302:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80001304:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    80001306:	00b67d63          	bgeu	a2,a1,80001320 <uvmdealloc+0x26>
    8000130a:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    8000130c:	6785                	lui	a5,0x1
    8000130e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001310:	00f60733          	add	a4,a2,a5
    80001314:	76fd                	lui	a3,0xfffff
    80001316:	8f75                	and	a4,a4,a3
    80001318:	97ae                	add	a5,a5,a1
    8000131a:	8ff5                	and	a5,a5,a3
    8000131c:	00f76863          	bltu	a4,a5,8000132c <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001320:	8526                	mv	a0,s1
    80001322:	60e2                	ld	ra,24(sp)
    80001324:	6442                	ld	s0,16(sp)
    80001326:	64a2                	ld	s1,8(sp)
    80001328:	6105                	addi	sp,sp,32
    8000132a:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000132c:	8f99                	sub	a5,a5,a4
    8000132e:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001330:	4685                	li	a3,1
    80001332:	0007861b          	sext.w	a2,a5
    80001336:	85ba                	mv	a1,a4
    80001338:	e83ff0ef          	jal	800011ba <uvmunmap>
    8000133c:	b7d5                	j	80001320 <uvmdealloc+0x26>

000000008000133e <uvmalloc>:
  if(newsz < oldsz)
    8000133e:	08b66f63          	bltu	a2,a1,800013dc <uvmalloc+0x9e>
{
    80001342:	7139                	addi	sp,sp,-64
    80001344:	fc06                	sd	ra,56(sp)
    80001346:	f822                	sd	s0,48(sp)
    80001348:	ec4e                	sd	s3,24(sp)
    8000134a:	e852                	sd	s4,16(sp)
    8000134c:	e456                	sd	s5,8(sp)
    8000134e:	0080                	addi	s0,sp,64
    80001350:	8aaa                	mv	s5,a0
    80001352:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001354:	6785                	lui	a5,0x1
    80001356:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001358:	95be                	add	a1,a1,a5
    8000135a:	77fd                	lui	a5,0xfffff
    8000135c:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001360:	08c9f063          	bgeu	s3,a2,800013e0 <uvmalloc+0xa2>
    80001364:	f426                	sd	s1,40(sp)
    80001366:	f04a                	sd	s2,32(sp)
    80001368:	e05a                	sd	s6,0(sp)
    8000136a:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000136c:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001370:	fb4ff0ef          	jal	80000b24 <kalloc>
    80001374:	84aa                	mv	s1,a0
    if(mem == 0){
    80001376:	c515                	beqz	a0,800013a2 <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    80001378:	6605                	lui	a2,0x1
    8000137a:	4581                	li	a1,0
    8000137c:	94dff0ef          	jal	80000cc8 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001380:	875a                	mv	a4,s6
    80001382:	86a6                	mv	a3,s1
    80001384:	6605                	lui	a2,0x1
    80001386:	85ca                	mv	a1,s2
    80001388:	8556                	mv	a0,s5
    8000138a:	c8bff0ef          	jal	80001014 <mappages>
    8000138e:	e915                	bnez	a0,800013c2 <uvmalloc+0x84>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001390:	6785                	lui	a5,0x1
    80001392:	993e                	add	s2,s2,a5
    80001394:	fd496ee3          	bltu	s2,s4,80001370 <uvmalloc+0x32>
  return newsz;
    80001398:	8552                	mv	a0,s4
    8000139a:	74a2                	ld	s1,40(sp)
    8000139c:	7902                	ld	s2,32(sp)
    8000139e:	6b02                	ld	s6,0(sp)
    800013a0:	a811                	j	800013b4 <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    800013a2:	864e                	mv	a2,s3
    800013a4:	85ca                	mv	a1,s2
    800013a6:	8556                	mv	a0,s5
    800013a8:	f53ff0ef          	jal	800012fa <uvmdealloc>
      return 0;
    800013ac:	4501                	li	a0,0
    800013ae:	74a2                	ld	s1,40(sp)
    800013b0:	7902                	ld	s2,32(sp)
    800013b2:	6b02                	ld	s6,0(sp)
}
    800013b4:	70e2                	ld	ra,56(sp)
    800013b6:	7442                	ld	s0,48(sp)
    800013b8:	69e2                	ld	s3,24(sp)
    800013ba:	6a42                	ld	s4,16(sp)
    800013bc:	6aa2                	ld	s5,8(sp)
    800013be:	6121                	addi	sp,sp,64
    800013c0:	8082                	ret
      kfree(mem);
    800013c2:	8526                	mv	a0,s1
    800013c4:	e7eff0ef          	jal	80000a42 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800013c8:	864e                	mv	a2,s3
    800013ca:	85ca                	mv	a1,s2
    800013cc:	8556                	mv	a0,s5
    800013ce:	f2dff0ef          	jal	800012fa <uvmdealloc>
      return 0;
    800013d2:	4501                	li	a0,0
    800013d4:	74a2                	ld	s1,40(sp)
    800013d6:	7902                	ld	s2,32(sp)
    800013d8:	6b02                	ld	s6,0(sp)
    800013da:	bfe9                	j	800013b4 <uvmalloc+0x76>
    return oldsz;
    800013dc:	852e                	mv	a0,a1
}
    800013de:	8082                	ret
  return newsz;
    800013e0:	8532                	mv	a0,a2
    800013e2:	bfc9                	j	800013b4 <uvmalloc+0x76>

00000000800013e4 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800013e4:	7179                	addi	sp,sp,-48
    800013e6:	f406                	sd	ra,40(sp)
    800013e8:	f022                	sd	s0,32(sp)
    800013ea:	ec26                	sd	s1,24(sp)
    800013ec:	e84a                	sd	s2,16(sp)
    800013ee:	e44e                	sd	s3,8(sp)
    800013f0:	e052                	sd	s4,0(sp)
    800013f2:	1800                	addi	s0,sp,48
    800013f4:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800013f6:	84aa                	mv	s1,a0
    800013f8:	6905                	lui	s2,0x1
    800013fa:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013fc:	4985                	li	s3,1
    800013fe:	a819                	j	80001414 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80001400:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001402:	00c79513          	slli	a0,a5,0xc
    80001406:	fdfff0ef          	jal	800013e4 <freewalk>
      pagetable[i] = 0;
    8000140a:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    8000140e:	04a1                	addi	s1,s1,8
    80001410:	01248f63          	beq	s1,s2,8000142e <freewalk+0x4a>
    pte_t pte = pagetable[i];
    80001414:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001416:	00f7f713          	andi	a4,a5,15
    8000141a:	ff3703e3          	beq	a4,s3,80001400 <freewalk+0x1c>
    } else if(pte & PTE_V){
    8000141e:	8b85                	andi	a5,a5,1
    80001420:	d7fd                	beqz	a5,8000140e <freewalk+0x2a>
      panic("freewalk: leaf");
    80001422:	00006517          	auipc	a0,0x6
    80001426:	d7650513          	addi	a0,a0,-650 # 80007198 <etext+0x198>
    8000142a:	b6aff0ef          	jal	80000794 <panic>
    }
  }
  kfree((void*)pagetable);
    8000142e:	8552                	mv	a0,s4
    80001430:	e12ff0ef          	jal	80000a42 <kfree>
}
    80001434:	70a2                	ld	ra,40(sp)
    80001436:	7402                	ld	s0,32(sp)
    80001438:	64e2                	ld	s1,24(sp)
    8000143a:	6942                	ld	s2,16(sp)
    8000143c:	69a2                	ld	s3,8(sp)
    8000143e:	6a02                	ld	s4,0(sp)
    80001440:	6145                	addi	sp,sp,48
    80001442:	8082                	ret

0000000080001444 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001444:	1101                	addi	sp,sp,-32
    80001446:	ec06                	sd	ra,24(sp)
    80001448:	e822                	sd	s0,16(sp)
    8000144a:	e426                	sd	s1,8(sp)
    8000144c:	1000                	addi	s0,sp,32
    8000144e:	84aa                	mv	s1,a0
  if(sz > 0)
    80001450:	e989                	bnez	a1,80001462 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001452:	8526                	mv	a0,s1
    80001454:	f91ff0ef          	jal	800013e4 <freewalk>
}
    80001458:	60e2                	ld	ra,24(sp)
    8000145a:	6442                	ld	s0,16(sp)
    8000145c:	64a2                	ld	s1,8(sp)
    8000145e:	6105                	addi	sp,sp,32
    80001460:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001462:	6785                	lui	a5,0x1
    80001464:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001466:	95be                	add	a1,a1,a5
    80001468:	4685                	li	a3,1
    8000146a:	00c5d613          	srli	a2,a1,0xc
    8000146e:	4581                	li	a1,0
    80001470:	d4bff0ef          	jal	800011ba <uvmunmap>
    80001474:	bff9                	j	80001452 <uvmfree+0xe>

0000000080001476 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001476:	c65d                	beqz	a2,80001524 <uvmcopy+0xae>
{
    80001478:	715d                	addi	sp,sp,-80
    8000147a:	e486                	sd	ra,72(sp)
    8000147c:	e0a2                	sd	s0,64(sp)
    8000147e:	fc26                	sd	s1,56(sp)
    80001480:	f84a                	sd	s2,48(sp)
    80001482:	f44e                	sd	s3,40(sp)
    80001484:	f052                	sd	s4,32(sp)
    80001486:	ec56                	sd	s5,24(sp)
    80001488:	e85a                	sd	s6,16(sp)
    8000148a:	e45e                	sd	s7,8(sp)
    8000148c:	0880                	addi	s0,sp,80
    8000148e:	8b2a                	mv	s6,a0
    80001490:	8aae                	mv	s5,a1
    80001492:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001494:	4981                	li	s3,0
    if((pte = walk(old, i, 0)) == 0)
    80001496:	4601                	li	a2,0
    80001498:	85ce                	mv	a1,s3
    8000149a:	855a                	mv	a0,s6
    8000149c:	aa1ff0ef          	jal	80000f3c <walk>
    800014a0:	c121                	beqz	a0,800014e0 <uvmcopy+0x6a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    800014a2:	6118                	ld	a4,0(a0)
    800014a4:	00177793          	andi	a5,a4,1
    800014a8:	c3b1                	beqz	a5,800014ec <uvmcopy+0x76>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    800014aa:	00a75593          	srli	a1,a4,0xa
    800014ae:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800014b2:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    800014b6:	e6eff0ef          	jal	80000b24 <kalloc>
    800014ba:	892a                	mv	s2,a0
    800014bc:	c129                	beqz	a0,800014fe <uvmcopy+0x88>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    800014be:	6605                	lui	a2,0x1
    800014c0:	85de                	mv	a1,s7
    800014c2:	863ff0ef          	jal	80000d24 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800014c6:	8726                	mv	a4,s1
    800014c8:	86ca                	mv	a3,s2
    800014ca:	6605                	lui	a2,0x1
    800014cc:	85ce                	mv	a1,s3
    800014ce:	8556                	mv	a0,s5
    800014d0:	b45ff0ef          	jal	80001014 <mappages>
    800014d4:	e115                	bnez	a0,800014f8 <uvmcopy+0x82>
  for(i = 0; i < sz; i += PGSIZE){
    800014d6:	6785                	lui	a5,0x1
    800014d8:	99be                	add	s3,s3,a5
    800014da:	fb49eee3          	bltu	s3,s4,80001496 <uvmcopy+0x20>
    800014de:	a805                	j	8000150e <uvmcopy+0x98>
      panic("uvmcopy: pte should exist");
    800014e0:	00006517          	auipc	a0,0x6
    800014e4:	cc850513          	addi	a0,a0,-824 # 800071a8 <etext+0x1a8>
    800014e8:	aacff0ef          	jal	80000794 <panic>
      panic("uvmcopy: page not present");
    800014ec:	00006517          	auipc	a0,0x6
    800014f0:	cdc50513          	addi	a0,a0,-804 # 800071c8 <etext+0x1c8>
    800014f4:	aa0ff0ef          	jal	80000794 <panic>
      kfree(mem);
    800014f8:	854a                	mv	a0,s2
    800014fa:	d48ff0ef          	jal	80000a42 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800014fe:	4685                	li	a3,1
    80001500:	00c9d613          	srli	a2,s3,0xc
    80001504:	4581                	li	a1,0
    80001506:	8556                	mv	a0,s5
    80001508:	cb3ff0ef          	jal	800011ba <uvmunmap>
  return -1;
    8000150c:	557d                	li	a0,-1
}
    8000150e:	60a6                	ld	ra,72(sp)
    80001510:	6406                	ld	s0,64(sp)
    80001512:	74e2                	ld	s1,56(sp)
    80001514:	7942                	ld	s2,48(sp)
    80001516:	79a2                	ld	s3,40(sp)
    80001518:	7a02                	ld	s4,32(sp)
    8000151a:	6ae2                	ld	s5,24(sp)
    8000151c:	6b42                	ld	s6,16(sp)
    8000151e:	6ba2                	ld	s7,8(sp)
    80001520:	6161                	addi	sp,sp,80
    80001522:	8082                	ret
  return 0;
    80001524:	4501                	li	a0,0
}
    80001526:	8082                	ret

0000000080001528 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001528:	1141                	addi	sp,sp,-16
    8000152a:	e406                	sd	ra,8(sp)
    8000152c:	e022                	sd	s0,0(sp)
    8000152e:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001530:	4601                	li	a2,0
    80001532:	a0bff0ef          	jal	80000f3c <walk>
  if(pte == 0)
    80001536:	c901                	beqz	a0,80001546 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001538:	611c                	ld	a5,0(a0)
    8000153a:	9bbd                	andi	a5,a5,-17
    8000153c:	e11c                	sd	a5,0(a0)
}
    8000153e:	60a2                	ld	ra,8(sp)
    80001540:	6402                	ld	s0,0(sp)
    80001542:	0141                	addi	sp,sp,16
    80001544:	8082                	ret
    panic("uvmclear");
    80001546:	00006517          	auipc	a0,0x6
    8000154a:	ca250513          	addi	a0,a0,-862 # 800071e8 <etext+0x1e8>
    8000154e:	a46ff0ef          	jal	80000794 <panic>

0000000080001552 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    80001552:	cad1                	beqz	a3,800015e6 <copyout+0x94>
{
    80001554:	711d                	addi	sp,sp,-96
    80001556:	ec86                	sd	ra,88(sp)
    80001558:	e8a2                	sd	s0,80(sp)
    8000155a:	e4a6                	sd	s1,72(sp)
    8000155c:	fc4e                	sd	s3,56(sp)
    8000155e:	f456                	sd	s5,40(sp)
    80001560:	f05a                	sd	s6,32(sp)
    80001562:	ec5e                	sd	s7,24(sp)
    80001564:	1080                	addi	s0,sp,96
    80001566:	8baa                	mv	s7,a0
    80001568:	8aae                	mv	s5,a1
    8000156a:	8b32                	mv	s6,a2
    8000156c:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    8000156e:	74fd                	lui	s1,0xfffff
    80001570:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    80001572:	57fd                	li	a5,-1
    80001574:	83e9                	srli	a5,a5,0x1a
    80001576:	0697ea63          	bltu	a5,s1,800015ea <copyout+0x98>
    8000157a:	e0ca                	sd	s2,64(sp)
    8000157c:	f852                	sd	s4,48(sp)
    8000157e:	e862                	sd	s8,16(sp)
    80001580:	e466                	sd	s9,8(sp)
    80001582:	e06a                	sd	s10,0(sp)
      return -1;
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80001584:	4cd5                	li	s9,21
    80001586:	6d05                	lui	s10,0x1
    if(va0 >= MAXVA)
    80001588:	8c3e                	mv	s8,a5
    8000158a:	a025                	j	800015b2 <copyout+0x60>
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    8000158c:	83a9                	srli	a5,a5,0xa
    8000158e:	07b2                	slli	a5,a5,0xc
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001590:	409a8533          	sub	a0,s5,s1
    80001594:	0009061b          	sext.w	a2,s2
    80001598:	85da                	mv	a1,s6
    8000159a:	953e                	add	a0,a0,a5
    8000159c:	f88ff0ef          	jal	80000d24 <memmove>

    len -= n;
    800015a0:	412989b3          	sub	s3,s3,s2
    src += n;
    800015a4:	9b4a                	add	s6,s6,s2
  while(len > 0){
    800015a6:	02098963          	beqz	s3,800015d8 <copyout+0x86>
    if(va0 >= MAXVA)
    800015aa:	054c6263          	bltu	s8,s4,800015ee <copyout+0x9c>
    800015ae:	84d2                	mv	s1,s4
    800015b0:	8ad2                	mv	s5,s4
    pte = walk(pagetable, va0, 0);
    800015b2:	4601                	li	a2,0
    800015b4:	85a6                	mv	a1,s1
    800015b6:	855e                	mv	a0,s7
    800015b8:	985ff0ef          	jal	80000f3c <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    800015bc:	c121                	beqz	a0,800015fc <copyout+0xaa>
    800015be:	611c                	ld	a5,0(a0)
    800015c0:	0157f713          	andi	a4,a5,21
    800015c4:	05971b63          	bne	a4,s9,8000161a <copyout+0xc8>
    n = PGSIZE - (dstva - va0);
    800015c8:	01a48a33          	add	s4,s1,s10
    800015cc:	415a0933          	sub	s2,s4,s5
    if(n > len)
    800015d0:	fb29fee3          	bgeu	s3,s2,8000158c <copyout+0x3a>
    800015d4:	894e                	mv	s2,s3
    800015d6:	bf5d                	j	8000158c <copyout+0x3a>
    dstva = va0 + PGSIZE;
  }
  return 0;
    800015d8:	4501                	li	a0,0
    800015da:	6906                	ld	s2,64(sp)
    800015dc:	7a42                	ld	s4,48(sp)
    800015de:	6c42                	ld	s8,16(sp)
    800015e0:	6ca2                	ld	s9,8(sp)
    800015e2:	6d02                	ld	s10,0(sp)
    800015e4:	a015                	j	80001608 <copyout+0xb6>
    800015e6:	4501                	li	a0,0
}
    800015e8:	8082                	ret
      return -1;
    800015ea:	557d                	li	a0,-1
    800015ec:	a831                	j	80001608 <copyout+0xb6>
    800015ee:	557d                	li	a0,-1
    800015f0:	6906                	ld	s2,64(sp)
    800015f2:	7a42                	ld	s4,48(sp)
    800015f4:	6c42                	ld	s8,16(sp)
    800015f6:	6ca2                	ld	s9,8(sp)
    800015f8:	6d02                	ld	s10,0(sp)
    800015fa:	a039                	j	80001608 <copyout+0xb6>
      return -1;
    800015fc:	557d                	li	a0,-1
    800015fe:	6906                	ld	s2,64(sp)
    80001600:	7a42                	ld	s4,48(sp)
    80001602:	6c42                	ld	s8,16(sp)
    80001604:	6ca2                	ld	s9,8(sp)
    80001606:	6d02                	ld	s10,0(sp)
}
    80001608:	60e6                	ld	ra,88(sp)
    8000160a:	6446                	ld	s0,80(sp)
    8000160c:	64a6                	ld	s1,72(sp)
    8000160e:	79e2                	ld	s3,56(sp)
    80001610:	7aa2                	ld	s5,40(sp)
    80001612:	7b02                	ld	s6,32(sp)
    80001614:	6be2                	ld	s7,24(sp)
    80001616:	6125                	addi	sp,sp,96
    80001618:	8082                	ret
      return -1;
    8000161a:	557d                	li	a0,-1
    8000161c:	6906                	ld	s2,64(sp)
    8000161e:	7a42                	ld	s4,48(sp)
    80001620:	6c42                	ld	s8,16(sp)
    80001622:	6ca2                	ld	s9,8(sp)
    80001624:	6d02                	ld	s10,0(sp)
    80001626:	b7cd                	j	80001608 <copyout+0xb6>

0000000080001628 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80001628:	c6a5                	beqz	a3,80001690 <copyin+0x68>
{
    8000162a:	715d                	addi	sp,sp,-80
    8000162c:	e486                	sd	ra,72(sp)
    8000162e:	e0a2                	sd	s0,64(sp)
    80001630:	fc26                	sd	s1,56(sp)
    80001632:	f84a                	sd	s2,48(sp)
    80001634:	f44e                	sd	s3,40(sp)
    80001636:	f052                	sd	s4,32(sp)
    80001638:	ec56                	sd	s5,24(sp)
    8000163a:	e85a                	sd	s6,16(sp)
    8000163c:	e45e                	sd	s7,8(sp)
    8000163e:	e062                	sd	s8,0(sp)
    80001640:	0880                	addi	s0,sp,80
    80001642:	8b2a                	mv	s6,a0
    80001644:	8a2e                	mv	s4,a1
    80001646:	8c32                	mv	s8,a2
    80001648:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    8000164a:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000164c:	6a85                	lui	s5,0x1
    8000164e:	a00d                	j	80001670 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001650:	018505b3          	add	a1,a0,s8
    80001654:	0004861b          	sext.w	a2,s1
    80001658:	412585b3          	sub	a1,a1,s2
    8000165c:	8552                	mv	a0,s4
    8000165e:	ec6ff0ef          	jal	80000d24 <memmove>

    len -= n;
    80001662:	409989b3          	sub	s3,s3,s1
    dst += n;
    80001666:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80001668:	01590c33          	add	s8,s2,s5
  while(len > 0){
    8000166c:	02098063          	beqz	s3,8000168c <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80001670:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80001674:	85ca                	mv	a1,s2
    80001676:	855a                	mv	a0,s6
    80001678:	95fff0ef          	jal	80000fd6 <walkaddr>
    if(pa0 == 0)
    8000167c:	cd01                	beqz	a0,80001694 <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    8000167e:	418904b3          	sub	s1,s2,s8
    80001682:	94d6                	add	s1,s1,s5
    if(n > len)
    80001684:	fc99f6e3          	bgeu	s3,s1,80001650 <copyin+0x28>
    80001688:	84ce                	mv	s1,s3
    8000168a:	b7d9                	j	80001650 <copyin+0x28>
  }
  return 0;
    8000168c:	4501                	li	a0,0
    8000168e:	a021                	j	80001696 <copyin+0x6e>
    80001690:	4501                	li	a0,0
}
    80001692:	8082                	ret
      return -1;
    80001694:	557d                	li	a0,-1
}
    80001696:	60a6                	ld	ra,72(sp)
    80001698:	6406                	ld	s0,64(sp)
    8000169a:	74e2                	ld	s1,56(sp)
    8000169c:	7942                	ld	s2,48(sp)
    8000169e:	79a2                	ld	s3,40(sp)
    800016a0:	7a02                	ld	s4,32(sp)
    800016a2:	6ae2                	ld	s5,24(sp)
    800016a4:	6b42                	ld	s6,16(sp)
    800016a6:	6ba2                	ld	s7,8(sp)
    800016a8:	6c02                	ld	s8,0(sp)
    800016aa:	6161                	addi	sp,sp,80
    800016ac:	8082                	ret

00000000800016ae <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800016ae:	c6dd                	beqz	a3,8000175c <copyinstr+0xae>
{
    800016b0:	715d                	addi	sp,sp,-80
    800016b2:	e486                	sd	ra,72(sp)
    800016b4:	e0a2                	sd	s0,64(sp)
    800016b6:	fc26                	sd	s1,56(sp)
    800016b8:	f84a                	sd	s2,48(sp)
    800016ba:	f44e                	sd	s3,40(sp)
    800016bc:	f052                	sd	s4,32(sp)
    800016be:	ec56                	sd	s5,24(sp)
    800016c0:	e85a                	sd	s6,16(sp)
    800016c2:	e45e                	sd	s7,8(sp)
    800016c4:	0880                	addi	s0,sp,80
    800016c6:	8a2a                	mv	s4,a0
    800016c8:	8b2e                	mv	s6,a1
    800016ca:	8bb2                	mv	s7,a2
    800016cc:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    800016ce:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800016d0:	6985                	lui	s3,0x1
    800016d2:	a825                	j	8000170a <copyinstr+0x5c>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800016d4:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800016d8:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800016da:	37fd                	addiw	a5,a5,-1
    800016dc:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800016e0:	60a6                	ld	ra,72(sp)
    800016e2:	6406                	ld	s0,64(sp)
    800016e4:	74e2                	ld	s1,56(sp)
    800016e6:	7942                	ld	s2,48(sp)
    800016e8:	79a2                	ld	s3,40(sp)
    800016ea:	7a02                	ld	s4,32(sp)
    800016ec:	6ae2                	ld	s5,24(sp)
    800016ee:	6b42                	ld	s6,16(sp)
    800016f0:	6ba2                	ld	s7,8(sp)
    800016f2:	6161                	addi	sp,sp,80
    800016f4:	8082                	ret
    800016f6:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800016fa:	9742                	add	a4,a4,a6
      --max;
    800016fc:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    80001700:	01348bb3          	add	s7,s1,s3
  while(got_null == 0 && max > 0){
    80001704:	04e58463          	beq	a1,a4,8000174c <copyinstr+0x9e>
{
    80001708:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    8000170a:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    8000170e:	85a6                	mv	a1,s1
    80001710:	8552                	mv	a0,s4
    80001712:	8c5ff0ef          	jal	80000fd6 <walkaddr>
    if(pa0 == 0)
    80001716:	cd0d                	beqz	a0,80001750 <copyinstr+0xa2>
    n = PGSIZE - (srcva - va0);
    80001718:	417486b3          	sub	a3,s1,s7
    8000171c:	96ce                	add	a3,a3,s3
    if(n > max)
    8000171e:	00d97363          	bgeu	s2,a3,80001724 <copyinstr+0x76>
    80001722:	86ca                	mv	a3,s2
    char *p = (char *) (pa0 + (srcva - va0));
    80001724:	955e                	add	a0,a0,s7
    80001726:	8d05                	sub	a0,a0,s1
    while(n > 0){
    80001728:	c695                	beqz	a3,80001754 <copyinstr+0xa6>
    8000172a:	87da                	mv	a5,s6
    8000172c:	885a                	mv	a6,s6
      if(*p == '\0'){
    8000172e:	41650633          	sub	a2,a0,s6
    while(n > 0){
    80001732:	96da                	add	a3,a3,s6
    80001734:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001736:	00f60733          	add	a4,a2,a5
    8000173a:	00074703          	lbu	a4,0(a4)
    8000173e:	db59                	beqz	a4,800016d4 <copyinstr+0x26>
        *dst = *p;
    80001740:	00e78023          	sb	a4,0(a5)
      dst++;
    80001744:	0785                	addi	a5,a5,1
    while(n > 0){
    80001746:	fed797e3          	bne	a5,a3,80001734 <copyinstr+0x86>
    8000174a:	b775                	j	800016f6 <copyinstr+0x48>
    8000174c:	4781                	li	a5,0
    8000174e:	b771                	j	800016da <copyinstr+0x2c>
      return -1;
    80001750:	557d                	li	a0,-1
    80001752:	b779                	j	800016e0 <copyinstr+0x32>
    srcva = va0 + PGSIZE;
    80001754:	6b85                	lui	s7,0x1
    80001756:	9ba6                	add	s7,s7,s1
    80001758:	87da                	mv	a5,s6
    8000175a:	b77d                	j	80001708 <copyinstr+0x5a>
  int got_null = 0;
    8000175c:	4781                	li	a5,0
  if(got_null){
    8000175e:	37fd                	addiw	a5,a5,-1
    80001760:	0007851b          	sext.w	a0,a5
}
    80001764:	8082                	ret

0000000080001766 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001766:	7139                	addi	sp,sp,-64
    80001768:	fc06                	sd	ra,56(sp)
    8000176a:	f822                	sd	s0,48(sp)
    8000176c:	f426                	sd	s1,40(sp)
    8000176e:	f04a                	sd	s2,32(sp)
    80001770:	ec4e                	sd	s3,24(sp)
    80001772:	e852                	sd	s4,16(sp)
    80001774:	e456                	sd	s5,8(sp)
    80001776:	e05a                	sd	s6,0(sp)
    80001778:	0080                	addi	s0,sp,64
    8000177a:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    8000177c:	00011497          	auipc	s1,0x11
    80001780:	10448493          	addi	s1,s1,260 # 80012880 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80001784:	8b26                	mv	s6,s1
    80001786:	00a36937          	lui	s2,0xa36
    8000178a:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    8000178e:	0932                	slli	s2,s2,0xc
    80001790:	46d90913          	addi	s2,s2,1133
    80001794:	0936                	slli	s2,s2,0xd
    80001796:	df590913          	addi	s2,s2,-523
    8000179a:	093a                	slli	s2,s2,0xe
    8000179c:	6cf90913          	addi	s2,s2,1743
    800017a0:	040009b7          	lui	s3,0x4000
    800017a4:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017a6:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800017a8:	00017a97          	auipc	s5,0x17
    800017ac:	ed8a8a93          	addi	s5,s5,-296 # 80018680 <tickslock>
    char *pa = kalloc();
    800017b0:	b74ff0ef          	jal	80000b24 <kalloc>
    800017b4:	862a                	mv	a2,a0
    if(pa == 0)
    800017b6:	cd15                	beqz	a0,800017f2 <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int) (p - proc));
    800017b8:	416485b3          	sub	a1,s1,s6
    800017bc:	858d                	srai	a1,a1,0x3
    800017be:	032585b3          	mul	a1,a1,s2
    800017c2:	2585                	addiw	a1,a1,1
    800017c4:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017c8:	4719                	li	a4,6
    800017ca:	6685                	lui	a3,0x1
    800017cc:	40b985b3          	sub	a1,s3,a1
    800017d0:	8552                	mv	a0,s4
    800017d2:	8f3ff0ef          	jal	800010c4 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    800017d6:	17848493          	addi	s1,s1,376
    800017da:	fd549be3          	bne	s1,s5,800017b0 <proc_mapstacks+0x4a>
  }
}
    800017de:	70e2                	ld	ra,56(sp)
    800017e0:	7442                	ld	s0,48(sp)
    800017e2:	74a2                	ld	s1,40(sp)
    800017e4:	7902                	ld	s2,32(sp)
    800017e6:	69e2                	ld	s3,24(sp)
    800017e8:	6a42                	ld	s4,16(sp)
    800017ea:	6aa2                	ld	s5,8(sp)
    800017ec:	6b02                	ld	s6,0(sp)
    800017ee:	6121                	addi	sp,sp,64
    800017f0:	8082                	ret
      panic("kalloc");
    800017f2:	00006517          	auipc	a0,0x6
    800017f6:	a0650513          	addi	a0,a0,-1530 # 800071f8 <etext+0x1f8>
    800017fa:	f9bfe0ef          	jal	80000794 <panic>

00000000800017fe <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017fe:	7139                	addi	sp,sp,-64
    80001800:	fc06                	sd	ra,56(sp)
    80001802:	f822                	sd	s0,48(sp)
    80001804:	f426                	sd	s1,40(sp)
    80001806:	f04a                	sd	s2,32(sp)
    80001808:	ec4e                	sd	s3,24(sp)
    8000180a:	e852                	sd	s4,16(sp)
    8000180c:	e456                	sd	s5,8(sp)
    8000180e:	e05a                	sd	s6,0(sp)
    80001810:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001812:	00006597          	auipc	a1,0x6
    80001816:	9ee58593          	addi	a1,a1,-1554 # 80007200 <etext+0x200>
    8000181a:	00011517          	auipc	a0,0x11
    8000181e:	c3650513          	addi	a0,a0,-970 # 80012450 <pid_lock>
    80001822:	b52ff0ef          	jal	80000b74 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001826:	00006597          	auipc	a1,0x6
    8000182a:	9e258593          	addi	a1,a1,-1566 # 80007208 <etext+0x208>
    8000182e:	00011517          	auipc	a0,0x11
    80001832:	c3a50513          	addi	a0,a0,-966 # 80012468 <wait_lock>
    80001836:	b3eff0ef          	jal	80000b74 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000183a:	00011497          	auipc	s1,0x11
    8000183e:	04648493          	addi	s1,s1,70 # 80012880 <proc>
      initlock(&p->lock, "proc");
    80001842:	00006b17          	auipc	s6,0x6
    80001846:	9d6b0b13          	addi	s6,s6,-1578 # 80007218 <etext+0x218>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    8000184a:	8aa6                	mv	s5,s1
    8000184c:	00a36937          	lui	s2,0xa36
    80001850:	77d90913          	addi	s2,s2,1917 # a3677d <_entry-0x7f5c9883>
    80001854:	0932                	slli	s2,s2,0xc
    80001856:	46d90913          	addi	s2,s2,1133
    8000185a:	0936                	slli	s2,s2,0xd
    8000185c:	df590913          	addi	s2,s2,-523
    80001860:	093a                	slli	s2,s2,0xe
    80001862:	6cf90913          	addi	s2,s2,1743
    80001866:	040009b7          	lui	s3,0x4000
    8000186a:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000186c:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    8000186e:	00017a17          	auipc	s4,0x17
    80001872:	e12a0a13          	addi	s4,s4,-494 # 80018680 <tickslock>
      initlock(&p->lock, "proc");
    80001876:	85da                	mv	a1,s6
    80001878:	8526                	mv	a0,s1
    8000187a:	afaff0ef          	jal	80000b74 <initlock>
      p->state = UNUSED;
    8000187e:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001882:	415487b3          	sub	a5,s1,s5
    80001886:	878d                	srai	a5,a5,0x3
    80001888:	032787b3          	mul	a5,a5,s2
    8000188c:	2785                	addiw	a5,a5,1
    8000188e:	00d7979b          	slliw	a5,a5,0xd
    80001892:	40f987b3          	sub	a5,s3,a5
    80001896:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001898:	17848493          	addi	s1,s1,376
    8000189c:	fd449de3          	bne	s1,s4,80001876 <procinit+0x78>
  }
}
    800018a0:	70e2                	ld	ra,56(sp)
    800018a2:	7442                	ld	s0,48(sp)
    800018a4:	74a2                	ld	s1,40(sp)
    800018a6:	7902                	ld	s2,32(sp)
    800018a8:	69e2                	ld	s3,24(sp)
    800018aa:	6a42                	ld	s4,16(sp)
    800018ac:	6aa2                	ld	s5,8(sp)
    800018ae:	6b02                	ld	s6,0(sp)
    800018b0:	6121                	addi	sp,sp,64
    800018b2:	8082                	ret

00000000800018b4 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018b4:	1141                	addi	sp,sp,-16
    800018b6:	e422                	sd	s0,8(sp)
    800018b8:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800018ba:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018bc:	2501                	sext.w	a0,a0
    800018be:	6422                	ld	s0,8(sp)
    800018c0:	0141                	addi	sp,sp,16
    800018c2:	8082                	ret

00000000800018c4 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800018c4:	1141                	addi	sp,sp,-16
    800018c6:	e422                	sd	s0,8(sp)
    800018c8:	0800                	addi	s0,sp,16
    800018ca:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018cc:	2781                	sext.w	a5,a5
    800018ce:	079e                	slli	a5,a5,0x7
  return c;
}
    800018d0:	00011517          	auipc	a0,0x11
    800018d4:	bb050513          	addi	a0,a0,-1104 # 80012480 <cpus>
    800018d8:	953e                	add	a0,a0,a5
    800018da:	6422                	ld	s0,8(sp)
    800018dc:	0141                	addi	sp,sp,16
    800018de:	8082                	ret

00000000800018e0 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    800018e0:	1101                	addi	sp,sp,-32
    800018e2:	ec06                	sd	ra,24(sp)
    800018e4:	e822                	sd	s0,16(sp)
    800018e6:	e426                	sd	s1,8(sp)
    800018e8:	1000                	addi	s0,sp,32
  push_off();
    800018ea:	acaff0ef          	jal	80000bb4 <push_off>
    800018ee:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018f0:	2781                	sext.w	a5,a5
    800018f2:	079e                	slli	a5,a5,0x7
    800018f4:	00011717          	auipc	a4,0x11
    800018f8:	b5c70713          	addi	a4,a4,-1188 # 80012450 <pid_lock>
    800018fc:	97ba                	add	a5,a5,a4
    800018fe:	7b84                	ld	s1,48(a5)
  pop_off();
    80001900:	b38ff0ef          	jal	80000c38 <pop_off>
  return p;
}
    80001904:	8526                	mv	a0,s1
    80001906:	60e2                	ld	ra,24(sp)
    80001908:	6442                	ld	s0,16(sp)
    8000190a:	64a2                	ld	s1,8(sp)
    8000190c:	6105                	addi	sp,sp,32
    8000190e:	8082                	ret

0000000080001910 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001910:	1141                	addi	sp,sp,-16
    80001912:	e406                	sd	ra,8(sp)
    80001914:	e022                	sd	s0,0(sp)
    80001916:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80001918:	fc9ff0ef          	jal	800018e0 <myproc>
    8000191c:	b70ff0ef          	jal	80000c8c <release>

  if (first) {
    80001920:	00009797          	auipc	a5,0x9
    80001924:	9607a783          	lw	a5,-1696(a5) # 8000a280 <first.1>
    80001928:	e799                	bnez	a5,80001936 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    8000192a:	431000ef          	jal	8000255a <usertrapret>
}
    8000192e:	60a2                	ld	ra,8(sp)
    80001930:	6402                	ld	s0,0(sp)
    80001932:	0141                	addi	sp,sp,16
    80001934:	8082                	ret
    fsinit(ROOTDEV);
    80001936:	4505                	li	a0,1
    80001938:	7fc010ef          	jal	80003134 <fsinit>
    first = 0;
    8000193c:	00009797          	auipc	a5,0x9
    80001940:	9407a223          	sw	zero,-1724(a5) # 8000a280 <first.1>
    __sync_synchronize();
    80001944:	0330000f          	fence	rw,rw
    80001948:	b7cd                	j	8000192a <forkret+0x1a>

000000008000194a <allocpid>:
{
    8000194a:	1101                	addi	sp,sp,-32
    8000194c:	ec06                	sd	ra,24(sp)
    8000194e:	e822                	sd	s0,16(sp)
    80001950:	e426                	sd	s1,8(sp)
    80001952:	e04a                	sd	s2,0(sp)
    80001954:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001956:	00011917          	auipc	s2,0x11
    8000195a:	afa90913          	addi	s2,s2,-1286 # 80012450 <pid_lock>
    8000195e:	854a                	mv	a0,s2
    80001960:	a94ff0ef          	jal	80000bf4 <acquire>
  pid = nextpid;
    80001964:	00009797          	auipc	a5,0x9
    80001968:	92478793          	addi	a5,a5,-1756 # 8000a288 <nextpid>
    8000196c:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    8000196e:	0014871b          	addiw	a4,s1,1
    80001972:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001974:	854a                	mv	a0,s2
    80001976:	b16ff0ef          	jal	80000c8c <release>
}
    8000197a:	8526                	mv	a0,s1
    8000197c:	60e2                	ld	ra,24(sp)
    8000197e:	6442                	ld	s0,16(sp)
    80001980:	64a2                	ld	s1,8(sp)
    80001982:	6902                	ld	s2,0(sp)
    80001984:	6105                	addi	sp,sp,32
    80001986:	8082                	ret

0000000080001988 <proc_pagetable>:
{
    80001988:	1101                	addi	sp,sp,-32
    8000198a:	ec06                	sd	ra,24(sp)
    8000198c:	e822                	sd	s0,16(sp)
    8000198e:	e426                	sd	s1,8(sp)
    80001990:	e04a                	sd	s2,0(sp)
    80001992:	1000                	addi	s0,sp,32
    80001994:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001996:	8e1ff0ef          	jal	80001276 <uvmcreate>
    8000199a:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000199c:	cd05                	beqz	a0,800019d4 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    8000199e:	4729                	li	a4,10
    800019a0:	00004697          	auipc	a3,0x4
    800019a4:	66068693          	addi	a3,a3,1632 # 80006000 <_trampoline>
    800019a8:	6605                	lui	a2,0x1
    800019aa:	040005b7          	lui	a1,0x4000
    800019ae:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019b0:	05b2                	slli	a1,a1,0xc
    800019b2:	e62ff0ef          	jal	80001014 <mappages>
    800019b6:	02054663          	bltz	a0,800019e2 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    800019ba:	4719                	li	a4,6
    800019bc:	05893683          	ld	a3,88(s2)
    800019c0:	6605                	lui	a2,0x1
    800019c2:	020005b7          	lui	a1,0x2000
    800019c6:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    800019c8:	05b6                	slli	a1,a1,0xd
    800019ca:	8526                	mv	a0,s1
    800019cc:	e48ff0ef          	jal	80001014 <mappages>
    800019d0:	00054f63          	bltz	a0,800019ee <proc_pagetable+0x66>
}
    800019d4:	8526                	mv	a0,s1
    800019d6:	60e2                	ld	ra,24(sp)
    800019d8:	6442                	ld	s0,16(sp)
    800019da:	64a2                	ld	s1,8(sp)
    800019dc:	6902                	ld	s2,0(sp)
    800019de:	6105                	addi	sp,sp,32
    800019e0:	8082                	ret
    uvmfree(pagetable, 0);
    800019e2:	4581                	li	a1,0
    800019e4:	8526                	mv	a0,s1
    800019e6:	a5fff0ef          	jal	80001444 <uvmfree>
    return 0;
    800019ea:	4481                	li	s1,0
    800019ec:	b7e5                	j	800019d4 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    800019ee:	4681                	li	a3,0
    800019f0:	4605                	li	a2,1
    800019f2:	040005b7          	lui	a1,0x4000
    800019f6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019f8:	05b2                	slli	a1,a1,0xc
    800019fa:	8526                	mv	a0,s1
    800019fc:	fbeff0ef          	jal	800011ba <uvmunmap>
    uvmfree(pagetable, 0);
    80001a00:	4581                	li	a1,0
    80001a02:	8526                	mv	a0,s1
    80001a04:	a41ff0ef          	jal	80001444 <uvmfree>
    return 0;
    80001a08:	4481                	li	s1,0
    80001a0a:	b7e9                	j	800019d4 <proc_pagetable+0x4c>

0000000080001a0c <proc_freepagetable>:
{
    80001a0c:	1101                	addi	sp,sp,-32
    80001a0e:	ec06                	sd	ra,24(sp)
    80001a10:	e822                	sd	s0,16(sp)
    80001a12:	e426                	sd	s1,8(sp)
    80001a14:	e04a                	sd	s2,0(sp)
    80001a16:	1000                	addi	s0,sp,32
    80001a18:	84aa                	mv	s1,a0
    80001a1a:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a1c:	4681                	li	a3,0
    80001a1e:	4605                	li	a2,1
    80001a20:	040005b7          	lui	a1,0x4000
    80001a24:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a26:	05b2                	slli	a1,a1,0xc
    80001a28:	f92ff0ef          	jal	800011ba <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a2c:	4681                	li	a3,0
    80001a2e:	4605                	li	a2,1
    80001a30:	020005b7          	lui	a1,0x2000
    80001a34:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a36:	05b6                	slli	a1,a1,0xd
    80001a38:	8526                	mv	a0,s1
    80001a3a:	f80ff0ef          	jal	800011ba <uvmunmap>
  uvmfree(pagetable, sz);
    80001a3e:	85ca                	mv	a1,s2
    80001a40:	8526                	mv	a0,s1
    80001a42:	a03ff0ef          	jal	80001444 <uvmfree>
}
    80001a46:	60e2                	ld	ra,24(sp)
    80001a48:	6442                	ld	s0,16(sp)
    80001a4a:	64a2                	ld	s1,8(sp)
    80001a4c:	6902                	ld	s2,0(sp)
    80001a4e:	6105                	addi	sp,sp,32
    80001a50:	8082                	ret

0000000080001a52 <freeproc>:
{
    80001a52:	1101                	addi	sp,sp,-32
    80001a54:	ec06                	sd	ra,24(sp)
    80001a56:	e822                	sd	s0,16(sp)
    80001a58:	e426                	sd	s1,8(sp)
    80001a5a:	1000                	addi	s0,sp,32
    80001a5c:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001a5e:	6d28                	ld	a0,88(a0)
    80001a60:	c119                	beqz	a0,80001a66 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001a62:	fe1fe0ef          	jal	80000a42 <kfree>
  p->trapframe = 0;
    80001a66:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001a6a:	68a8                	ld	a0,80(s1)
    80001a6c:	c501                	beqz	a0,80001a74 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001a6e:	64ac                	ld	a1,72(s1)
    80001a70:	f9dff0ef          	jal	80001a0c <proc_freepagetable>
  p->pagetable = 0;
    80001a74:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001a78:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001a7c:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001a80:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001a84:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001a88:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001a8c:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001a90:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001a94:	0004ac23          	sw	zero,24(s1)
  p->tickets = 0;
    80001a98:	1604a423          	sw	zero,360(s1)
  p->ticks = 0;
    80001a9c:	1604a623          	sw	zero,364(s1)
  p->stride = 0;
    80001aa0:	1604a823          	sw	zero,368(s1)
  p->pass = 0;
    80001aa4:	1604aa23          	sw	zero,372(s1)
}
    80001aa8:	60e2                	ld	ra,24(sp)
    80001aaa:	6442                	ld	s0,16(sp)
    80001aac:	64a2                	ld	s1,8(sp)
    80001aae:	6105                	addi	sp,sp,32
    80001ab0:	8082                	ret

0000000080001ab2 <allocproc>:
{
    80001ab2:	1101                	addi	sp,sp,-32
    80001ab4:	ec06                	sd	ra,24(sp)
    80001ab6:	e822                	sd	s0,16(sp)
    80001ab8:	e426                	sd	s1,8(sp)
    80001aba:	e04a                	sd	s2,0(sp)
    80001abc:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001abe:	00011497          	auipc	s1,0x11
    80001ac2:	dc248493          	addi	s1,s1,-574 # 80012880 <proc>
    80001ac6:	00017917          	auipc	s2,0x17
    80001aca:	bba90913          	addi	s2,s2,-1094 # 80018680 <tickslock>
    acquire(&p->lock);
    80001ace:	8526                	mv	a0,s1
    80001ad0:	924ff0ef          	jal	80000bf4 <acquire>
    if(p->state == UNUSED) {
    80001ad4:	4c9c                	lw	a5,24(s1)
    80001ad6:	cb91                	beqz	a5,80001aea <allocproc+0x38>
      release(&p->lock);
    80001ad8:	8526                	mv	a0,s1
    80001ada:	9b2ff0ef          	jal	80000c8c <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ade:	17848493          	addi	s1,s1,376
    80001ae2:	ff2496e3          	bne	s1,s2,80001ace <allocproc+0x1c>
  return 0;
    80001ae6:	4481                	li	s1,0
    80001ae8:	a8a1                	j	80001b40 <allocproc+0x8e>
  p->pid = allocpid();
    80001aea:	e61ff0ef          	jal	8000194a <allocpid>
    80001aee:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001af0:	4785                	li	a5,1
    80001af2:	cc9c                	sw	a5,24(s1)
  p->tickets = 10000;
    80001af4:	6709                	lui	a4,0x2
    80001af6:	71070713          	addi	a4,a4,1808 # 2710 <_entry-0x7fffd8f0>
    80001afa:	16e4a423          	sw	a4,360(s1)
  p->ticks = 0;
    80001afe:	1604a623          	sw	zero,364(s1)
  p->stride = 10000/p->tickets;
    80001b02:	16f4a823          	sw	a5,368(s1)
  p->pass = p->stride;
    80001b06:	16f4aa23          	sw	a5,372(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b0a:	81aff0ef          	jal	80000b24 <kalloc>
    80001b0e:	892a                	mv	s2,a0
    80001b10:	eca8                	sd	a0,88(s1)
    80001b12:	cd15                	beqz	a0,80001b4e <allocproc+0x9c>
  p->pagetable = proc_pagetable(p);
    80001b14:	8526                	mv	a0,s1
    80001b16:	e73ff0ef          	jal	80001988 <proc_pagetable>
    80001b1a:	892a                	mv	s2,a0
    80001b1c:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b1e:	c121                	beqz	a0,80001b5e <allocproc+0xac>
  memset(&p->context, 0, sizeof(p->context));
    80001b20:	07000613          	li	a2,112
    80001b24:	4581                	li	a1,0
    80001b26:	06048513          	addi	a0,s1,96
    80001b2a:	99eff0ef          	jal	80000cc8 <memset>
  p->context.ra = (uint64)forkret;
    80001b2e:	00000797          	auipc	a5,0x0
    80001b32:	de278793          	addi	a5,a5,-542 # 80001910 <forkret>
    80001b36:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b38:	60bc                	ld	a5,64(s1)
    80001b3a:	6705                	lui	a4,0x1
    80001b3c:	97ba                	add	a5,a5,a4
    80001b3e:	f4bc                	sd	a5,104(s1)
}
    80001b40:	8526                	mv	a0,s1
    80001b42:	60e2                	ld	ra,24(sp)
    80001b44:	6442                	ld	s0,16(sp)
    80001b46:	64a2                	ld	s1,8(sp)
    80001b48:	6902                	ld	s2,0(sp)
    80001b4a:	6105                	addi	sp,sp,32
    80001b4c:	8082                	ret
    freeproc(p);
    80001b4e:	8526                	mv	a0,s1
    80001b50:	f03ff0ef          	jal	80001a52 <freeproc>
    release(&p->lock);
    80001b54:	8526                	mv	a0,s1
    80001b56:	936ff0ef          	jal	80000c8c <release>
    return 0;
    80001b5a:	84ca                	mv	s1,s2
    80001b5c:	b7d5                	j	80001b40 <allocproc+0x8e>
    freeproc(p);
    80001b5e:	8526                	mv	a0,s1
    80001b60:	ef3ff0ef          	jal	80001a52 <freeproc>
    release(&p->lock);
    80001b64:	8526                	mv	a0,s1
    80001b66:	926ff0ef          	jal	80000c8c <release>
    return 0;
    80001b6a:	84ca                	mv	s1,s2
    80001b6c:	bfd1                	j	80001b40 <allocproc+0x8e>

0000000080001b6e <userinit>:
{
    80001b6e:	1101                	addi	sp,sp,-32
    80001b70:	ec06                	sd	ra,24(sp)
    80001b72:	e822                	sd	s0,16(sp)
    80001b74:	e426                	sd	s1,8(sp)
    80001b76:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b78:	f3bff0ef          	jal	80001ab2 <allocproc>
    80001b7c:	84aa                	mv	s1,a0
  initproc = p;
    80001b7e:	00008797          	auipc	a5,0x8
    80001b82:	7aa7b123          	sd	a0,1954(a5) # 8000a320 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001b86:	03400613          	li	a2,52
    80001b8a:	00008597          	auipc	a1,0x8
    80001b8e:	70658593          	addi	a1,a1,1798 # 8000a290 <initcode>
    80001b92:	6928                	ld	a0,80(a0)
    80001b94:	f08ff0ef          	jal	8000129c <uvmfirst>
  p->sz = PGSIZE;
    80001b98:	6785                	lui	a5,0x1
    80001b9a:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001b9c:	6cb8                	ld	a4,88(s1)
    80001b9e:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001ba2:	6cb8                	ld	a4,88(s1)
    80001ba4:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001ba6:	4641                	li	a2,16
    80001ba8:	00005597          	auipc	a1,0x5
    80001bac:	67858593          	addi	a1,a1,1656 # 80007220 <etext+0x220>
    80001bb0:	15848513          	addi	a0,s1,344
    80001bb4:	a52ff0ef          	jal	80000e06 <safestrcpy>
  p->cwd = namei("/");
    80001bb8:	00005517          	auipc	a0,0x5
    80001bbc:	67850513          	addi	a0,a0,1656 # 80007230 <etext+0x230>
    80001bc0:	683010ef          	jal	80003a42 <namei>
    80001bc4:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bc8:	478d                	li	a5,3
    80001bca:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bcc:	8526                	mv	a0,s1
    80001bce:	8beff0ef          	jal	80000c8c <release>
}
    80001bd2:	60e2                	ld	ra,24(sp)
    80001bd4:	6442                	ld	s0,16(sp)
    80001bd6:	64a2                	ld	s1,8(sp)
    80001bd8:	6105                	addi	sp,sp,32
    80001bda:	8082                	ret

0000000080001bdc <growproc>:
{
    80001bdc:	1101                	addi	sp,sp,-32
    80001bde:	ec06                	sd	ra,24(sp)
    80001be0:	e822                	sd	s0,16(sp)
    80001be2:	e426                	sd	s1,8(sp)
    80001be4:	e04a                	sd	s2,0(sp)
    80001be6:	1000                	addi	s0,sp,32
    80001be8:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001bea:	cf7ff0ef          	jal	800018e0 <myproc>
    80001bee:	84aa                	mv	s1,a0
  sz = p->sz;
    80001bf0:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001bf2:	01204c63          	bgtz	s2,80001c0a <growproc+0x2e>
  } else if(n < 0){
    80001bf6:	02094463          	bltz	s2,80001c1e <growproc+0x42>
  p->sz = sz;
    80001bfa:	e4ac                	sd	a1,72(s1)
  return 0;
    80001bfc:	4501                	li	a0,0
}
    80001bfe:	60e2                	ld	ra,24(sp)
    80001c00:	6442                	ld	s0,16(sp)
    80001c02:	64a2                	ld	s1,8(sp)
    80001c04:	6902                	ld	s2,0(sp)
    80001c06:	6105                	addi	sp,sp,32
    80001c08:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c0a:	4691                	li	a3,4
    80001c0c:	00b90633          	add	a2,s2,a1
    80001c10:	6928                	ld	a0,80(a0)
    80001c12:	f2cff0ef          	jal	8000133e <uvmalloc>
    80001c16:	85aa                	mv	a1,a0
    80001c18:	f16d                	bnez	a0,80001bfa <growproc+0x1e>
      return -1;
    80001c1a:	557d                	li	a0,-1
    80001c1c:	b7cd                	j	80001bfe <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c1e:	00b90633          	add	a2,s2,a1
    80001c22:	6928                	ld	a0,80(a0)
    80001c24:	ed6ff0ef          	jal	800012fa <uvmdealloc>
    80001c28:	85aa                	mv	a1,a0
    80001c2a:	bfc1                	j	80001bfa <growproc+0x1e>

0000000080001c2c <fork>:
{
    80001c2c:	7139                	addi	sp,sp,-64
    80001c2e:	fc06                	sd	ra,56(sp)
    80001c30:	f822                	sd	s0,48(sp)
    80001c32:	f04a                	sd	s2,32(sp)
    80001c34:	e456                	sd	s5,8(sp)
    80001c36:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c38:	ca9ff0ef          	jal	800018e0 <myproc>
    80001c3c:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c3e:	e75ff0ef          	jal	80001ab2 <allocproc>
    80001c42:	0e050a63          	beqz	a0,80001d36 <fork+0x10a>
    80001c46:	e852                	sd	s4,16(sp)
    80001c48:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c4a:	048ab603          	ld	a2,72(s5)
    80001c4e:	692c                	ld	a1,80(a0)
    80001c50:	050ab503          	ld	a0,80(s5)
    80001c54:	823ff0ef          	jal	80001476 <uvmcopy>
    80001c58:	04054a63          	bltz	a0,80001cac <fork+0x80>
    80001c5c:	f426                	sd	s1,40(sp)
    80001c5e:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c60:	048ab783          	ld	a5,72(s5)
    80001c64:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c68:	058ab683          	ld	a3,88(s5)
    80001c6c:	87b6                	mv	a5,a3
    80001c6e:	058a3703          	ld	a4,88(s4)
    80001c72:	12068693          	addi	a3,a3,288
    80001c76:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80001c7a:	6788                	ld	a0,8(a5)
    80001c7c:	6b8c                	ld	a1,16(a5)
    80001c7e:	6f90                	ld	a2,24(a5)
    80001c80:	01073023          	sd	a6,0(a4)
    80001c84:	e708                	sd	a0,8(a4)
    80001c86:	eb0c                	sd	a1,16(a4)
    80001c88:	ef10                	sd	a2,24(a4)
    80001c8a:	02078793          	addi	a5,a5,32
    80001c8e:	02070713          	addi	a4,a4,32
    80001c92:	fed792e3          	bne	a5,a3,80001c76 <fork+0x4a>
  np->trapframe->a0 = 0;
    80001c96:	058a3783          	ld	a5,88(s4)
    80001c9a:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001c9e:	0d0a8493          	addi	s1,s5,208
    80001ca2:	0d0a0913          	addi	s2,s4,208
    80001ca6:	150a8993          	addi	s3,s5,336
    80001caa:	a831                	j	80001cc6 <fork+0x9a>
    freeproc(np);
    80001cac:	8552                	mv	a0,s4
    80001cae:	da5ff0ef          	jal	80001a52 <freeproc>
    release(&np->lock);
    80001cb2:	8552                	mv	a0,s4
    80001cb4:	fd9fe0ef          	jal	80000c8c <release>
    return -1;
    80001cb8:	597d                	li	s2,-1
    80001cba:	6a42                	ld	s4,16(sp)
    80001cbc:	a0b5                	j	80001d28 <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001cbe:	04a1                	addi	s1,s1,8
    80001cc0:	0921                	addi	s2,s2,8
    80001cc2:	01348963          	beq	s1,s3,80001cd4 <fork+0xa8>
    if(p->ofile[i])
    80001cc6:	6088                	ld	a0,0(s1)
    80001cc8:	d97d                	beqz	a0,80001cbe <fork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001cca:	308020ef          	jal	80003fd2 <filedup>
    80001cce:	00a93023          	sd	a0,0(s2)
    80001cd2:	b7f5                	j	80001cbe <fork+0x92>
  np->cwd = idup(p->cwd);
    80001cd4:	150ab503          	ld	a0,336(s5)
    80001cd8:	65a010ef          	jal	80003332 <idup>
    80001cdc:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001ce0:	4641                	li	a2,16
    80001ce2:	158a8593          	addi	a1,s5,344
    80001ce6:	158a0513          	addi	a0,s4,344
    80001cea:	91cff0ef          	jal	80000e06 <safestrcpy>
  pid = np->pid;
    80001cee:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001cf2:	8552                	mv	a0,s4
    80001cf4:	f99fe0ef          	jal	80000c8c <release>
  acquire(&wait_lock);
    80001cf8:	00010497          	auipc	s1,0x10
    80001cfc:	77048493          	addi	s1,s1,1904 # 80012468 <wait_lock>
    80001d00:	8526                	mv	a0,s1
    80001d02:	ef3fe0ef          	jal	80000bf4 <acquire>
  np->parent = p;
    80001d06:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d0a:	8526                	mv	a0,s1
    80001d0c:	f81fe0ef          	jal	80000c8c <release>
  acquire(&np->lock);
    80001d10:	8552                	mv	a0,s4
    80001d12:	ee3fe0ef          	jal	80000bf4 <acquire>
  np->state = RUNNABLE;
    80001d16:	478d                	li	a5,3
    80001d18:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d1c:	8552                	mv	a0,s4
    80001d1e:	f6ffe0ef          	jal	80000c8c <release>
  return pid;
    80001d22:	74a2                	ld	s1,40(sp)
    80001d24:	69e2                	ld	s3,24(sp)
    80001d26:	6a42                	ld	s4,16(sp)
}
    80001d28:	854a                	mv	a0,s2
    80001d2a:	70e2                	ld	ra,56(sp)
    80001d2c:	7442                	ld	s0,48(sp)
    80001d2e:	7902                	ld	s2,32(sp)
    80001d30:	6aa2                	ld	s5,8(sp)
    80001d32:	6121                	addi	sp,sp,64
    80001d34:	8082                	ret
    return -1;
    80001d36:	597d                	li	s2,-1
    80001d38:	bfc5                	j	80001d28 <fork+0xfc>

0000000080001d3a <rand>:
{
    80001d3a:	1141                	addi	sp,sp,-16
    80001d3c:	e422                	sd	s0,8(sp)
    80001d3e:	0800                	addi	s0,sp,16
bit = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5)) & 1;
    80001d40:	00008717          	auipc	a4,0x8
    80001d44:	54470713          	addi	a4,a4,1348 # 8000a284 <lfsr>
    80001d48:	00075503          	lhu	a0,0(a4)
    80001d4c:	0025579b          	srliw	a5,a0,0x2
    80001d50:	0035569b          	srliw	a3,a0,0x3
    80001d54:	8fb5                	xor	a5,a5,a3
    80001d56:	8fa9                	xor	a5,a5,a0
    80001d58:	0055569b          	srliw	a3,a0,0x5
    80001d5c:	8fb5                	xor	a5,a5,a3
    80001d5e:	8b85                	andi	a5,a5,1
    80001d60:	00008697          	auipc	a3,0x8
    80001d64:	5af69c23          	sh	a5,1464(a3) # 8000a318 <bit>
return lfsr = (lfsr >> 1) | (bit << 15);
    80001d68:	0015551b          	srliw	a0,a0,0x1
    80001d6c:	00f7979b          	slliw	a5,a5,0xf
    80001d70:	8d5d                	or	a0,a0,a5
    80001d72:	1542                	slli	a0,a0,0x30
    80001d74:	9141                	srli	a0,a0,0x30
    80001d76:	00a71023          	sh	a0,0(a4)
}
    80001d7a:	6422                	ld	s0,8(sp)
    80001d7c:	0141                	addi	sp,sp,16
    80001d7e:	8082                	ret

0000000080001d80 <scheduler>:
{
    80001d80:	711d                	addi	sp,sp,-96
    80001d82:	ec86                	sd	ra,88(sp)
    80001d84:	e8a2                	sd	s0,80(sp)
    80001d86:	e4a6                	sd	s1,72(sp)
    80001d88:	e0ca                	sd	s2,64(sp)
    80001d8a:	fc4e                	sd	s3,56(sp)
    80001d8c:	f852                	sd	s4,48(sp)
    80001d8e:	f456                	sd	s5,40(sp)
    80001d90:	f05a                	sd	s6,32(sp)
    80001d92:	ec5e                	sd	s7,24(sp)
    80001d94:	e862                	sd	s8,16(sp)
    80001d96:	e466                	sd	s9,8(sp)
    80001d98:	e06a                	sd	s10,0(sp)
    80001d9a:	1080                	addi	s0,sp,96
    80001d9c:	8792                	mv	a5,tp
  int id = r_tp();
    80001d9e:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001da0:	00779c93          	slli	s9,a5,0x7
    80001da4:	00010717          	auipc	a4,0x10
    80001da8:	6ac70713          	addi	a4,a4,1708 # 80012450 <pid_lock>
    80001dac:	9766                	add	a4,a4,s9
    80001dae:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &selected_proc->context);
    80001db2:	00010717          	auipc	a4,0x10
    80001db6:	6d670713          	addi	a4,a4,1750 # 80012488 <cpus+0x8>
    80001dba:	9cba                	add	s9,s9,a4
    struct proc *selected_proc = 0;
    80001dbc:	4b81                	li	s7,0
    int smallest_pass = INT_MAX;
    80001dbe:	80000b37          	lui	s6,0x80000
    80001dc2:	fffb4b13          	not	s6,s6
      if (p->state == RUNNABLE)
    80001dc6:	490d                	li	s2,3
    for (p = proc; p < &proc[NPROC]; p++)
    80001dc8:	00017997          	auipc	s3,0x17
    80001dcc:	8b898993          	addi	s3,s3,-1864 # 80018680 <tickslock>
        selected_proc->state = RUNNING;
    80001dd0:	4d11                	li	s10,4
        c->proc = selected_proc;
    80001dd2:	079e                	slli	a5,a5,0x7
    80001dd4:	00010c17          	auipc	s8,0x10
    80001dd8:	67cc0c13          	addi	s8,s8,1660 # 80012450 <pid_lock>
    80001ddc:	9c3e                	add	s8,s8,a5
    80001dde:	a061                	j	80001e66 <scheduler+0xe6>
      release(&p->lock);
    80001de0:	8526                	mv	a0,s1
    80001de2:	eabfe0ef          	jal	80000c8c <release>
    for (p = proc; p < &proc[NPROC]; p++)
    80001de6:	17848493          	addi	s1,s1,376
    80001dea:	01348f63          	beq	s1,s3,80001e08 <scheduler+0x88>
      acquire(&p->lock);
    80001dee:	8526                	mv	a0,s1
    80001df0:	e05fe0ef          	jal	80000bf4 <acquire>
      if (p->state == RUNNABLE)
    80001df4:	4c9c                	lw	a5,24(s1)
    80001df6:	ff2795e3          	bne	a5,s2,80001de0 <scheduler+0x60>
        if (p->pass < smallest_pass)
    80001dfa:	1744a783          	lw	a5,372(s1)
    80001dfe:	ff47d1e3          	bge	a5,s4,80001de0 <scheduler+0x60>
          selected_proc = p;
    80001e02:	8aa6                	mv	s5,s1
          smallest_pass = p->pass;
    80001e04:	8a3e                	mv	s4,a5
    80001e06:	bfe9                	j	80001de0 <scheduler+0x60>
    if (selected_proc)
    80001e08:	040a8763          	beqz	s5,80001e56 <scheduler+0xd6>
      acquire(&selected_proc->lock);
    80001e0c:	8556                	mv	a0,s5
    80001e0e:	de7fe0ef          	jal	80000bf4 <acquire>
      if (selected_proc->state == RUNNABLE)
    80001e12:	018aa783          	lw	a5,24(s5)
    80001e16:	03279d63          	bne	a5,s2,80001e50 <scheduler+0xd0>
        selected_proc->state = RUNNING;
    80001e1a:	01aaac23          	sw	s10,24(s5)
        c->proc = selected_proc;
    80001e1e:	035c3823          	sd	s5,48(s8)
        selected_proc->ticks++;
    80001e22:	16caa783          	lw	a5,364(s5)
    80001e26:	2785                	addiw	a5,a5,1
    80001e28:	16faa623          	sw	a5,364(s5)
        swtch(&c->context, &selected_proc->context);
    80001e2c:	060a8593          	addi	a1,s5,96
    80001e30:	8566                	mv	a0,s9
    80001e32:	682000ef          	jal	800024b4 <swtch>
        selected_proc->pass += selected_proc->stride;
    80001e36:	174aa703          	lw	a4,372(s5)
    80001e3a:	170aa783          	lw	a5,368(s5)
    80001e3e:	9fb9                	addw	a5,a5,a4
    80001e40:	16faaa23          	sw	a5,372(s5)
        c->proc = 0;
    80001e44:	020c3823          	sd	zero,48(s8)
        release(&selected_proc->lock);
    80001e48:	8556                	mv	a0,s5
    80001e4a:	e43fe0ef          	jal	80000c8c <release>
    if(found == 0) {
    80001e4e:	a821                	j	80001e66 <scheduler+0xe6>
        release(&selected_proc->lock);
    80001e50:	8556                	mv	a0,s5
    80001e52:	e3bfe0ef          	jal	80000c8c <release>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e56:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e5a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e5e:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    80001e62:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e66:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e6a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e6e:	10079073          	csrw	sstatus,a5
    struct proc *selected_proc = 0;
    80001e72:	8ade                	mv	s5,s7
    int smallest_pass = INT_MAX;
    80001e74:	8a5a                	mv	s4,s6
    for (p = proc; p < &proc[NPROC]; p++)
    80001e76:	00011497          	auipc	s1,0x11
    80001e7a:	a0a48493          	addi	s1,s1,-1526 # 80012880 <proc>
    80001e7e:	bf85                	j	80001dee <scheduler+0x6e>

0000000080001e80 <sched>:
{
    80001e80:	7179                	addi	sp,sp,-48
    80001e82:	f406                	sd	ra,40(sp)
    80001e84:	f022                	sd	s0,32(sp)
    80001e86:	ec26                	sd	s1,24(sp)
    80001e88:	e84a                	sd	s2,16(sp)
    80001e8a:	e44e                	sd	s3,8(sp)
    80001e8c:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e8e:	a53ff0ef          	jal	800018e0 <myproc>
    80001e92:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e94:	cf7fe0ef          	jal	80000b8a <holding>
    80001e98:	c92d                	beqz	a0,80001f0a <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e9a:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e9c:	2781                	sext.w	a5,a5
    80001e9e:	079e                	slli	a5,a5,0x7
    80001ea0:	00010717          	auipc	a4,0x10
    80001ea4:	5b070713          	addi	a4,a4,1456 # 80012450 <pid_lock>
    80001ea8:	97ba                	add	a5,a5,a4
    80001eaa:	0a87a703          	lw	a4,168(a5)
    80001eae:	4785                	li	a5,1
    80001eb0:	06f71363          	bne	a4,a5,80001f16 <sched+0x96>
  if(p->state == RUNNING)
    80001eb4:	4c98                	lw	a4,24(s1)
    80001eb6:	4791                	li	a5,4
    80001eb8:	06f70563          	beq	a4,a5,80001f22 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001ebc:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001ec0:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001ec2:	e7b5                	bnez	a5,80001f2e <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001ec4:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001ec6:	00010917          	auipc	s2,0x10
    80001eca:	58a90913          	addi	s2,s2,1418 # 80012450 <pid_lock>
    80001ece:	2781                	sext.w	a5,a5
    80001ed0:	079e                	slli	a5,a5,0x7
    80001ed2:	97ca                	add	a5,a5,s2
    80001ed4:	0ac7a983          	lw	s3,172(a5)
    80001ed8:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001eda:	2781                	sext.w	a5,a5
    80001edc:	079e                	slli	a5,a5,0x7
    80001ede:	00010597          	auipc	a1,0x10
    80001ee2:	5aa58593          	addi	a1,a1,1450 # 80012488 <cpus+0x8>
    80001ee6:	95be                	add	a1,a1,a5
    80001ee8:	06048513          	addi	a0,s1,96
    80001eec:	5c8000ef          	jal	800024b4 <swtch>
    80001ef0:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001ef2:	2781                	sext.w	a5,a5
    80001ef4:	079e                	slli	a5,a5,0x7
    80001ef6:	993e                	add	s2,s2,a5
    80001ef8:	0b392623          	sw	s3,172(s2)
}
    80001efc:	70a2                	ld	ra,40(sp)
    80001efe:	7402                	ld	s0,32(sp)
    80001f00:	64e2                	ld	s1,24(sp)
    80001f02:	6942                	ld	s2,16(sp)
    80001f04:	69a2                	ld	s3,8(sp)
    80001f06:	6145                	addi	sp,sp,48
    80001f08:	8082                	ret
    panic("sched p->lock");
    80001f0a:	00005517          	auipc	a0,0x5
    80001f0e:	32e50513          	addi	a0,a0,814 # 80007238 <etext+0x238>
    80001f12:	883fe0ef          	jal	80000794 <panic>
    panic("sched locks");
    80001f16:	00005517          	auipc	a0,0x5
    80001f1a:	33250513          	addi	a0,a0,818 # 80007248 <etext+0x248>
    80001f1e:	877fe0ef          	jal	80000794 <panic>
    panic("sched running");
    80001f22:	00005517          	auipc	a0,0x5
    80001f26:	33650513          	addi	a0,a0,822 # 80007258 <etext+0x258>
    80001f2a:	86bfe0ef          	jal	80000794 <panic>
    panic("sched interruptible");
    80001f2e:	00005517          	auipc	a0,0x5
    80001f32:	33a50513          	addi	a0,a0,826 # 80007268 <etext+0x268>
    80001f36:	85ffe0ef          	jal	80000794 <panic>

0000000080001f3a <yield>:
{
    80001f3a:	1101                	addi	sp,sp,-32
    80001f3c:	ec06                	sd	ra,24(sp)
    80001f3e:	e822                	sd	s0,16(sp)
    80001f40:	e426                	sd	s1,8(sp)
    80001f42:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f44:	99dff0ef          	jal	800018e0 <myproc>
    80001f48:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f4a:	cabfe0ef          	jal	80000bf4 <acquire>
  p->state = RUNNABLE;
    80001f4e:	478d                	li	a5,3
    80001f50:	cc9c                	sw	a5,24(s1)
  sched();
    80001f52:	f2fff0ef          	jal	80001e80 <sched>
  release(&p->lock);
    80001f56:	8526                	mv	a0,s1
    80001f58:	d35fe0ef          	jal	80000c8c <release>
}
    80001f5c:	60e2                	ld	ra,24(sp)
    80001f5e:	6442                	ld	s0,16(sp)
    80001f60:	64a2                	ld	s1,8(sp)
    80001f62:	6105                	addi	sp,sp,32
    80001f64:	8082                	ret

0000000080001f66 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001f66:	7179                	addi	sp,sp,-48
    80001f68:	f406                	sd	ra,40(sp)
    80001f6a:	f022                	sd	s0,32(sp)
    80001f6c:	ec26                	sd	s1,24(sp)
    80001f6e:	e84a                	sd	s2,16(sp)
    80001f70:	e44e                	sd	s3,8(sp)
    80001f72:	1800                	addi	s0,sp,48
    80001f74:	89aa                	mv	s3,a0
    80001f76:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001f78:	969ff0ef          	jal	800018e0 <myproc>
    80001f7c:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001f7e:	c77fe0ef          	jal	80000bf4 <acquire>
  release(lk);
    80001f82:	854a                	mv	a0,s2
    80001f84:	d09fe0ef          	jal	80000c8c <release>

  // Go to sleep.
  p->chan = chan;
    80001f88:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f8c:	4789                	li	a5,2
    80001f8e:	cc9c                	sw	a5,24(s1)

  sched();
    80001f90:	ef1ff0ef          	jal	80001e80 <sched>

  // Tidy up.
  p->chan = 0;
    80001f94:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f98:	8526                	mv	a0,s1
    80001f9a:	cf3fe0ef          	jal	80000c8c <release>
  acquire(lk);
    80001f9e:	854a                	mv	a0,s2
    80001fa0:	c55fe0ef          	jal	80000bf4 <acquire>
}
    80001fa4:	70a2                	ld	ra,40(sp)
    80001fa6:	7402                	ld	s0,32(sp)
    80001fa8:	64e2                	ld	s1,24(sp)
    80001faa:	6942                	ld	s2,16(sp)
    80001fac:	69a2                	ld	s3,8(sp)
    80001fae:	6145                	addi	sp,sp,48
    80001fb0:	8082                	ret

0000000080001fb2 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80001fb2:	7139                	addi	sp,sp,-64
    80001fb4:	fc06                	sd	ra,56(sp)
    80001fb6:	f822                	sd	s0,48(sp)
    80001fb8:	f426                	sd	s1,40(sp)
    80001fba:	f04a                	sd	s2,32(sp)
    80001fbc:	ec4e                	sd	s3,24(sp)
    80001fbe:	e852                	sd	s4,16(sp)
    80001fc0:	e456                	sd	s5,8(sp)
    80001fc2:	0080                	addi	s0,sp,64
    80001fc4:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001fc6:	00011497          	auipc	s1,0x11
    80001fca:	8ba48493          	addi	s1,s1,-1862 # 80012880 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001fce:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001fd0:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001fd2:	00016917          	auipc	s2,0x16
    80001fd6:	6ae90913          	addi	s2,s2,1710 # 80018680 <tickslock>
    80001fda:	a801                	j	80001fea <wakeup+0x38>
      }
      release(&p->lock);
    80001fdc:	8526                	mv	a0,s1
    80001fde:	caffe0ef          	jal	80000c8c <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001fe2:	17848493          	addi	s1,s1,376
    80001fe6:	03248263          	beq	s1,s2,8000200a <wakeup+0x58>
    if(p != myproc()){
    80001fea:	8f7ff0ef          	jal	800018e0 <myproc>
    80001fee:	fea48ae3          	beq	s1,a0,80001fe2 <wakeup+0x30>
      acquire(&p->lock);
    80001ff2:	8526                	mv	a0,s1
    80001ff4:	c01fe0ef          	jal	80000bf4 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001ff8:	4c9c                	lw	a5,24(s1)
    80001ffa:	ff3791e3          	bne	a5,s3,80001fdc <wakeup+0x2a>
    80001ffe:	709c                	ld	a5,32(s1)
    80002000:	fd479ee3          	bne	a5,s4,80001fdc <wakeup+0x2a>
        p->state = RUNNABLE;
    80002004:	0154ac23          	sw	s5,24(s1)
    80002008:	bfd1                	j	80001fdc <wakeup+0x2a>
    }
  }
}
    8000200a:	70e2                	ld	ra,56(sp)
    8000200c:	7442                	ld	s0,48(sp)
    8000200e:	74a2                	ld	s1,40(sp)
    80002010:	7902                	ld	s2,32(sp)
    80002012:	69e2                	ld	s3,24(sp)
    80002014:	6a42                	ld	s4,16(sp)
    80002016:	6aa2                	ld	s5,8(sp)
    80002018:	6121                	addi	sp,sp,64
    8000201a:	8082                	ret

000000008000201c <reparent>:
{
    8000201c:	7179                	addi	sp,sp,-48
    8000201e:	f406                	sd	ra,40(sp)
    80002020:	f022                	sd	s0,32(sp)
    80002022:	ec26                	sd	s1,24(sp)
    80002024:	e84a                	sd	s2,16(sp)
    80002026:	e44e                	sd	s3,8(sp)
    80002028:	e052                	sd	s4,0(sp)
    8000202a:	1800                	addi	s0,sp,48
    8000202c:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000202e:	00011497          	auipc	s1,0x11
    80002032:	85248493          	addi	s1,s1,-1966 # 80012880 <proc>
      pp->parent = initproc;
    80002036:	00008a17          	auipc	s4,0x8
    8000203a:	2eaa0a13          	addi	s4,s4,746 # 8000a320 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000203e:	00016997          	auipc	s3,0x16
    80002042:	64298993          	addi	s3,s3,1602 # 80018680 <tickslock>
    80002046:	a029                	j	80002050 <reparent+0x34>
    80002048:	17848493          	addi	s1,s1,376
    8000204c:	01348b63          	beq	s1,s3,80002062 <reparent+0x46>
    if(pp->parent == p){
    80002050:	7c9c                	ld	a5,56(s1)
    80002052:	ff279be3          	bne	a5,s2,80002048 <reparent+0x2c>
      pp->parent = initproc;
    80002056:	000a3503          	ld	a0,0(s4)
    8000205a:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000205c:	f57ff0ef          	jal	80001fb2 <wakeup>
    80002060:	b7e5                	j	80002048 <reparent+0x2c>
}
    80002062:	70a2                	ld	ra,40(sp)
    80002064:	7402                	ld	s0,32(sp)
    80002066:	64e2                	ld	s1,24(sp)
    80002068:	6942                	ld	s2,16(sp)
    8000206a:	69a2                	ld	s3,8(sp)
    8000206c:	6a02                	ld	s4,0(sp)
    8000206e:	6145                	addi	sp,sp,48
    80002070:	8082                	ret

0000000080002072 <exit>:
{
    80002072:	7179                	addi	sp,sp,-48
    80002074:	f406                	sd	ra,40(sp)
    80002076:	f022                	sd	s0,32(sp)
    80002078:	ec26                	sd	s1,24(sp)
    8000207a:	e84a                	sd	s2,16(sp)
    8000207c:	e44e                	sd	s3,8(sp)
    8000207e:	e052                	sd	s4,0(sp)
    80002080:	1800                	addi	s0,sp,48
    80002082:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002084:	85dff0ef          	jal	800018e0 <myproc>
    80002088:	89aa                	mv	s3,a0
  if(p == initproc)
    8000208a:	00008797          	auipc	a5,0x8
    8000208e:	2967b783          	ld	a5,662(a5) # 8000a320 <initproc>
    80002092:	0d050493          	addi	s1,a0,208
    80002096:	15050913          	addi	s2,a0,336
    8000209a:	00a79f63          	bne	a5,a0,800020b8 <exit+0x46>
    panic("init exiting");
    8000209e:	00005517          	auipc	a0,0x5
    800020a2:	1e250513          	addi	a0,a0,482 # 80007280 <etext+0x280>
    800020a6:	eeefe0ef          	jal	80000794 <panic>
      fileclose(f);
    800020aa:	76f010ef          	jal	80004018 <fileclose>
      p->ofile[fd] = 0;
    800020ae:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    800020b2:	04a1                	addi	s1,s1,8
    800020b4:	01248563          	beq	s1,s2,800020be <exit+0x4c>
    if(p->ofile[fd]){
    800020b8:	6088                	ld	a0,0(s1)
    800020ba:	f965                	bnez	a0,800020aa <exit+0x38>
    800020bc:	bfdd                	j	800020b2 <exit+0x40>
  begin_op();
    800020be:	341010ef          	jal	80003bfe <begin_op>
  iput(p->cwd);
    800020c2:	1509b503          	ld	a0,336(s3)
    800020c6:	424010ef          	jal	800034ea <iput>
  end_op();
    800020ca:	39f010ef          	jal	80003c68 <end_op>
  p->cwd = 0;
    800020ce:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800020d2:	00010497          	auipc	s1,0x10
    800020d6:	39648493          	addi	s1,s1,918 # 80012468 <wait_lock>
    800020da:	8526                	mv	a0,s1
    800020dc:	b19fe0ef          	jal	80000bf4 <acquire>
  reparent(p);
    800020e0:	854e                	mv	a0,s3
    800020e2:	f3bff0ef          	jal	8000201c <reparent>
  wakeup(p->parent);
    800020e6:	0389b503          	ld	a0,56(s3)
    800020ea:	ec9ff0ef          	jal	80001fb2 <wakeup>
  acquire(&p->lock);
    800020ee:	854e                	mv	a0,s3
    800020f0:	b05fe0ef          	jal	80000bf4 <acquire>
  p->xstate = status;
    800020f4:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800020f8:	4795                	li	a5,5
    800020fa:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800020fe:	8526                	mv	a0,s1
    80002100:	b8dfe0ef          	jal	80000c8c <release>
  sched();
    80002104:	d7dff0ef          	jal	80001e80 <sched>
  panic("zombie exit");
    80002108:	00005517          	auipc	a0,0x5
    8000210c:	18850513          	addi	a0,a0,392 # 80007290 <etext+0x290>
    80002110:	e84fe0ef          	jal	80000794 <panic>

0000000080002114 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002114:	7179                	addi	sp,sp,-48
    80002116:	f406                	sd	ra,40(sp)
    80002118:	f022                	sd	s0,32(sp)
    8000211a:	ec26                	sd	s1,24(sp)
    8000211c:	e84a                	sd	s2,16(sp)
    8000211e:	e44e                	sd	s3,8(sp)
    80002120:	1800                	addi	s0,sp,48
    80002122:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002124:	00010497          	auipc	s1,0x10
    80002128:	75c48493          	addi	s1,s1,1884 # 80012880 <proc>
    8000212c:	00016997          	auipc	s3,0x16
    80002130:	55498993          	addi	s3,s3,1364 # 80018680 <tickslock>
    acquire(&p->lock);
    80002134:	8526                	mv	a0,s1
    80002136:	abffe0ef          	jal	80000bf4 <acquire>
    if(p->pid == pid){
    8000213a:	589c                	lw	a5,48(s1)
    8000213c:	01278b63          	beq	a5,s2,80002152 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002140:	8526                	mv	a0,s1
    80002142:	b4bfe0ef          	jal	80000c8c <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002146:	17848493          	addi	s1,s1,376
    8000214a:	ff3495e3          	bne	s1,s3,80002134 <kill+0x20>
  }
  return -1;
    8000214e:	557d                	li	a0,-1
    80002150:	a819                	j	80002166 <kill+0x52>
      p->killed = 1;
    80002152:	4785                	li	a5,1
    80002154:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002156:	4c98                	lw	a4,24(s1)
    80002158:	4789                	li	a5,2
    8000215a:	00f70d63          	beq	a4,a5,80002174 <kill+0x60>
      release(&p->lock);
    8000215e:	8526                	mv	a0,s1
    80002160:	b2dfe0ef          	jal	80000c8c <release>
      return 0;
    80002164:	4501                	li	a0,0
}
    80002166:	70a2                	ld	ra,40(sp)
    80002168:	7402                	ld	s0,32(sp)
    8000216a:	64e2                	ld	s1,24(sp)
    8000216c:	6942                	ld	s2,16(sp)
    8000216e:	69a2                	ld	s3,8(sp)
    80002170:	6145                	addi	sp,sp,48
    80002172:	8082                	ret
        p->state = RUNNABLE;
    80002174:	478d                	li	a5,3
    80002176:	cc9c                	sw	a5,24(s1)
    80002178:	b7dd                	j	8000215e <kill+0x4a>

000000008000217a <setkilled>:

void
setkilled(struct proc *p)
{
    8000217a:	1101                	addi	sp,sp,-32
    8000217c:	ec06                	sd	ra,24(sp)
    8000217e:	e822                	sd	s0,16(sp)
    80002180:	e426                	sd	s1,8(sp)
    80002182:	1000                	addi	s0,sp,32
    80002184:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002186:	a6ffe0ef          	jal	80000bf4 <acquire>
  p->killed = 1;
    8000218a:	4785                	li	a5,1
    8000218c:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000218e:	8526                	mv	a0,s1
    80002190:	afdfe0ef          	jal	80000c8c <release>
}
    80002194:	60e2                	ld	ra,24(sp)
    80002196:	6442                	ld	s0,16(sp)
    80002198:	64a2                	ld	s1,8(sp)
    8000219a:	6105                	addi	sp,sp,32
    8000219c:	8082                	ret

000000008000219e <killed>:

int
killed(struct proc *p)
{
    8000219e:	1101                	addi	sp,sp,-32
    800021a0:	ec06                	sd	ra,24(sp)
    800021a2:	e822                	sd	s0,16(sp)
    800021a4:	e426                	sd	s1,8(sp)
    800021a6:	e04a                	sd	s2,0(sp)
    800021a8:	1000                	addi	s0,sp,32
    800021aa:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800021ac:	a49fe0ef          	jal	80000bf4 <acquire>
  k = p->killed;
    800021b0:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800021b4:	8526                	mv	a0,s1
    800021b6:	ad7fe0ef          	jal	80000c8c <release>
  return k;
}
    800021ba:	854a                	mv	a0,s2
    800021bc:	60e2                	ld	ra,24(sp)
    800021be:	6442                	ld	s0,16(sp)
    800021c0:	64a2                	ld	s1,8(sp)
    800021c2:	6902                	ld	s2,0(sp)
    800021c4:	6105                	addi	sp,sp,32
    800021c6:	8082                	ret

00000000800021c8 <wait>:
{
    800021c8:	715d                	addi	sp,sp,-80
    800021ca:	e486                	sd	ra,72(sp)
    800021cc:	e0a2                	sd	s0,64(sp)
    800021ce:	fc26                	sd	s1,56(sp)
    800021d0:	f84a                	sd	s2,48(sp)
    800021d2:	f44e                	sd	s3,40(sp)
    800021d4:	f052                	sd	s4,32(sp)
    800021d6:	ec56                	sd	s5,24(sp)
    800021d8:	e85a                	sd	s6,16(sp)
    800021da:	e45e                	sd	s7,8(sp)
    800021dc:	e062                	sd	s8,0(sp)
    800021de:	0880                	addi	s0,sp,80
    800021e0:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800021e2:	efeff0ef          	jal	800018e0 <myproc>
    800021e6:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021e8:	00010517          	auipc	a0,0x10
    800021ec:	28050513          	addi	a0,a0,640 # 80012468 <wait_lock>
    800021f0:	a05fe0ef          	jal	80000bf4 <acquire>
    havekids = 0;
    800021f4:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    800021f6:	4a15                	li	s4,5
        havekids = 1;
    800021f8:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021fa:	00016997          	auipc	s3,0x16
    800021fe:	48698993          	addi	s3,s3,1158 # 80018680 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002202:	00010c17          	auipc	s8,0x10
    80002206:	266c0c13          	addi	s8,s8,614 # 80012468 <wait_lock>
    8000220a:	a871                	j	800022a6 <wait+0xde>
          pid = pp->pid;
    8000220c:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002210:	000b0c63          	beqz	s6,80002228 <wait+0x60>
    80002214:	4691                	li	a3,4
    80002216:	02c48613          	addi	a2,s1,44
    8000221a:	85da                	mv	a1,s6
    8000221c:	05093503          	ld	a0,80(s2)
    80002220:	b32ff0ef          	jal	80001552 <copyout>
    80002224:	02054b63          	bltz	a0,8000225a <wait+0x92>
          freeproc(pp);
    80002228:	8526                	mv	a0,s1
    8000222a:	829ff0ef          	jal	80001a52 <freeproc>
          release(&pp->lock);
    8000222e:	8526                	mv	a0,s1
    80002230:	a5dfe0ef          	jal	80000c8c <release>
          release(&wait_lock);
    80002234:	00010517          	auipc	a0,0x10
    80002238:	23450513          	addi	a0,a0,564 # 80012468 <wait_lock>
    8000223c:	a51fe0ef          	jal	80000c8c <release>
}
    80002240:	854e                	mv	a0,s3
    80002242:	60a6                	ld	ra,72(sp)
    80002244:	6406                	ld	s0,64(sp)
    80002246:	74e2                	ld	s1,56(sp)
    80002248:	7942                	ld	s2,48(sp)
    8000224a:	79a2                	ld	s3,40(sp)
    8000224c:	7a02                	ld	s4,32(sp)
    8000224e:	6ae2                	ld	s5,24(sp)
    80002250:	6b42                	ld	s6,16(sp)
    80002252:	6ba2                	ld	s7,8(sp)
    80002254:	6c02                	ld	s8,0(sp)
    80002256:	6161                	addi	sp,sp,80
    80002258:	8082                	ret
            release(&pp->lock);
    8000225a:	8526                	mv	a0,s1
    8000225c:	a31fe0ef          	jal	80000c8c <release>
            release(&wait_lock);
    80002260:	00010517          	auipc	a0,0x10
    80002264:	20850513          	addi	a0,a0,520 # 80012468 <wait_lock>
    80002268:	a25fe0ef          	jal	80000c8c <release>
            return -1;
    8000226c:	59fd                	li	s3,-1
    8000226e:	bfc9                	j	80002240 <wait+0x78>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002270:	17848493          	addi	s1,s1,376
    80002274:	03348063          	beq	s1,s3,80002294 <wait+0xcc>
      if(pp->parent == p){
    80002278:	7c9c                	ld	a5,56(s1)
    8000227a:	ff279be3          	bne	a5,s2,80002270 <wait+0xa8>
        acquire(&pp->lock);
    8000227e:	8526                	mv	a0,s1
    80002280:	975fe0ef          	jal	80000bf4 <acquire>
        if(pp->state == ZOMBIE){
    80002284:	4c9c                	lw	a5,24(s1)
    80002286:	f94783e3          	beq	a5,s4,8000220c <wait+0x44>
        release(&pp->lock);
    8000228a:	8526                	mv	a0,s1
    8000228c:	a01fe0ef          	jal	80000c8c <release>
        havekids = 1;
    80002290:	8756                	mv	a4,s5
    80002292:	bff9                	j	80002270 <wait+0xa8>
    if(!havekids || killed(p)){
    80002294:	cf19                	beqz	a4,800022b2 <wait+0xea>
    80002296:	854a                	mv	a0,s2
    80002298:	f07ff0ef          	jal	8000219e <killed>
    8000229c:	e919                	bnez	a0,800022b2 <wait+0xea>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000229e:	85e2                	mv	a1,s8
    800022a0:	854a                	mv	a0,s2
    800022a2:	cc5ff0ef          	jal	80001f66 <sleep>
    havekids = 0;
    800022a6:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022a8:	00010497          	auipc	s1,0x10
    800022ac:	5d848493          	addi	s1,s1,1496 # 80012880 <proc>
    800022b0:	b7e1                	j	80002278 <wait+0xb0>
      release(&wait_lock);
    800022b2:	00010517          	auipc	a0,0x10
    800022b6:	1b650513          	addi	a0,a0,438 # 80012468 <wait_lock>
    800022ba:	9d3fe0ef          	jal	80000c8c <release>
      return -1;
    800022be:	59fd                	li	s3,-1
    800022c0:	b741                	j	80002240 <wait+0x78>

00000000800022c2 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800022c2:	7179                	addi	sp,sp,-48
    800022c4:	f406                	sd	ra,40(sp)
    800022c6:	f022                	sd	s0,32(sp)
    800022c8:	ec26                	sd	s1,24(sp)
    800022ca:	e84a                	sd	s2,16(sp)
    800022cc:	e44e                	sd	s3,8(sp)
    800022ce:	e052                	sd	s4,0(sp)
    800022d0:	1800                	addi	s0,sp,48
    800022d2:	84aa                	mv	s1,a0
    800022d4:	892e                	mv	s2,a1
    800022d6:	89b2                	mv	s3,a2
    800022d8:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800022da:	e06ff0ef          	jal	800018e0 <myproc>
  if(user_dst){
    800022de:	cc99                	beqz	s1,800022fc <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800022e0:	86d2                	mv	a3,s4
    800022e2:	864e                	mv	a2,s3
    800022e4:	85ca                	mv	a1,s2
    800022e6:	6928                	ld	a0,80(a0)
    800022e8:	a6aff0ef          	jal	80001552 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800022ec:	70a2                	ld	ra,40(sp)
    800022ee:	7402                	ld	s0,32(sp)
    800022f0:	64e2                	ld	s1,24(sp)
    800022f2:	6942                	ld	s2,16(sp)
    800022f4:	69a2                	ld	s3,8(sp)
    800022f6:	6a02                	ld	s4,0(sp)
    800022f8:	6145                	addi	sp,sp,48
    800022fa:	8082                	ret
    memmove((char *)dst, src, len);
    800022fc:	000a061b          	sext.w	a2,s4
    80002300:	85ce                	mv	a1,s3
    80002302:	854a                	mv	a0,s2
    80002304:	a21fe0ef          	jal	80000d24 <memmove>
    return 0;
    80002308:	8526                	mv	a0,s1
    8000230a:	b7cd                	j	800022ec <either_copyout+0x2a>

000000008000230c <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000230c:	7179                	addi	sp,sp,-48
    8000230e:	f406                	sd	ra,40(sp)
    80002310:	f022                	sd	s0,32(sp)
    80002312:	ec26                	sd	s1,24(sp)
    80002314:	e84a                	sd	s2,16(sp)
    80002316:	e44e                	sd	s3,8(sp)
    80002318:	e052                	sd	s4,0(sp)
    8000231a:	1800                	addi	s0,sp,48
    8000231c:	892a                	mv	s2,a0
    8000231e:	84ae                	mv	s1,a1
    80002320:	89b2                	mv	s3,a2
    80002322:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002324:	dbcff0ef          	jal	800018e0 <myproc>
  if(user_src){
    80002328:	cc99                	beqz	s1,80002346 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    8000232a:	86d2                	mv	a3,s4
    8000232c:	864e                	mv	a2,s3
    8000232e:	85ca                	mv	a1,s2
    80002330:	6928                	ld	a0,80(a0)
    80002332:	af6ff0ef          	jal	80001628 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002336:	70a2                	ld	ra,40(sp)
    80002338:	7402                	ld	s0,32(sp)
    8000233a:	64e2                	ld	s1,24(sp)
    8000233c:	6942                	ld	s2,16(sp)
    8000233e:	69a2                	ld	s3,8(sp)
    80002340:	6a02                	ld	s4,0(sp)
    80002342:	6145                	addi	sp,sp,48
    80002344:	8082                	ret
    memmove(dst, (char*)src, len);
    80002346:	000a061b          	sext.w	a2,s4
    8000234a:	85ce                	mv	a1,s3
    8000234c:	854a                	mv	a0,s2
    8000234e:	9d7fe0ef          	jal	80000d24 <memmove>
    return 0;
    80002352:	8526                	mv	a0,s1
    80002354:	b7cd                	j	80002336 <either_copyin+0x2a>

0000000080002356 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002356:	715d                	addi	sp,sp,-80
    80002358:	e486                	sd	ra,72(sp)
    8000235a:	e0a2                	sd	s0,64(sp)
    8000235c:	fc26                	sd	s1,56(sp)
    8000235e:	f84a                	sd	s2,48(sp)
    80002360:	f44e                	sd	s3,40(sp)
    80002362:	f052                	sd	s4,32(sp)
    80002364:	ec56                	sd	s5,24(sp)
    80002366:	e85a                	sd	s6,16(sp)
    80002368:	e45e                	sd	s7,8(sp)
    8000236a:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    8000236c:	00005517          	auipc	a0,0x5
    80002370:	d0c50513          	addi	a0,a0,-756 # 80007078 <etext+0x78>
    80002374:	94efe0ef          	jal	800004c2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002378:	00010497          	auipc	s1,0x10
    8000237c:	66048493          	addi	s1,s1,1632 # 800129d8 <proc+0x158>
    80002380:	00016917          	auipc	s2,0x16
    80002384:	45890913          	addi	s2,s2,1112 # 800187d8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002388:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000238a:	00005997          	auipc	s3,0x5
    8000238e:	f1698993          	addi	s3,s3,-234 # 800072a0 <etext+0x2a0>
    printf("%d %s %s", p->pid, state, p->name);
    80002392:	00005a97          	auipc	s5,0x5
    80002396:	f16a8a93          	addi	s5,s5,-234 # 800072a8 <etext+0x2a8>
    printf("\n");
    8000239a:	00005a17          	auipc	s4,0x5
    8000239e:	cdea0a13          	addi	s4,s4,-802 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023a2:	00005b97          	auipc	s7,0x5
    800023a6:	406b8b93          	addi	s7,s7,1030 # 800077a8 <states.0>
    800023aa:	a829                	j	800023c4 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800023ac:	ed86a583          	lw	a1,-296(a3)
    800023b0:	8556                	mv	a0,s5
    800023b2:	910fe0ef          	jal	800004c2 <printf>
    printf("\n");
    800023b6:	8552                	mv	a0,s4
    800023b8:	90afe0ef          	jal	800004c2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800023bc:	17848493          	addi	s1,s1,376
    800023c0:	03248263          	beq	s1,s2,800023e4 <procdump+0x8e>
    if(p->state == UNUSED)
    800023c4:	86a6                	mv	a3,s1
    800023c6:	ec04a783          	lw	a5,-320(s1)
    800023ca:	dbed                	beqz	a5,800023bc <procdump+0x66>
      state = "???";
    800023cc:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023ce:	fcfb6fe3          	bltu	s6,a5,800023ac <procdump+0x56>
    800023d2:	02079713          	slli	a4,a5,0x20
    800023d6:	01d75793          	srli	a5,a4,0x1d
    800023da:	97de                	add	a5,a5,s7
    800023dc:	6390                	ld	a2,0(a5)
    800023de:	f679                	bnez	a2,800023ac <procdump+0x56>
      state = "???";
    800023e0:	864e                	mv	a2,s3
    800023e2:	b7e9                	j	800023ac <procdump+0x56>
  }
}
    800023e4:	60a6                	ld	ra,72(sp)
    800023e6:	6406                	ld	s0,64(sp)
    800023e8:	74e2                	ld	s1,56(sp)
    800023ea:	7942                	ld	s2,48(sp)
    800023ec:	79a2                	ld	s3,40(sp)
    800023ee:	7a02                	ld	s4,32(sp)
    800023f0:	6ae2                	ld	s5,24(sp)
    800023f2:	6b42                	ld	s6,16(sp)
    800023f4:	6ba2                	ld	s7,8(sp)
    800023f6:	6161                	addi	sp,sp,80
    800023f8:	8082                	ret

00000000800023fa <sched_statistics>:

int
sched_statistics(void)
{
    800023fa:	7179                	addi	sp,sp,-48
    800023fc:	f406                	sd	ra,40(sp)
    800023fe:	f022                	sd	s0,32(sp)
    80002400:	ec26                	sd	s1,24(sp)
    80002402:	e84a                	sd	s2,16(sp)
    80002404:	e44e                	sd	s3,8(sp)
    80002406:	1800                	addi	s0,sp,48
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++)
    80002408:	00010497          	auipc	s1,0x10
    8000240c:	47848493          	addi	s1,s1,1144 # 80012880 <proc>
  {
    acquire(&p->lock);
    if (p->state != UNUSED)
    {
      printf("%d(%s): tickets: %d, ticks: %d\n", p->pid, p->name, p->tickets, p->ticks);
    80002410:	00005997          	auipc	s3,0x5
    80002414:	ea898993          	addi	s3,s3,-344 # 800072b8 <etext+0x2b8>
  for (p = proc; p < &proc[NPROC]; p++)
    80002418:	00016917          	auipc	s2,0x16
    8000241c:	26890913          	addi	s2,s2,616 # 80018680 <tickslock>
    80002420:	a801                	j	80002430 <sched_statistics+0x36>
    }
    release(&p->lock);
    80002422:	8526                	mv	a0,s1
    80002424:	869fe0ef          	jal	80000c8c <release>
  for (p = proc; p < &proc[NPROC]; p++)
    80002428:	17848493          	addi	s1,s1,376
    8000242c:	03248263          	beq	s1,s2,80002450 <sched_statistics+0x56>
    acquire(&p->lock);
    80002430:	8526                	mv	a0,s1
    80002432:	fc2fe0ef          	jal	80000bf4 <acquire>
    if (p->state != UNUSED)
    80002436:	4c9c                	lw	a5,24(s1)
    80002438:	d7ed                	beqz	a5,80002422 <sched_statistics+0x28>
      printf("%d(%s): tickets: %d, ticks: %d\n", p->pid, p->name, p->tickets, p->ticks);
    8000243a:	16c4a703          	lw	a4,364(s1)
    8000243e:	1684a683          	lw	a3,360(s1)
    80002442:	15848613          	addi	a2,s1,344
    80002446:	588c                	lw	a1,48(s1)
    80002448:	854e                	mv	a0,s3
    8000244a:	878fe0ef          	jal	800004c2 <printf>
    8000244e:	bfd1                	j	80002422 <sched_statistics+0x28>
  }
  return 0;
}
    80002450:	4501                	li	a0,0
    80002452:	70a2                	ld	ra,40(sp)
    80002454:	7402                	ld	s0,32(sp)
    80002456:	64e2                	ld	s1,24(sp)
    80002458:	6942                	ld	s2,16(sp)
    8000245a:	69a2                	ld	s3,8(sp)
    8000245c:	6145                	addi	sp,sp,48
    8000245e:	8082                	ret

0000000080002460 <sched_tickets>:

int sched_tickets(int tickets)
{
  if (tickets < 1 || tickets > 10000)
    80002460:	fff5071b          	addiw	a4,a0,-1
    80002464:	6789                	lui	a5,0x2
    80002466:	70f78793          	addi	a5,a5,1807 # 270f <_entry-0x7fffd8f1>
    8000246a:	00e7f463          	bgeu	a5,a4,80002472 <sched_tickets+0x12>
  p->pass = p->stride;
  p->tickets = tickets;
  release(&p->lock);

  return 0;
}
    8000246e:	4501                	li	a0,0
    80002470:	8082                	ret
{
    80002472:	1101                	addi	sp,sp,-32
    80002474:	ec06                	sd	ra,24(sp)
    80002476:	e822                	sd	s0,16(sp)
    80002478:	e426                	sd	s1,8(sp)
    8000247a:	e04a                	sd	s2,0(sp)
    8000247c:	1000                	addi	s0,sp,32
    8000247e:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002480:	c60ff0ef          	jal	800018e0 <myproc>
    80002484:	892a                	mv	s2,a0
  acquire(&p->lock);
    80002486:	f6efe0ef          	jal	80000bf4 <acquire>
  p->stride = 10000/tickets;
    8000248a:	6789                	lui	a5,0x2
    8000248c:	7107879b          	addiw	a5,a5,1808 # 2710 <_entry-0x7fffd8f0>
    80002490:	0297c7bb          	divw	a5,a5,s1
    80002494:	16f92823          	sw	a5,368(s2)
  p->pass = p->stride;
    80002498:	16f92a23          	sw	a5,372(s2)
  p->tickets = tickets;
    8000249c:	16992423          	sw	s1,360(s2)
  release(&p->lock);
    800024a0:	854a                	mv	a0,s2
    800024a2:	feafe0ef          	jal	80000c8c <release>
}
    800024a6:	4501                	li	a0,0
    800024a8:	60e2                	ld	ra,24(sp)
    800024aa:	6442                	ld	s0,16(sp)
    800024ac:	64a2                	ld	s1,8(sp)
    800024ae:	6902                	ld	s2,0(sp)
    800024b0:	6105                	addi	sp,sp,32
    800024b2:	8082                	ret

00000000800024b4 <swtch>:
    800024b4:	00153023          	sd	ra,0(a0)
    800024b8:	00253423          	sd	sp,8(a0)
    800024bc:	e900                	sd	s0,16(a0)
    800024be:	ed04                	sd	s1,24(a0)
    800024c0:	03253023          	sd	s2,32(a0)
    800024c4:	03353423          	sd	s3,40(a0)
    800024c8:	03453823          	sd	s4,48(a0)
    800024cc:	03553c23          	sd	s5,56(a0)
    800024d0:	05653023          	sd	s6,64(a0)
    800024d4:	05753423          	sd	s7,72(a0)
    800024d8:	05853823          	sd	s8,80(a0)
    800024dc:	05953c23          	sd	s9,88(a0)
    800024e0:	07a53023          	sd	s10,96(a0)
    800024e4:	07b53423          	sd	s11,104(a0)
    800024e8:	0005b083          	ld	ra,0(a1)
    800024ec:	0085b103          	ld	sp,8(a1)
    800024f0:	6980                	ld	s0,16(a1)
    800024f2:	6d84                	ld	s1,24(a1)
    800024f4:	0205b903          	ld	s2,32(a1)
    800024f8:	0285b983          	ld	s3,40(a1)
    800024fc:	0305ba03          	ld	s4,48(a1)
    80002500:	0385ba83          	ld	s5,56(a1)
    80002504:	0405bb03          	ld	s6,64(a1)
    80002508:	0485bb83          	ld	s7,72(a1)
    8000250c:	0505bc03          	ld	s8,80(a1)
    80002510:	0585bc83          	ld	s9,88(a1)
    80002514:	0605bd03          	ld	s10,96(a1)
    80002518:	0685bd83          	ld	s11,104(a1)
    8000251c:	8082                	ret

000000008000251e <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000251e:	1141                	addi	sp,sp,-16
    80002520:	e406                	sd	ra,8(sp)
    80002522:	e022                	sd	s0,0(sp)
    80002524:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002526:	00005597          	auipc	a1,0x5
    8000252a:	de258593          	addi	a1,a1,-542 # 80007308 <etext+0x308>
    8000252e:	00016517          	auipc	a0,0x16
    80002532:	15250513          	addi	a0,a0,338 # 80018680 <tickslock>
    80002536:	e3efe0ef          	jal	80000b74 <initlock>
}
    8000253a:	60a2                	ld	ra,8(sp)
    8000253c:	6402                	ld	s0,0(sp)
    8000253e:	0141                	addi	sp,sp,16
    80002540:	8082                	ret

0000000080002542 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002542:	1141                	addi	sp,sp,-16
    80002544:	e422                	sd	s0,8(sp)
    80002546:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002548:	00003797          	auipc	a5,0x3
    8000254c:	e3878793          	addi	a5,a5,-456 # 80005380 <kernelvec>
    80002550:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002554:	6422                	ld	s0,8(sp)
    80002556:	0141                	addi	sp,sp,16
    80002558:	8082                	ret

000000008000255a <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    8000255a:	1141                	addi	sp,sp,-16
    8000255c:	e406                	sd	ra,8(sp)
    8000255e:	e022                	sd	s0,0(sp)
    80002560:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002562:	b7eff0ef          	jal	800018e0 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002566:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000256a:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000256c:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002570:	00004697          	auipc	a3,0x4
    80002574:	a9068693          	addi	a3,a3,-1392 # 80006000 <_trampoline>
    80002578:	00004717          	auipc	a4,0x4
    8000257c:	a8870713          	addi	a4,a4,-1400 # 80006000 <_trampoline>
    80002580:	8f15                	sub	a4,a4,a3
    80002582:	040007b7          	lui	a5,0x4000
    80002586:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80002588:	07b2                	slli	a5,a5,0xc
    8000258a:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000258c:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002590:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002592:	18002673          	csrr	a2,satp
    80002596:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002598:	6d30                	ld	a2,88(a0)
    8000259a:	6138                	ld	a4,64(a0)
    8000259c:	6585                	lui	a1,0x1
    8000259e:	972e                	add	a4,a4,a1
    800025a0:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800025a2:	6d38                	ld	a4,88(a0)
    800025a4:	00000617          	auipc	a2,0x0
    800025a8:	11060613          	addi	a2,a2,272 # 800026b4 <usertrap>
    800025ac:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800025ae:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800025b0:	8612                	mv	a2,tp
    800025b2:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025b4:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800025b8:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800025bc:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800025c0:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800025c4:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800025c6:	6f18                	ld	a4,24(a4)
    800025c8:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    800025cc:	6928                	ld	a0,80(a0)
    800025ce:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800025d0:	00004717          	auipc	a4,0x4
    800025d4:	acc70713          	addi	a4,a4,-1332 # 8000609c <userret>
    800025d8:	8f15                	sub	a4,a4,a3
    800025da:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800025dc:	577d                	li	a4,-1
    800025de:	177e                	slli	a4,a4,0x3f
    800025e0:	8d59                	or	a0,a0,a4
    800025e2:	9782                	jalr	a5
}
    800025e4:	60a2                	ld	ra,8(sp)
    800025e6:	6402                	ld	s0,0(sp)
    800025e8:	0141                	addi	sp,sp,16
    800025ea:	8082                	ret

00000000800025ec <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800025ec:	1101                	addi	sp,sp,-32
    800025ee:	ec06                	sd	ra,24(sp)
    800025f0:	e822                	sd	s0,16(sp)
    800025f2:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    800025f4:	ac0ff0ef          	jal	800018b4 <cpuid>
    800025f8:	cd11                	beqz	a0,80002614 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800025fa:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800025fe:	000f4737          	lui	a4,0xf4
    80002602:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002606:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002608:	14d79073          	csrw	stimecmp,a5
}
    8000260c:	60e2                	ld	ra,24(sp)
    8000260e:	6442                	ld	s0,16(sp)
    80002610:	6105                	addi	sp,sp,32
    80002612:	8082                	ret
    80002614:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    80002616:	00016497          	auipc	s1,0x16
    8000261a:	06a48493          	addi	s1,s1,106 # 80018680 <tickslock>
    8000261e:	8526                	mv	a0,s1
    80002620:	dd4fe0ef          	jal	80000bf4 <acquire>
    ticks++;
    80002624:	00008517          	auipc	a0,0x8
    80002628:	d0450513          	addi	a0,a0,-764 # 8000a328 <ticks>
    8000262c:	411c                	lw	a5,0(a0)
    8000262e:	2785                	addiw	a5,a5,1
    80002630:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    80002632:	981ff0ef          	jal	80001fb2 <wakeup>
    release(&tickslock);
    80002636:	8526                	mv	a0,s1
    80002638:	e54fe0ef          	jal	80000c8c <release>
    8000263c:	64a2                	ld	s1,8(sp)
    8000263e:	bf75                	j	800025fa <clockintr+0xe>

0000000080002640 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002640:	1101                	addi	sp,sp,-32
    80002642:	ec06                	sd	ra,24(sp)
    80002644:	e822                	sd	s0,16(sp)
    80002646:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002648:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    8000264c:	57fd                	li	a5,-1
    8000264e:	17fe                	slli	a5,a5,0x3f
    80002650:	07a5                	addi	a5,a5,9
    80002652:	00f70c63          	beq	a4,a5,8000266a <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002656:	57fd                	li	a5,-1
    80002658:	17fe                	slli	a5,a5,0x3f
    8000265a:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000265c:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    8000265e:	04f70763          	beq	a4,a5,800026ac <devintr+0x6c>
  }
}
    80002662:	60e2                	ld	ra,24(sp)
    80002664:	6442                	ld	s0,16(sp)
    80002666:	6105                	addi	sp,sp,32
    80002668:	8082                	ret
    8000266a:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000266c:	5c1020ef          	jal	8000542c <plic_claim>
    80002670:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002672:	47a9                	li	a5,10
    80002674:	00f50963          	beq	a0,a5,80002686 <devintr+0x46>
    } else if(irq == VIRTIO0_IRQ){
    80002678:	4785                	li	a5,1
    8000267a:	00f50963          	beq	a0,a5,8000268c <devintr+0x4c>
    return 1;
    8000267e:	4505                	li	a0,1
    } else if(irq){
    80002680:	e889                	bnez	s1,80002692 <devintr+0x52>
    80002682:	64a2                	ld	s1,8(sp)
    80002684:	bff9                	j	80002662 <devintr+0x22>
      uartintr();
    80002686:	b80fe0ef          	jal	80000a06 <uartintr>
    if(irq)
    8000268a:	a819                	j	800026a0 <devintr+0x60>
      virtio_disk_intr();
    8000268c:	266030ef          	jal	800058f2 <virtio_disk_intr>
    if(irq)
    80002690:	a801                	j	800026a0 <devintr+0x60>
      printf("unexpected interrupt irq=%d\n", irq);
    80002692:	85a6                	mv	a1,s1
    80002694:	00005517          	auipc	a0,0x5
    80002698:	c7c50513          	addi	a0,a0,-900 # 80007310 <etext+0x310>
    8000269c:	e27fd0ef          	jal	800004c2 <printf>
      plic_complete(irq);
    800026a0:	8526                	mv	a0,s1
    800026a2:	5ab020ef          	jal	8000544c <plic_complete>
    return 1;
    800026a6:	4505                	li	a0,1
    800026a8:	64a2                	ld	s1,8(sp)
    800026aa:	bf65                	j	80002662 <devintr+0x22>
    clockintr();
    800026ac:	f41ff0ef          	jal	800025ec <clockintr>
    return 2;
    800026b0:	4509                	li	a0,2
    800026b2:	bf45                	j	80002662 <devintr+0x22>

00000000800026b4 <usertrap>:
{
    800026b4:	1101                	addi	sp,sp,-32
    800026b6:	ec06                	sd	ra,24(sp)
    800026b8:	e822                	sd	s0,16(sp)
    800026ba:	e426                	sd	s1,8(sp)
    800026bc:	e04a                	sd	s2,0(sp)
    800026be:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800026c0:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800026c4:	1007f793          	andi	a5,a5,256
    800026c8:	ef85                	bnez	a5,80002700 <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800026ca:	00003797          	auipc	a5,0x3
    800026ce:	cb678793          	addi	a5,a5,-842 # 80005380 <kernelvec>
    800026d2:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800026d6:	a0aff0ef          	jal	800018e0 <myproc>
    800026da:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800026dc:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026de:	14102773          	csrr	a4,sepc
    800026e2:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800026e4:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800026e8:	47a1                	li	a5,8
    800026ea:	02f70163          	beq	a4,a5,8000270c <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    800026ee:	f53ff0ef          	jal	80002640 <devintr>
    800026f2:	892a                	mv	s2,a0
    800026f4:	c135                	beqz	a0,80002758 <usertrap+0xa4>
  if(killed(p))
    800026f6:	8526                	mv	a0,s1
    800026f8:	aa7ff0ef          	jal	8000219e <killed>
    800026fc:	cd1d                	beqz	a0,8000273a <usertrap+0x86>
    800026fe:	a81d                	j	80002734 <usertrap+0x80>
    panic("usertrap: not from user mode");
    80002700:	00005517          	auipc	a0,0x5
    80002704:	c3050513          	addi	a0,a0,-976 # 80007330 <etext+0x330>
    80002708:	88cfe0ef          	jal	80000794 <panic>
    if(killed(p))
    8000270c:	a93ff0ef          	jal	8000219e <killed>
    80002710:	e121                	bnez	a0,80002750 <usertrap+0x9c>
    p->trapframe->epc += 4;
    80002712:	6cb8                	ld	a4,88(s1)
    80002714:	6f1c                	ld	a5,24(a4)
    80002716:	0791                	addi	a5,a5,4
    80002718:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000271a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000271e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002722:	10079073          	csrw	sstatus,a5
    syscall();
    80002726:	248000ef          	jal	8000296e <syscall>
  if(killed(p))
    8000272a:	8526                	mv	a0,s1
    8000272c:	a73ff0ef          	jal	8000219e <killed>
    80002730:	c901                	beqz	a0,80002740 <usertrap+0x8c>
    80002732:	4901                	li	s2,0
    exit(-1);
    80002734:	557d                	li	a0,-1
    80002736:	93dff0ef          	jal	80002072 <exit>
  if(which_dev == 2)
    8000273a:	4789                	li	a5,2
    8000273c:	04f90563          	beq	s2,a5,80002786 <usertrap+0xd2>
  usertrapret();
    80002740:	e1bff0ef          	jal	8000255a <usertrapret>
}
    80002744:	60e2                	ld	ra,24(sp)
    80002746:	6442                	ld	s0,16(sp)
    80002748:	64a2                	ld	s1,8(sp)
    8000274a:	6902                	ld	s2,0(sp)
    8000274c:	6105                	addi	sp,sp,32
    8000274e:	8082                	ret
      exit(-1);
    80002750:	557d                	li	a0,-1
    80002752:	921ff0ef          	jal	80002072 <exit>
    80002756:	bf75                	j	80002712 <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002758:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    8000275c:	5890                	lw	a2,48(s1)
    8000275e:	00005517          	auipc	a0,0x5
    80002762:	bf250513          	addi	a0,a0,-1038 # 80007350 <etext+0x350>
    80002766:	d5dfd0ef          	jal	800004c2 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000276a:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    8000276e:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002772:	00005517          	auipc	a0,0x5
    80002776:	c0e50513          	addi	a0,a0,-1010 # 80007380 <etext+0x380>
    8000277a:	d49fd0ef          	jal	800004c2 <printf>
    setkilled(p);
    8000277e:	8526                	mv	a0,s1
    80002780:	9fbff0ef          	jal	8000217a <setkilled>
    80002784:	b75d                	j	8000272a <usertrap+0x76>
    yield();
    80002786:	fb4ff0ef          	jal	80001f3a <yield>
    8000278a:	bf5d                	j	80002740 <usertrap+0x8c>

000000008000278c <kerneltrap>:
{
    8000278c:	7179                	addi	sp,sp,-48
    8000278e:	f406                	sd	ra,40(sp)
    80002790:	f022                	sd	s0,32(sp)
    80002792:	ec26                	sd	s1,24(sp)
    80002794:	e84a                	sd	s2,16(sp)
    80002796:	e44e                	sd	s3,8(sp)
    80002798:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000279a:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000279e:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027a2:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    800027a6:	1004f793          	andi	a5,s1,256
    800027aa:	c795                	beqz	a5,800027d6 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027ac:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800027b0:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800027b2:	eb85                	bnez	a5,800027e2 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    800027b4:	e8dff0ef          	jal	80002640 <devintr>
    800027b8:	c91d                	beqz	a0,800027ee <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    800027ba:	4789                	li	a5,2
    800027bc:	04f50a63          	beq	a0,a5,80002810 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800027c0:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800027c4:	10049073          	csrw	sstatus,s1
}
    800027c8:	70a2                	ld	ra,40(sp)
    800027ca:	7402                	ld	s0,32(sp)
    800027cc:	64e2                	ld	s1,24(sp)
    800027ce:	6942                	ld	s2,16(sp)
    800027d0:	69a2                	ld	s3,8(sp)
    800027d2:	6145                	addi	sp,sp,48
    800027d4:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800027d6:	00005517          	auipc	a0,0x5
    800027da:	bd250513          	addi	a0,a0,-1070 # 800073a8 <etext+0x3a8>
    800027de:	fb7fd0ef          	jal	80000794 <panic>
    panic("kerneltrap: interrupts enabled");
    800027e2:	00005517          	auipc	a0,0x5
    800027e6:	bee50513          	addi	a0,a0,-1042 # 800073d0 <etext+0x3d0>
    800027ea:	fabfd0ef          	jal	80000794 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800027ee:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800027f2:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800027f6:	85ce                	mv	a1,s3
    800027f8:	00005517          	auipc	a0,0x5
    800027fc:	bf850513          	addi	a0,a0,-1032 # 800073f0 <etext+0x3f0>
    80002800:	cc3fd0ef          	jal	800004c2 <printf>
    panic("kerneltrap");
    80002804:	00005517          	auipc	a0,0x5
    80002808:	c1450513          	addi	a0,a0,-1004 # 80007418 <etext+0x418>
    8000280c:	f89fd0ef          	jal	80000794 <panic>
  if(which_dev == 2 && myproc() != 0)
    80002810:	8d0ff0ef          	jal	800018e0 <myproc>
    80002814:	d555                	beqz	a0,800027c0 <kerneltrap+0x34>
    yield();
    80002816:	f24ff0ef          	jal	80001f3a <yield>
    8000281a:	b75d                	j	800027c0 <kerneltrap+0x34>

000000008000281c <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    8000281c:	1101                	addi	sp,sp,-32
    8000281e:	ec06                	sd	ra,24(sp)
    80002820:	e822                	sd	s0,16(sp)
    80002822:	e426                	sd	s1,8(sp)
    80002824:	1000                	addi	s0,sp,32
    80002826:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002828:	8b8ff0ef          	jal	800018e0 <myproc>
  switch (n) {
    8000282c:	4795                	li	a5,5
    8000282e:	0497e163          	bltu	a5,s1,80002870 <argraw+0x54>
    80002832:	048a                	slli	s1,s1,0x2
    80002834:	00005717          	auipc	a4,0x5
    80002838:	fa470713          	addi	a4,a4,-92 # 800077d8 <states.0+0x30>
    8000283c:	94ba                	add	s1,s1,a4
    8000283e:	409c                	lw	a5,0(s1)
    80002840:	97ba                	add	a5,a5,a4
    80002842:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002844:	6d3c                	ld	a5,88(a0)
    80002846:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002848:	60e2                	ld	ra,24(sp)
    8000284a:	6442                	ld	s0,16(sp)
    8000284c:	64a2                	ld	s1,8(sp)
    8000284e:	6105                	addi	sp,sp,32
    80002850:	8082                	ret
    return p->trapframe->a1;
    80002852:	6d3c                	ld	a5,88(a0)
    80002854:	7fa8                	ld	a0,120(a5)
    80002856:	bfcd                	j	80002848 <argraw+0x2c>
    return p->trapframe->a2;
    80002858:	6d3c                	ld	a5,88(a0)
    8000285a:	63c8                	ld	a0,128(a5)
    8000285c:	b7f5                	j	80002848 <argraw+0x2c>
    return p->trapframe->a3;
    8000285e:	6d3c                	ld	a5,88(a0)
    80002860:	67c8                	ld	a0,136(a5)
    80002862:	b7dd                	j	80002848 <argraw+0x2c>
    return p->trapframe->a4;
    80002864:	6d3c                	ld	a5,88(a0)
    80002866:	6bc8                	ld	a0,144(a5)
    80002868:	b7c5                	j	80002848 <argraw+0x2c>
    return p->trapframe->a5;
    8000286a:	6d3c                	ld	a5,88(a0)
    8000286c:	6fc8                	ld	a0,152(a5)
    8000286e:	bfe9                	j	80002848 <argraw+0x2c>
  panic("argraw");
    80002870:	00005517          	auipc	a0,0x5
    80002874:	bb850513          	addi	a0,a0,-1096 # 80007428 <etext+0x428>
    80002878:	f1dfd0ef          	jal	80000794 <panic>

000000008000287c <fetchaddr>:
{
    8000287c:	1101                	addi	sp,sp,-32
    8000287e:	ec06                	sd	ra,24(sp)
    80002880:	e822                	sd	s0,16(sp)
    80002882:	e426                	sd	s1,8(sp)
    80002884:	e04a                	sd	s2,0(sp)
    80002886:	1000                	addi	s0,sp,32
    80002888:	84aa                	mv	s1,a0
    8000288a:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000288c:	854ff0ef          	jal	800018e0 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002890:	653c                	ld	a5,72(a0)
    80002892:	02f4f663          	bgeu	s1,a5,800028be <fetchaddr+0x42>
    80002896:	00848713          	addi	a4,s1,8
    8000289a:	02e7e463          	bltu	a5,a4,800028c2 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000289e:	46a1                	li	a3,8
    800028a0:	8626                	mv	a2,s1
    800028a2:	85ca                	mv	a1,s2
    800028a4:	6928                	ld	a0,80(a0)
    800028a6:	d83fe0ef          	jal	80001628 <copyin>
    800028aa:	00a03533          	snez	a0,a0
    800028ae:	40a00533          	neg	a0,a0
}
    800028b2:	60e2                	ld	ra,24(sp)
    800028b4:	6442                	ld	s0,16(sp)
    800028b6:	64a2                	ld	s1,8(sp)
    800028b8:	6902                	ld	s2,0(sp)
    800028ba:	6105                	addi	sp,sp,32
    800028bc:	8082                	ret
    return -1;
    800028be:	557d                	li	a0,-1
    800028c0:	bfcd                	j	800028b2 <fetchaddr+0x36>
    800028c2:	557d                	li	a0,-1
    800028c4:	b7fd                	j	800028b2 <fetchaddr+0x36>

00000000800028c6 <fetchstr>:
{
    800028c6:	7179                	addi	sp,sp,-48
    800028c8:	f406                	sd	ra,40(sp)
    800028ca:	f022                	sd	s0,32(sp)
    800028cc:	ec26                	sd	s1,24(sp)
    800028ce:	e84a                	sd	s2,16(sp)
    800028d0:	e44e                	sd	s3,8(sp)
    800028d2:	1800                	addi	s0,sp,48
    800028d4:	892a                	mv	s2,a0
    800028d6:	84ae                	mv	s1,a1
    800028d8:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    800028da:	806ff0ef          	jal	800018e0 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    800028de:	86ce                	mv	a3,s3
    800028e0:	864a                	mv	a2,s2
    800028e2:	85a6                	mv	a1,s1
    800028e4:	6928                	ld	a0,80(a0)
    800028e6:	dc9fe0ef          	jal	800016ae <copyinstr>
    800028ea:	00054c63          	bltz	a0,80002902 <fetchstr+0x3c>
  return strlen(buf);
    800028ee:	8526                	mv	a0,s1
    800028f0:	d48fe0ef          	jal	80000e38 <strlen>
}
    800028f4:	70a2                	ld	ra,40(sp)
    800028f6:	7402                	ld	s0,32(sp)
    800028f8:	64e2                	ld	s1,24(sp)
    800028fa:	6942                	ld	s2,16(sp)
    800028fc:	69a2                	ld	s3,8(sp)
    800028fe:	6145                	addi	sp,sp,48
    80002900:	8082                	ret
    return -1;
    80002902:	557d                	li	a0,-1
    80002904:	bfc5                	j	800028f4 <fetchstr+0x2e>

0000000080002906 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002906:	1101                	addi	sp,sp,-32
    80002908:	ec06                	sd	ra,24(sp)
    8000290a:	e822                	sd	s0,16(sp)
    8000290c:	e426                	sd	s1,8(sp)
    8000290e:	1000                	addi	s0,sp,32
    80002910:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002912:	f0bff0ef          	jal	8000281c <argraw>
    80002916:	c088                	sw	a0,0(s1)
}
    80002918:	60e2                	ld	ra,24(sp)
    8000291a:	6442                	ld	s0,16(sp)
    8000291c:	64a2                	ld	s1,8(sp)
    8000291e:	6105                	addi	sp,sp,32
    80002920:	8082                	ret

0000000080002922 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002922:	1101                	addi	sp,sp,-32
    80002924:	ec06                	sd	ra,24(sp)
    80002926:	e822                	sd	s0,16(sp)
    80002928:	e426                	sd	s1,8(sp)
    8000292a:	1000                	addi	s0,sp,32
    8000292c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000292e:	eefff0ef          	jal	8000281c <argraw>
    80002932:	e088                	sd	a0,0(s1)
}
    80002934:	60e2                	ld	ra,24(sp)
    80002936:	6442                	ld	s0,16(sp)
    80002938:	64a2                	ld	s1,8(sp)
    8000293a:	6105                	addi	sp,sp,32
    8000293c:	8082                	ret

000000008000293e <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    8000293e:	7179                	addi	sp,sp,-48
    80002940:	f406                	sd	ra,40(sp)
    80002942:	f022                	sd	s0,32(sp)
    80002944:	ec26                	sd	s1,24(sp)
    80002946:	e84a                	sd	s2,16(sp)
    80002948:	1800                	addi	s0,sp,48
    8000294a:	84ae                	mv	s1,a1
    8000294c:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    8000294e:	fd840593          	addi	a1,s0,-40
    80002952:	fd1ff0ef          	jal	80002922 <argaddr>
  return fetchstr(addr, buf, max);
    80002956:	864a                	mv	a2,s2
    80002958:	85a6                	mv	a1,s1
    8000295a:	fd843503          	ld	a0,-40(s0)
    8000295e:	f69ff0ef          	jal	800028c6 <fetchstr>
}
    80002962:	70a2                	ld	ra,40(sp)
    80002964:	7402                	ld	s0,32(sp)
    80002966:	64e2                	ld	s1,24(sp)
    80002968:	6942                	ld	s2,16(sp)
    8000296a:	6145                	addi	sp,sp,48
    8000296c:	8082                	ret

000000008000296e <syscall>:
[SYS_sched_tickets]  sys_sched_tickets,
};

void
syscall(void)
{
    8000296e:	1101                	addi	sp,sp,-32
    80002970:	ec06                	sd	ra,24(sp)
    80002972:	e822                	sd	s0,16(sp)
    80002974:	e426                	sd	s1,8(sp)
    80002976:	e04a                	sd	s2,0(sp)
    80002978:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    8000297a:	f67fe0ef          	jal	800018e0 <myproc>
    8000297e:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002980:	05853903          	ld	s2,88(a0)
    80002984:	0a893783          	ld	a5,168(s2)
    80002988:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    8000298c:	37fd                	addiw	a5,a5,-1
    8000298e:	4759                	li	a4,22
    80002990:	00f76f63          	bltu	a4,a5,800029ae <syscall+0x40>
    80002994:	00369713          	slli	a4,a3,0x3
    80002998:	00005797          	auipc	a5,0x5
    8000299c:	e5878793          	addi	a5,a5,-424 # 800077f0 <syscalls>
    800029a0:	97ba                	add	a5,a5,a4
    800029a2:	639c                	ld	a5,0(a5)
    800029a4:	c789                	beqz	a5,800029ae <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    800029a6:	9782                	jalr	a5
    800029a8:	06a93823          	sd	a0,112(s2)
    800029ac:	a829                	j	800029c6 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    800029ae:	15848613          	addi	a2,s1,344
    800029b2:	588c                	lw	a1,48(s1)
    800029b4:	00005517          	auipc	a0,0x5
    800029b8:	a7c50513          	addi	a0,a0,-1412 # 80007430 <etext+0x430>
    800029bc:	b07fd0ef          	jal	800004c2 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    800029c0:	6cbc                	ld	a5,88(s1)
    800029c2:	577d                	li	a4,-1
    800029c4:	fbb8                	sd	a4,112(a5)
  }
}
    800029c6:	60e2                	ld	ra,24(sp)
    800029c8:	6442                	ld	s0,16(sp)
    800029ca:	64a2                	ld	s1,8(sp)
    800029cc:	6902                	ld	s2,0(sp)
    800029ce:	6105                	addi	sp,sp,32
    800029d0:	8082                	ret

00000000800029d2 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    800029d2:	1101                	addi	sp,sp,-32
    800029d4:	ec06                	sd	ra,24(sp)
    800029d6:	e822                	sd	s0,16(sp)
    800029d8:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800029da:	fec40593          	addi	a1,s0,-20
    800029de:	4501                	li	a0,0
    800029e0:	f27ff0ef          	jal	80002906 <argint>
  exit(n);
    800029e4:	fec42503          	lw	a0,-20(s0)
    800029e8:	e8aff0ef          	jal	80002072 <exit>
  return 0;  // not reached
}
    800029ec:	4501                	li	a0,0
    800029ee:	60e2                	ld	ra,24(sp)
    800029f0:	6442                	ld	s0,16(sp)
    800029f2:	6105                	addi	sp,sp,32
    800029f4:	8082                	ret

00000000800029f6 <sys_getpid>:

uint64
sys_getpid(void)
{
    800029f6:	1141                	addi	sp,sp,-16
    800029f8:	e406                	sd	ra,8(sp)
    800029fa:	e022                	sd	s0,0(sp)
    800029fc:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800029fe:	ee3fe0ef          	jal	800018e0 <myproc>
}
    80002a02:	5908                	lw	a0,48(a0)
    80002a04:	60a2                	ld	ra,8(sp)
    80002a06:	6402                	ld	s0,0(sp)
    80002a08:	0141                	addi	sp,sp,16
    80002a0a:	8082                	ret

0000000080002a0c <sys_fork>:

uint64
sys_fork(void)
{
    80002a0c:	1141                	addi	sp,sp,-16
    80002a0e:	e406                	sd	ra,8(sp)
    80002a10:	e022                	sd	s0,0(sp)
    80002a12:	0800                	addi	s0,sp,16
  return fork();
    80002a14:	a18ff0ef          	jal	80001c2c <fork>
}
    80002a18:	60a2                	ld	ra,8(sp)
    80002a1a:	6402                	ld	s0,0(sp)
    80002a1c:	0141                	addi	sp,sp,16
    80002a1e:	8082                	ret

0000000080002a20 <sys_wait>:

uint64
sys_wait(void)
{
    80002a20:	1101                	addi	sp,sp,-32
    80002a22:	ec06                	sd	ra,24(sp)
    80002a24:	e822                	sd	s0,16(sp)
    80002a26:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002a28:	fe840593          	addi	a1,s0,-24
    80002a2c:	4501                	li	a0,0
    80002a2e:	ef5ff0ef          	jal	80002922 <argaddr>
  return wait(p);
    80002a32:	fe843503          	ld	a0,-24(s0)
    80002a36:	f92ff0ef          	jal	800021c8 <wait>
}
    80002a3a:	60e2                	ld	ra,24(sp)
    80002a3c:	6442                	ld	s0,16(sp)
    80002a3e:	6105                	addi	sp,sp,32
    80002a40:	8082                	ret

0000000080002a42 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002a42:	7179                	addi	sp,sp,-48
    80002a44:	f406                	sd	ra,40(sp)
    80002a46:	f022                	sd	s0,32(sp)
    80002a48:	ec26                	sd	s1,24(sp)
    80002a4a:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002a4c:	fdc40593          	addi	a1,s0,-36
    80002a50:	4501                	li	a0,0
    80002a52:	eb5ff0ef          	jal	80002906 <argint>
  addr = myproc()->sz;
    80002a56:	e8bfe0ef          	jal	800018e0 <myproc>
    80002a5a:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80002a5c:	fdc42503          	lw	a0,-36(s0)
    80002a60:	97cff0ef          	jal	80001bdc <growproc>
    80002a64:	00054863          	bltz	a0,80002a74 <sys_sbrk+0x32>
    return -1;
  return addr;
}
    80002a68:	8526                	mv	a0,s1
    80002a6a:	70a2                	ld	ra,40(sp)
    80002a6c:	7402                	ld	s0,32(sp)
    80002a6e:	64e2                	ld	s1,24(sp)
    80002a70:	6145                	addi	sp,sp,48
    80002a72:	8082                	ret
    return -1;
    80002a74:	54fd                	li	s1,-1
    80002a76:	bfcd                	j	80002a68 <sys_sbrk+0x26>

0000000080002a78 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002a78:	7139                	addi	sp,sp,-64
    80002a7a:	fc06                	sd	ra,56(sp)
    80002a7c:	f822                	sd	s0,48(sp)
    80002a7e:	f04a                	sd	s2,32(sp)
    80002a80:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002a82:	fcc40593          	addi	a1,s0,-52
    80002a86:	4501                	li	a0,0
    80002a88:	e7fff0ef          	jal	80002906 <argint>
  if(n < 0)
    80002a8c:	fcc42783          	lw	a5,-52(s0)
    80002a90:	0607c763          	bltz	a5,80002afe <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80002a94:	00016517          	auipc	a0,0x16
    80002a98:	bec50513          	addi	a0,a0,-1044 # 80018680 <tickslock>
    80002a9c:	958fe0ef          	jal	80000bf4 <acquire>
  ticks0 = ticks;
    80002aa0:	00008917          	auipc	s2,0x8
    80002aa4:	88892903          	lw	s2,-1912(s2) # 8000a328 <ticks>
  while(ticks - ticks0 < n){
    80002aa8:	fcc42783          	lw	a5,-52(s0)
    80002aac:	cf8d                	beqz	a5,80002ae6 <sys_sleep+0x6e>
    80002aae:	f426                	sd	s1,40(sp)
    80002ab0:	ec4e                	sd	s3,24(sp)
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002ab2:	00016997          	auipc	s3,0x16
    80002ab6:	bce98993          	addi	s3,s3,-1074 # 80018680 <tickslock>
    80002aba:	00008497          	auipc	s1,0x8
    80002abe:	86e48493          	addi	s1,s1,-1938 # 8000a328 <ticks>
    if(killed(myproc())){
    80002ac2:	e1ffe0ef          	jal	800018e0 <myproc>
    80002ac6:	ed8ff0ef          	jal	8000219e <killed>
    80002aca:	ed0d                	bnez	a0,80002b04 <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80002acc:	85ce                	mv	a1,s3
    80002ace:	8526                	mv	a0,s1
    80002ad0:	c96ff0ef          	jal	80001f66 <sleep>
  while(ticks - ticks0 < n){
    80002ad4:	409c                	lw	a5,0(s1)
    80002ad6:	412787bb          	subw	a5,a5,s2
    80002ada:	fcc42703          	lw	a4,-52(s0)
    80002ade:	fee7e2e3          	bltu	a5,a4,80002ac2 <sys_sleep+0x4a>
    80002ae2:	74a2                	ld	s1,40(sp)
    80002ae4:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002ae6:	00016517          	auipc	a0,0x16
    80002aea:	b9a50513          	addi	a0,a0,-1126 # 80018680 <tickslock>
    80002aee:	99efe0ef          	jal	80000c8c <release>
  return 0;
    80002af2:	4501                	li	a0,0
}
    80002af4:	70e2                	ld	ra,56(sp)
    80002af6:	7442                	ld	s0,48(sp)
    80002af8:	7902                	ld	s2,32(sp)
    80002afa:	6121                	addi	sp,sp,64
    80002afc:	8082                	ret
    n = 0;
    80002afe:	fc042623          	sw	zero,-52(s0)
    80002b02:	bf49                	j	80002a94 <sys_sleep+0x1c>
      release(&tickslock);
    80002b04:	00016517          	auipc	a0,0x16
    80002b08:	b7c50513          	addi	a0,a0,-1156 # 80018680 <tickslock>
    80002b0c:	980fe0ef          	jal	80000c8c <release>
      return -1;
    80002b10:	557d                	li	a0,-1
    80002b12:	74a2                	ld	s1,40(sp)
    80002b14:	69e2                	ld	s3,24(sp)
    80002b16:	bff9                	j	80002af4 <sys_sleep+0x7c>

0000000080002b18 <sys_kill>:

uint64
sys_kill(void)
{
    80002b18:	1101                	addi	sp,sp,-32
    80002b1a:	ec06                	sd	ra,24(sp)
    80002b1c:	e822                	sd	s0,16(sp)
    80002b1e:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002b20:	fec40593          	addi	a1,s0,-20
    80002b24:	4501                	li	a0,0
    80002b26:	de1ff0ef          	jal	80002906 <argint>
  return kill(pid);
    80002b2a:	fec42503          	lw	a0,-20(s0)
    80002b2e:	de6ff0ef          	jal	80002114 <kill>
}
    80002b32:	60e2                	ld	ra,24(sp)
    80002b34:	6442                	ld	s0,16(sp)
    80002b36:	6105                	addi	sp,sp,32
    80002b38:	8082                	ret

0000000080002b3a <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002b3a:	1101                	addi	sp,sp,-32
    80002b3c:	ec06                	sd	ra,24(sp)
    80002b3e:	e822                	sd	s0,16(sp)
    80002b40:	e426                	sd	s1,8(sp)
    80002b42:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002b44:	00016517          	auipc	a0,0x16
    80002b48:	b3c50513          	addi	a0,a0,-1220 # 80018680 <tickslock>
    80002b4c:	8a8fe0ef          	jal	80000bf4 <acquire>
  xticks = ticks;
    80002b50:	00007497          	auipc	s1,0x7
    80002b54:	7d84a483          	lw	s1,2008(s1) # 8000a328 <ticks>
  release(&tickslock);
    80002b58:	00016517          	auipc	a0,0x16
    80002b5c:	b2850513          	addi	a0,a0,-1240 # 80018680 <tickslock>
    80002b60:	92cfe0ef          	jal	80000c8c <release>
  return xticks;
}
    80002b64:	02049513          	slli	a0,s1,0x20
    80002b68:	9101                	srli	a0,a0,0x20
    80002b6a:	60e2                	ld	ra,24(sp)
    80002b6c:	6442                	ld	s0,16(sp)
    80002b6e:	64a2                	ld	s1,8(sp)
    80002b70:	6105                	addi	sp,sp,32
    80002b72:	8082                	ret

0000000080002b74 <sys_sched_statistics>:

uint64
sys_sched_statistics(void)
{
    80002b74:	1141                	addi	sp,sp,-16
    80002b76:	e406                	sd	ra,8(sp)
    80002b78:	e022                	sd	s0,0(sp)
    80002b7a:	0800                	addi	s0,sp,16
  int result = sched_statistics();
    80002b7c:	87fff0ef          	jal	800023fa <sched_statistics>
  return result;
}
    80002b80:	60a2                	ld	ra,8(sp)
    80002b82:	6402                	ld	s0,0(sp)
    80002b84:	0141                	addi	sp,sp,16
    80002b86:	8082                	ret

0000000080002b88 <sys_sched_tickets>:

uint64
sys_sched_tickets(void)
{
    80002b88:	1101                	addi	sp,sp,-32
    80002b8a:	ec06                	sd	ra,24(sp)
    80002b8c:	e822                	sd	s0,16(sp)
    80002b8e:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002b90:	fec40593          	addi	a1,s0,-20
    80002b94:	4501                	li	a0,0
    80002b96:	d71ff0ef          	jal	80002906 <argint>
  return sched_tickets(n);
    80002b9a:	fec42503          	lw	a0,-20(s0)
    80002b9e:	8c3ff0ef          	jal	80002460 <sched_tickets>
}
    80002ba2:	60e2                	ld	ra,24(sp)
    80002ba4:	6442                	ld	s0,16(sp)
    80002ba6:	6105                	addi	sp,sp,32
    80002ba8:	8082                	ret

0000000080002baa <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002baa:	7179                	addi	sp,sp,-48
    80002bac:	f406                	sd	ra,40(sp)
    80002bae:	f022                	sd	s0,32(sp)
    80002bb0:	ec26                	sd	s1,24(sp)
    80002bb2:	e84a                	sd	s2,16(sp)
    80002bb4:	e44e                	sd	s3,8(sp)
    80002bb6:	e052                	sd	s4,0(sp)
    80002bb8:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002bba:	00005597          	auipc	a1,0x5
    80002bbe:	89658593          	addi	a1,a1,-1898 # 80007450 <etext+0x450>
    80002bc2:	00016517          	auipc	a0,0x16
    80002bc6:	ad650513          	addi	a0,a0,-1322 # 80018698 <bcache>
    80002bca:	fabfd0ef          	jal	80000b74 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002bce:	0001e797          	auipc	a5,0x1e
    80002bd2:	aca78793          	addi	a5,a5,-1334 # 80020698 <bcache+0x8000>
    80002bd6:	0001e717          	auipc	a4,0x1e
    80002bda:	d2a70713          	addi	a4,a4,-726 # 80020900 <bcache+0x8268>
    80002bde:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002be2:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002be6:	00016497          	auipc	s1,0x16
    80002bea:	aca48493          	addi	s1,s1,-1334 # 800186b0 <bcache+0x18>
    b->next = bcache.head.next;
    80002bee:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002bf0:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002bf2:	00005a17          	auipc	s4,0x5
    80002bf6:	866a0a13          	addi	s4,s4,-1946 # 80007458 <etext+0x458>
    b->next = bcache.head.next;
    80002bfa:	2b893783          	ld	a5,696(s2)
    80002bfe:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002c00:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002c04:	85d2                	mv	a1,s4
    80002c06:	01048513          	addi	a0,s1,16
    80002c0a:	248010ef          	jal	80003e52 <initsleeplock>
    bcache.head.next->prev = b;
    80002c0e:	2b893783          	ld	a5,696(s2)
    80002c12:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002c14:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002c18:	45848493          	addi	s1,s1,1112
    80002c1c:	fd349fe3          	bne	s1,s3,80002bfa <binit+0x50>
  }
}
    80002c20:	70a2                	ld	ra,40(sp)
    80002c22:	7402                	ld	s0,32(sp)
    80002c24:	64e2                	ld	s1,24(sp)
    80002c26:	6942                	ld	s2,16(sp)
    80002c28:	69a2                	ld	s3,8(sp)
    80002c2a:	6a02                	ld	s4,0(sp)
    80002c2c:	6145                	addi	sp,sp,48
    80002c2e:	8082                	ret

0000000080002c30 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002c30:	7179                	addi	sp,sp,-48
    80002c32:	f406                	sd	ra,40(sp)
    80002c34:	f022                	sd	s0,32(sp)
    80002c36:	ec26                	sd	s1,24(sp)
    80002c38:	e84a                	sd	s2,16(sp)
    80002c3a:	e44e                	sd	s3,8(sp)
    80002c3c:	1800                	addi	s0,sp,48
    80002c3e:	892a                	mv	s2,a0
    80002c40:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c42:	00016517          	auipc	a0,0x16
    80002c46:	a5650513          	addi	a0,a0,-1450 # 80018698 <bcache>
    80002c4a:	fabfd0ef          	jal	80000bf4 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002c4e:	0001e497          	auipc	s1,0x1e
    80002c52:	d024b483          	ld	s1,-766(s1) # 80020950 <bcache+0x82b8>
    80002c56:	0001e797          	auipc	a5,0x1e
    80002c5a:	caa78793          	addi	a5,a5,-854 # 80020900 <bcache+0x8268>
    80002c5e:	02f48b63          	beq	s1,a5,80002c94 <bread+0x64>
    80002c62:	873e                	mv	a4,a5
    80002c64:	a021                	j	80002c6c <bread+0x3c>
    80002c66:	68a4                	ld	s1,80(s1)
    80002c68:	02e48663          	beq	s1,a4,80002c94 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002c6c:	449c                	lw	a5,8(s1)
    80002c6e:	ff279ce3          	bne	a5,s2,80002c66 <bread+0x36>
    80002c72:	44dc                	lw	a5,12(s1)
    80002c74:	ff3799e3          	bne	a5,s3,80002c66 <bread+0x36>
      b->refcnt++;
    80002c78:	40bc                	lw	a5,64(s1)
    80002c7a:	2785                	addiw	a5,a5,1
    80002c7c:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c7e:	00016517          	auipc	a0,0x16
    80002c82:	a1a50513          	addi	a0,a0,-1510 # 80018698 <bcache>
    80002c86:	806fe0ef          	jal	80000c8c <release>
      acquiresleep(&b->lock);
    80002c8a:	01048513          	addi	a0,s1,16
    80002c8e:	1fa010ef          	jal	80003e88 <acquiresleep>
      return b;
    80002c92:	a889                	j	80002ce4 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c94:	0001e497          	auipc	s1,0x1e
    80002c98:	cb44b483          	ld	s1,-844(s1) # 80020948 <bcache+0x82b0>
    80002c9c:	0001e797          	auipc	a5,0x1e
    80002ca0:	c6478793          	addi	a5,a5,-924 # 80020900 <bcache+0x8268>
    80002ca4:	00f48863          	beq	s1,a5,80002cb4 <bread+0x84>
    80002ca8:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002caa:	40bc                	lw	a5,64(s1)
    80002cac:	cb91                	beqz	a5,80002cc0 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002cae:	64a4                	ld	s1,72(s1)
    80002cb0:	fee49de3          	bne	s1,a4,80002caa <bread+0x7a>
  panic("bget: no buffers");
    80002cb4:	00004517          	auipc	a0,0x4
    80002cb8:	7ac50513          	addi	a0,a0,1964 # 80007460 <etext+0x460>
    80002cbc:	ad9fd0ef          	jal	80000794 <panic>
      b->dev = dev;
    80002cc0:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002cc4:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002cc8:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002ccc:	4785                	li	a5,1
    80002cce:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002cd0:	00016517          	auipc	a0,0x16
    80002cd4:	9c850513          	addi	a0,a0,-1592 # 80018698 <bcache>
    80002cd8:	fb5fd0ef          	jal	80000c8c <release>
      acquiresleep(&b->lock);
    80002cdc:	01048513          	addi	a0,s1,16
    80002ce0:	1a8010ef          	jal	80003e88 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002ce4:	409c                	lw	a5,0(s1)
    80002ce6:	cb89                	beqz	a5,80002cf8 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002ce8:	8526                	mv	a0,s1
    80002cea:	70a2                	ld	ra,40(sp)
    80002cec:	7402                	ld	s0,32(sp)
    80002cee:	64e2                	ld	s1,24(sp)
    80002cf0:	6942                	ld	s2,16(sp)
    80002cf2:	69a2                	ld	s3,8(sp)
    80002cf4:	6145                	addi	sp,sp,48
    80002cf6:	8082                	ret
    virtio_disk_rw(b, 0);
    80002cf8:	4581                	li	a1,0
    80002cfa:	8526                	mv	a0,s1
    80002cfc:	1e5020ef          	jal	800056e0 <virtio_disk_rw>
    b->valid = 1;
    80002d00:	4785                	li	a5,1
    80002d02:	c09c                	sw	a5,0(s1)
  return b;
    80002d04:	b7d5                	j	80002ce8 <bread+0xb8>

0000000080002d06 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002d06:	1101                	addi	sp,sp,-32
    80002d08:	ec06                	sd	ra,24(sp)
    80002d0a:	e822                	sd	s0,16(sp)
    80002d0c:	e426                	sd	s1,8(sp)
    80002d0e:	1000                	addi	s0,sp,32
    80002d10:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002d12:	0541                	addi	a0,a0,16
    80002d14:	1f2010ef          	jal	80003f06 <holdingsleep>
    80002d18:	c911                	beqz	a0,80002d2c <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002d1a:	4585                	li	a1,1
    80002d1c:	8526                	mv	a0,s1
    80002d1e:	1c3020ef          	jal	800056e0 <virtio_disk_rw>
}
    80002d22:	60e2                	ld	ra,24(sp)
    80002d24:	6442                	ld	s0,16(sp)
    80002d26:	64a2                	ld	s1,8(sp)
    80002d28:	6105                	addi	sp,sp,32
    80002d2a:	8082                	ret
    panic("bwrite");
    80002d2c:	00004517          	auipc	a0,0x4
    80002d30:	74c50513          	addi	a0,a0,1868 # 80007478 <etext+0x478>
    80002d34:	a61fd0ef          	jal	80000794 <panic>

0000000080002d38 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002d38:	1101                	addi	sp,sp,-32
    80002d3a:	ec06                	sd	ra,24(sp)
    80002d3c:	e822                	sd	s0,16(sp)
    80002d3e:	e426                	sd	s1,8(sp)
    80002d40:	e04a                	sd	s2,0(sp)
    80002d42:	1000                	addi	s0,sp,32
    80002d44:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002d46:	01050913          	addi	s2,a0,16
    80002d4a:	854a                	mv	a0,s2
    80002d4c:	1ba010ef          	jal	80003f06 <holdingsleep>
    80002d50:	c135                	beqz	a0,80002db4 <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002d52:	854a                	mv	a0,s2
    80002d54:	17a010ef          	jal	80003ece <releasesleep>

  acquire(&bcache.lock);
    80002d58:	00016517          	auipc	a0,0x16
    80002d5c:	94050513          	addi	a0,a0,-1728 # 80018698 <bcache>
    80002d60:	e95fd0ef          	jal	80000bf4 <acquire>
  b->refcnt--;
    80002d64:	40bc                	lw	a5,64(s1)
    80002d66:	37fd                	addiw	a5,a5,-1
    80002d68:	0007871b          	sext.w	a4,a5
    80002d6c:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002d6e:	e71d                	bnez	a4,80002d9c <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002d70:	68b8                	ld	a4,80(s1)
    80002d72:	64bc                	ld	a5,72(s1)
    80002d74:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002d76:	68b8                	ld	a4,80(s1)
    80002d78:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002d7a:	0001e797          	auipc	a5,0x1e
    80002d7e:	91e78793          	addi	a5,a5,-1762 # 80020698 <bcache+0x8000>
    80002d82:	2b87b703          	ld	a4,696(a5)
    80002d86:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d88:	0001e717          	auipc	a4,0x1e
    80002d8c:	b7870713          	addi	a4,a4,-1160 # 80020900 <bcache+0x8268>
    80002d90:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d92:	2b87b703          	ld	a4,696(a5)
    80002d96:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d98:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002d9c:	00016517          	auipc	a0,0x16
    80002da0:	8fc50513          	addi	a0,a0,-1796 # 80018698 <bcache>
    80002da4:	ee9fd0ef          	jal	80000c8c <release>
}
    80002da8:	60e2                	ld	ra,24(sp)
    80002daa:	6442                	ld	s0,16(sp)
    80002dac:	64a2                	ld	s1,8(sp)
    80002dae:	6902                	ld	s2,0(sp)
    80002db0:	6105                	addi	sp,sp,32
    80002db2:	8082                	ret
    panic("brelse");
    80002db4:	00004517          	auipc	a0,0x4
    80002db8:	6cc50513          	addi	a0,a0,1740 # 80007480 <etext+0x480>
    80002dbc:	9d9fd0ef          	jal	80000794 <panic>

0000000080002dc0 <bpin>:

void
bpin(struct buf *b) {
    80002dc0:	1101                	addi	sp,sp,-32
    80002dc2:	ec06                	sd	ra,24(sp)
    80002dc4:	e822                	sd	s0,16(sp)
    80002dc6:	e426                	sd	s1,8(sp)
    80002dc8:	1000                	addi	s0,sp,32
    80002dca:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002dcc:	00016517          	auipc	a0,0x16
    80002dd0:	8cc50513          	addi	a0,a0,-1844 # 80018698 <bcache>
    80002dd4:	e21fd0ef          	jal	80000bf4 <acquire>
  b->refcnt++;
    80002dd8:	40bc                	lw	a5,64(s1)
    80002dda:	2785                	addiw	a5,a5,1
    80002ddc:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002dde:	00016517          	auipc	a0,0x16
    80002de2:	8ba50513          	addi	a0,a0,-1862 # 80018698 <bcache>
    80002de6:	ea7fd0ef          	jal	80000c8c <release>
}
    80002dea:	60e2                	ld	ra,24(sp)
    80002dec:	6442                	ld	s0,16(sp)
    80002dee:	64a2                	ld	s1,8(sp)
    80002df0:	6105                	addi	sp,sp,32
    80002df2:	8082                	ret

0000000080002df4 <bunpin>:

void
bunpin(struct buf *b) {
    80002df4:	1101                	addi	sp,sp,-32
    80002df6:	ec06                	sd	ra,24(sp)
    80002df8:	e822                	sd	s0,16(sp)
    80002dfa:	e426                	sd	s1,8(sp)
    80002dfc:	1000                	addi	s0,sp,32
    80002dfe:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e00:	00016517          	auipc	a0,0x16
    80002e04:	89850513          	addi	a0,a0,-1896 # 80018698 <bcache>
    80002e08:	dedfd0ef          	jal	80000bf4 <acquire>
  b->refcnt--;
    80002e0c:	40bc                	lw	a5,64(s1)
    80002e0e:	37fd                	addiw	a5,a5,-1
    80002e10:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e12:	00016517          	auipc	a0,0x16
    80002e16:	88650513          	addi	a0,a0,-1914 # 80018698 <bcache>
    80002e1a:	e73fd0ef          	jal	80000c8c <release>
}
    80002e1e:	60e2                	ld	ra,24(sp)
    80002e20:	6442                	ld	s0,16(sp)
    80002e22:	64a2                	ld	s1,8(sp)
    80002e24:	6105                	addi	sp,sp,32
    80002e26:	8082                	ret

0000000080002e28 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002e28:	1101                	addi	sp,sp,-32
    80002e2a:	ec06                	sd	ra,24(sp)
    80002e2c:	e822                	sd	s0,16(sp)
    80002e2e:	e426                	sd	s1,8(sp)
    80002e30:	e04a                	sd	s2,0(sp)
    80002e32:	1000                	addi	s0,sp,32
    80002e34:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002e36:	00d5d59b          	srliw	a1,a1,0xd
    80002e3a:	0001e797          	auipc	a5,0x1e
    80002e3e:	f3a7a783          	lw	a5,-198(a5) # 80020d74 <sb+0x1c>
    80002e42:	9dbd                	addw	a1,a1,a5
    80002e44:	dedff0ef          	jal	80002c30 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002e48:	0074f713          	andi	a4,s1,7
    80002e4c:	4785                	li	a5,1
    80002e4e:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    80002e52:	14ce                	slli	s1,s1,0x33
    80002e54:	90d9                	srli	s1,s1,0x36
    80002e56:	00950733          	add	a4,a0,s1
    80002e5a:	05874703          	lbu	a4,88(a4)
    80002e5e:	00e7f6b3          	and	a3,a5,a4
    80002e62:	c29d                	beqz	a3,80002e88 <bfree+0x60>
    80002e64:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002e66:	94aa                	add	s1,s1,a0
    80002e68:	fff7c793          	not	a5,a5
    80002e6c:	8f7d                	and	a4,a4,a5
    80002e6e:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002e72:	711000ef          	jal	80003d82 <log_write>
  brelse(bp);
    80002e76:	854a                	mv	a0,s2
    80002e78:	ec1ff0ef          	jal	80002d38 <brelse>
}
    80002e7c:	60e2                	ld	ra,24(sp)
    80002e7e:	6442                	ld	s0,16(sp)
    80002e80:	64a2                	ld	s1,8(sp)
    80002e82:	6902                	ld	s2,0(sp)
    80002e84:	6105                	addi	sp,sp,32
    80002e86:	8082                	ret
    panic("freeing free block");
    80002e88:	00004517          	auipc	a0,0x4
    80002e8c:	60050513          	addi	a0,a0,1536 # 80007488 <etext+0x488>
    80002e90:	905fd0ef          	jal	80000794 <panic>

0000000080002e94 <balloc>:
{
    80002e94:	711d                	addi	sp,sp,-96
    80002e96:	ec86                	sd	ra,88(sp)
    80002e98:	e8a2                	sd	s0,80(sp)
    80002e9a:	e4a6                	sd	s1,72(sp)
    80002e9c:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80002e9e:	0001e797          	auipc	a5,0x1e
    80002ea2:	ebe7a783          	lw	a5,-322(a5) # 80020d5c <sb+0x4>
    80002ea6:	0e078f63          	beqz	a5,80002fa4 <balloc+0x110>
    80002eaa:	e0ca                	sd	s2,64(sp)
    80002eac:	fc4e                	sd	s3,56(sp)
    80002eae:	f852                	sd	s4,48(sp)
    80002eb0:	f456                	sd	s5,40(sp)
    80002eb2:	f05a                	sd	s6,32(sp)
    80002eb4:	ec5e                	sd	s7,24(sp)
    80002eb6:	e862                	sd	s8,16(sp)
    80002eb8:	e466                	sd	s9,8(sp)
    80002eba:	8baa                	mv	s7,a0
    80002ebc:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002ebe:	0001eb17          	auipc	s6,0x1e
    80002ec2:	e9ab0b13          	addi	s6,s6,-358 # 80020d58 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002ec6:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80002ec8:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002eca:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002ecc:	6c89                	lui	s9,0x2
    80002ece:	a0b5                	j	80002f3a <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002ed0:	97ca                	add	a5,a5,s2
    80002ed2:	8e55                	or	a2,a2,a3
    80002ed4:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002ed8:	854a                	mv	a0,s2
    80002eda:	6a9000ef          	jal	80003d82 <log_write>
        brelse(bp);
    80002ede:	854a                	mv	a0,s2
    80002ee0:	e59ff0ef          	jal	80002d38 <brelse>
  bp = bread(dev, bno);
    80002ee4:	85a6                	mv	a1,s1
    80002ee6:	855e                	mv	a0,s7
    80002ee8:	d49ff0ef          	jal	80002c30 <bread>
    80002eec:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002eee:	40000613          	li	a2,1024
    80002ef2:	4581                	li	a1,0
    80002ef4:	05850513          	addi	a0,a0,88
    80002ef8:	dd1fd0ef          	jal	80000cc8 <memset>
  log_write(bp);
    80002efc:	854a                	mv	a0,s2
    80002efe:	685000ef          	jal	80003d82 <log_write>
  brelse(bp);
    80002f02:	854a                	mv	a0,s2
    80002f04:	e35ff0ef          	jal	80002d38 <brelse>
}
    80002f08:	6906                	ld	s2,64(sp)
    80002f0a:	79e2                	ld	s3,56(sp)
    80002f0c:	7a42                	ld	s4,48(sp)
    80002f0e:	7aa2                	ld	s5,40(sp)
    80002f10:	7b02                	ld	s6,32(sp)
    80002f12:	6be2                	ld	s7,24(sp)
    80002f14:	6c42                	ld	s8,16(sp)
    80002f16:	6ca2                	ld	s9,8(sp)
}
    80002f18:	8526                	mv	a0,s1
    80002f1a:	60e6                	ld	ra,88(sp)
    80002f1c:	6446                	ld	s0,80(sp)
    80002f1e:	64a6                	ld	s1,72(sp)
    80002f20:	6125                	addi	sp,sp,96
    80002f22:	8082                	ret
    brelse(bp);
    80002f24:	854a                	mv	a0,s2
    80002f26:	e13ff0ef          	jal	80002d38 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002f2a:	015c87bb          	addw	a5,s9,s5
    80002f2e:	00078a9b          	sext.w	s5,a5
    80002f32:	004b2703          	lw	a4,4(s6)
    80002f36:	04eaff63          	bgeu	s5,a4,80002f94 <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    80002f3a:	41fad79b          	sraiw	a5,s5,0x1f
    80002f3e:	0137d79b          	srliw	a5,a5,0x13
    80002f42:	015787bb          	addw	a5,a5,s5
    80002f46:	40d7d79b          	sraiw	a5,a5,0xd
    80002f4a:	01cb2583          	lw	a1,28(s6)
    80002f4e:	9dbd                	addw	a1,a1,a5
    80002f50:	855e                	mv	a0,s7
    80002f52:	cdfff0ef          	jal	80002c30 <bread>
    80002f56:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f58:	004b2503          	lw	a0,4(s6)
    80002f5c:	000a849b          	sext.w	s1,s5
    80002f60:	8762                	mv	a4,s8
    80002f62:	fca4f1e3          	bgeu	s1,a0,80002f24 <balloc+0x90>
      m = 1 << (bi % 8);
    80002f66:	00777693          	andi	a3,a4,7
    80002f6a:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002f6e:	41f7579b          	sraiw	a5,a4,0x1f
    80002f72:	01d7d79b          	srliw	a5,a5,0x1d
    80002f76:	9fb9                	addw	a5,a5,a4
    80002f78:	4037d79b          	sraiw	a5,a5,0x3
    80002f7c:	00f90633          	add	a2,s2,a5
    80002f80:	05864603          	lbu	a2,88(a2)
    80002f84:	00c6f5b3          	and	a1,a3,a2
    80002f88:	d5a1                	beqz	a1,80002ed0 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f8a:	2705                	addiw	a4,a4,1
    80002f8c:	2485                	addiw	s1,s1,1
    80002f8e:	fd471ae3          	bne	a4,s4,80002f62 <balloc+0xce>
    80002f92:	bf49                	j	80002f24 <balloc+0x90>
    80002f94:	6906                	ld	s2,64(sp)
    80002f96:	79e2                	ld	s3,56(sp)
    80002f98:	7a42                	ld	s4,48(sp)
    80002f9a:	7aa2                	ld	s5,40(sp)
    80002f9c:	7b02                	ld	s6,32(sp)
    80002f9e:	6be2                	ld	s7,24(sp)
    80002fa0:	6c42                	ld	s8,16(sp)
    80002fa2:	6ca2                	ld	s9,8(sp)
  printf("balloc: out of blocks\n");
    80002fa4:	00004517          	auipc	a0,0x4
    80002fa8:	4fc50513          	addi	a0,a0,1276 # 800074a0 <etext+0x4a0>
    80002fac:	d16fd0ef          	jal	800004c2 <printf>
  return 0;
    80002fb0:	4481                	li	s1,0
    80002fb2:	b79d                	j	80002f18 <balloc+0x84>

0000000080002fb4 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002fb4:	7179                	addi	sp,sp,-48
    80002fb6:	f406                	sd	ra,40(sp)
    80002fb8:	f022                	sd	s0,32(sp)
    80002fba:	ec26                	sd	s1,24(sp)
    80002fbc:	e84a                	sd	s2,16(sp)
    80002fbe:	e44e                	sd	s3,8(sp)
    80002fc0:	1800                	addi	s0,sp,48
    80002fc2:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002fc4:	47ad                	li	a5,11
    80002fc6:	02b7e663          	bltu	a5,a1,80002ff2 <bmap+0x3e>
    if((addr = ip->addrs[bn]) == 0){
    80002fca:	02059793          	slli	a5,a1,0x20
    80002fce:	01e7d593          	srli	a1,a5,0x1e
    80002fd2:	00b504b3          	add	s1,a0,a1
    80002fd6:	0504a903          	lw	s2,80(s1)
    80002fda:	06091a63          	bnez	s2,8000304e <bmap+0x9a>
      addr = balloc(ip->dev);
    80002fde:	4108                	lw	a0,0(a0)
    80002fe0:	eb5ff0ef          	jal	80002e94 <balloc>
    80002fe4:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002fe8:	06090363          	beqz	s2,8000304e <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    80002fec:	0524a823          	sw	s2,80(s1)
    80002ff0:	a8b9                	j	8000304e <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002ff2:	ff45849b          	addiw	s1,a1,-12
    80002ff6:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80002ffa:	0ff00793          	li	a5,255
    80002ffe:	06e7ee63          	bltu	a5,a4,8000307a <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80003002:	08052903          	lw	s2,128(a0)
    80003006:	00091d63          	bnez	s2,80003020 <bmap+0x6c>
      addr = balloc(ip->dev);
    8000300a:	4108                	lw	a0,0(a0)
    8000300c:	e89ff0ef          	jal	80002e94 <balloc>
    80003010:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003014:	02090d63          	beqz	s2,8000304e <bmap+0x9a>
    80003018:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000301a:	0929a023          	sw	s2,128(s3)
    8000301e:	a011                	j	80003022 <bmap+0x6e>
    80003020:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80003022:	85ca                	mv	a1,s2
    80003024:	0009a503          	lw	a0,0(s3)
    80003028:	c09ff0ef          	jal	80002c30 <bread>
    8000302c:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    8000302e:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80003032:	02049713          	slli	a4,s1,0x20
    80003036:	01e75593          	srli	a1,a4,0x1e
    8000303a:	00b784b3          	add	s1,a5,a1
    8000303e:	0004a903          	lw	s2,0(s1)
    80003042:	00090e63          	beqz	s2,8000305e <bmap+0xaa>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003046:	8552                	mv	a0,s4
    80003048:	cf1ff0ef          	jal	80002d38 <brelse>
    return addr;
    8000304c:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000304e:	854a                	mv	a0,s2
    80003050:	70a2                	ld	ra,40(sp)
    80003052:	7402                	ld	s0,32(sp)
    80003054:	64e2                	ld	s1,24(sp)
    80003056:	6942                	ld	s2,16(sp)
    80003058:	69a2                	ld	s3,8(sp)
    8000305a:	6145                	addi	sp,sp,48
    8000305c:	8082                	ret
      addr = balloc(ip->dev);
    8000305e:	0009a503          	lw	a0,0(s3)
    80003062:	e33ff0ef          	jal	80002e94 <balloc>
    80003066:	0005091b          	sext.w	s2,a0
      if(addr){
    8000306a:	fc090ee3          	beqz	s2,80003046 <bmap+0x92>
        a[bn] = addr;
    8000306e:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80003072:	8552                	mv	a0,s4
    80003074:	50f000ef          	jal	80003d82 <log_write>
    80003078:	b7f9                	j	80003046 <bmap+0x92>
    8000307a:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000307c:	00004517          	auipc	a0,0x4
    80003080:	43c50513          	addi	a0,a0,1084 # 800074b8 <etext+0x4b8>
    80003084:	f10fd0ef          	jal	80000794 <panic>

0000000080003088 <iget>:
{
    80003088:	7179                	addi	sp,sp,-48
    8000308a:	f406                	sd	ra,40(sp)
    8000308c:	f022                	sd	s0,32(sp)
    8000308e:	ec26                	sd	s1,24(sp)
    80003090:	e84a                	sd	s2,16(sp)
    80003092:	e44e                	sd	s3,8(sp)
    80003094:	e052                	sd	s4,0(sp)
    80003096:	1800                	addi	s0,sp,48
    80003098:	89aa                	mv	s3,a0
    8000309a:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000309c:	0001e517          	auipc	a0,0x1e
    800030a0:	cdc50513          	addi	a0,a0,-804 # 80020d78 <itable>
    800030a4:	b51fd0ef          	jal	80000bf4 <acquire>
  empty = 0;
    800030a8:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800030aa:	0001e497          	auipc	s1,0x1e
    800030ae:	ce648493          	addi	s1,s1,-794 # 80020d90 <itable+0x18>
    800030b2:	0001f697          	auipc	a3,0x1f
    800030b6:	76e68693          	addi	a3,a3,1902 # 80022820 <log>
    800030ba:	a039                	j	800030c8 <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800030bc:	02090963          	beqz	s2,800030ee <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800030c0:	08848493          	addi	s1,s1,136
    800030c4:	02d48863          	beq	s1,a3,800030f4 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800030c8:	449c                	lw	a5,8(s1)
    800030ca:	fef059e3          	blez	a5,800030bc <iget+0x34>
    800030ce:	4098                	lw	a4,0(s1)
    800030d0:	ff3716e3          	bne	a4,s3,800030bc <iget+0x34>
    800030d4:	40d8                	lw	a4,4(s1)
    800030d6:	ff4713e3          	bne	a4,s4,800030bc <iget+0x34>
      ip->ref++;
    800030da:	2785                	addiw	a5,a5,1
    800030dc:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800030de:	0001e517          	auipc	a0,0x1e
    800030e2:	c9a50513          	addi	a0,a0,-870 # 80020d78 <itable>
    800030e6:	ba7fd0ef          	jal	80000c8c <release>
      return ip;
    800030ea:	8926                	mv	s2,s1
    800030ec:	a02d                	j	80003116 <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800030ee:	fbe9                	bnez	a5,800030c0 <iget+0x38>
      empty = ip;
    800030f0:	8926                	mv	s2,s1
    800030f2:	b7f9                	j	800030c0 <iget+0x38>
  if(empty == 0)
    800030f4:	02090a63          	beqz	s2,80003128 <iget+0xa0>
  ip->dev = dev;
    800030f8:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800030fc:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003100:	4785                	li	a5,1
    80003102:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003106:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000310a:	0001e517          	auipc	a0,0x1e
    8000310e:	c6e50513          	addi	a0,a0,-914 # 80020d78 <itable>
    80003112:	b7bfd0ef          	jal	80000c8c <release>
}
    80003116:	854a                	mv	a0,s2
    80003118:	70a2                	ld	ra,40(sp)
    8000311a:	7402                	ld	s0,32(sp)
    8000311c:	64e2                	ld	s1,24(sp)
    8000311e:	6942                	ld	s2,16(sp)
    80003120:	69a2                	ld	s3,8(sp)
    80003122:	6a02                	ld	s4,0(sp)
    80003124:	6145                	addi	sp,sp,48
    80003126:	8082                	ret
    panic("iget: no inodes");
    80003128:	00004517          	auipc	a0,0x4
    8000312c:	3a850513          	addi	a0,a0,936 # 800074d0 <etext+0x4d0>
    80003130:	e64fd0ef          	jal	80000794 <panic>

0000000080003134 <fsinit>:
fsinit(int dev) {
    80003134:	7179                	addi	sp,sp,-48
    80003136:	f406                	sd	ra,40(sp)
    80003138:	f022                	sd	s0,32(sp)
    8000313a:	ec26                	sd	s1,24(sp)
    8000313c:	e84a                	sd	s2,16(sp)
    8000313e:	e44e                	sd	s3,8(sp)
    80003140:	1800                	addi	s0,sp,48
    80003142:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003144:	4585                	li	a1,1
    80003146:	aebff0ef          	jal	80002c30 <bread>
    8000314a:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000314c:	0001e997          	auipc	s3,0x1e
    80003150:	c0c98993          	addi	s3,s3,-1012 # 80020d58 <sb>
    80003154:	02000613          	li	a2,32
    80003158:	05850593          	addi	a1,a0,88
    8000315c:	854e                	mv	a0,s3
    8000315e:	bc7fd0ef          	jal	80000d24 <memmove>
  brelse(bp);
    80003162:	8526                	mv	a0,s1
    80003164:	bd5ff0ef          	jal	80002d38 <brelse>
  if(sb.magic != FSMAGIC)
    80003168:	0009a703          	lw	a4,0(s3)
    8000316c:	102037b7          	lui	a5,0x10203
    80003170:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003174:	02f71063          	bne	a4,a5,80003194 <fsinit+0x60>
  initlog(dev, &sb);
    80003178:	0001e597          	auipc	a1,0x1e
    8000317c:	be058593          	addi	a1,a1,-1056 # 80020d58 <sb>
    80003180:	854a                	mv	a0,s2
    80003182:	1f9000ef          	jal	80003b7a <initlog>
}
    80003186:	70a2                	ld	ra,40(sp)
    80003188:	7402                	ld	s0,32(sp)
    8000318a:	64e2                	ld	s1,24(sp)
    8000318c:	6942                	ld	s2,16(sp)
    8000318e:	69a2                	ld	s3,8(sp)
    80003190:	6145                	addi	sp,sp,48
    80003192:	8082                	ret
    panic("invalid file system");
    80003194:	00004517          	auipc	a0,0x4
    80003198:	34c50513          	addi	a0,a0,844 # 800074e0 <etext+0x4e0>
    8000319c:	df8fd0ef          	jal	80000794 <panic>

00000000800031a0 <iinit>:
{
    800031a0:	7179                	addi	sp,sp,-48
    800031a2:	f406                	sd	ra,40(sp)
    800031a4:	f022                	sd	s0,32(sp)
    800031a6:	ec26                	sd	s1,24(sp)
    800031a8:	e84a                	sd	s2,16(sp)
    800031aa:	e44e                	sd	s3,8(sp)
    800031ac:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800031ae:	00004597          	auipc	a1,0x4
    800031b2:	34a58593          	addi	a1,a1,842 # 800074f8 <etext+0x4f8>
    800031b6:	0001e517          	auipc	a0,0x1e
    800031ba:	bc250513          	addi	a0,a0,-1086 # 80020d78 <itable>
    800031be:	9b7fd0ef          	jal	80000b74 <initlock>
  for(i = 0; i < NINODE; i++) {
    800031c2:	0001e497          	auipc	s1,0x1e
    800031c6:	bde48493          	addi	s1,s1,-1058 # 80020da0 <itable+0x28>
    800031ca:	0001f997          	auipc	s3,0x1f
    800031ce:	66698993          	addi	s3,s3,1638 # 80022830 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800031d2:	00004917          	auipc	s2,0x4
    800031d6:	32e90913          	addi	s2,s2,814 # 80007500 <etext+0x500>
    800031da:	85ca                	mv	a1,s2
    800031dc:	8526                	mv	a0,s1
    800031de:	475000ef          	jal	80003e52 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800031e2:	08848493          	addi	s1,s1,136
    800031e6:	ff349ae3          	bne	s1,s3,800031da <iinit+0x3a>
}
    800031ea:	70a2                	ld	ra,40(sp)
    800031ec:	7402                	ld	s0,32(sp)
    800031ee:	64e2                	ld	s1,24(sp)
    800031f0:	6942                	ld	s2,16(sp)
    800031f2:	69a2                	ld	s3,8(sp)
    800031f4:	6145                	addi	sp,sp,48
    800031f6:	8082                	ret

00000000800031f8 <ialloc>:
{
    800031f8:	7139                	addi	sp,sp,-64
    800031fa:	fc06                	sd	ra,56(sp)
    800031fc:	f822                	sd	s0,48(sp)
    800031fe:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003200:	0001e717          	auipc	a4,0x1e
    80003204:	b6472703          	lw	a4,-1180(a4) # 80020d64 <sb+0xc>
    80003208:	4785                	li	a5,1
    8000320a:	06e7f063          	bgeu	a5,a4,8000326a <ialloc+0x72>
    8000320e:	f426                	sd	s1,40(sp)
    80003210:	f04a                	sd	s2,32(sp)
    80003212:	ec4e                	sd	s3,24(sp)
    80003214:	e852                	sd	s4,16(sp)
    80003216:	e456                	sd	s5,8(sp)
    80003218:	e05a                	sd	s6,0(sp)
    8000321a:	8aaa                	mv	s5,a0
    8000321c:	8b2e                	mv	s6,a1
    8000321e:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    80003220:	0001ea17          	auipc	s4,0x1e
    80003224:	b38a0a13          	addi	s4,s4,-1224 # 80020d58 <sb>
    80003228:	00495593          	srli	a1,s2,0x4
    8000322c:	018a2783          	lw	a5,24(s4)
    80003230:	9dbd                	addw	a1,a1,a5
    80003232:	8556                	mv	a0,s5
    80003234:	9fdff0ef          	jal	80002c30 <bread>
    80003238:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000323a:	05850993          	addi	s3,a0,88
    8000323e:	00f97793          	andi	a5,s2,15
    80003242:	079a                	slli	a5,a5,0x6
    80003244:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80003246:	00099783          	lh	a5,0(s3)
    8000324a:	cb9d                	beqz	a5,80003280 <ialloc+0x88>
    brelse(bp);
    8000324c:	aedff0ef          	jal	80002d38 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80003250:	0905                	addi	s2,s2,1
    80003252:	00ca2703          	lw	a4,12(s4)
    80003256:	0009079b          	sext.w	a5,s2
    8000325a:	fce7e7e3          	bltu	a5,a4,80003228 <ialloc+0x30>
    8000325e:	74a2                	ld	s1,40(sp)
    80003260:	7902                	ld	s2,32(sp)
    80003262:	69e2                	ld	s3,24(sp)
    80003264:	6a42                	ld	s4,16(sp)
    80003266:	6aa2                	ld	s5,8(sp)
    80003268:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    8000326a:	00004517          	auipc	a0,0x4
    8000326e:	29e50513          	addi	a0,a0,670 # 80007508 <etext+0x508>
    80003272:	a50fd0ef          	jal	800004c2 <printf>
  return 0;
    80003276:	4501                	li	a0,0
}
    80003278:	70e2                	ld	ra,56(sp)
    8000327a:	7442                	ld	s0,48(sp)
    8000327c:	6121                	addi	sp,sp,64
    8000327e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003280:	04000613          	li	a2,64
    80003284:	4581                	li	a1,0
    80003286:	854e                	mv	a0,s3
    80003288:	a41fd0ef          	jal	80000cc8 <memset>
      dip->type = type;
    8000328c:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003290:	8526                	mv	a0,s1
    80003292:	2f1000ef          	jal	80003d82 <log_write>
      brelse(bp);
    80003296:	8526                	mv	a0,s1
    80003298:	aa1ff0ef          	jal	80002d38 <brelse>
      return iget(dev, inum);
    8000329c:	0009059b          	sext.w	a1,s2
    800032a0:	8556                	mv	a0,s5
    800032a2:	de7ff0ef          	jal	80003088 <iget>
    800032a6:	74a2                	ld	s1,40(sp)
    800032a8:	7902                	ld	s2,32(sp)
    800032aa:	69e2                	ld	s3,24(sp)
    800032ac:	6a42                	ld	s4,16(sp)
    800032ae:	6aa2                	ld	s5,8(sp)
    800032b0:	6b02                	ld	s6,0(sp)
    800032b2:	b7d9                	j	80003278 <ialloc+0x80>

00000000800032b4 <iupdate>:
{
    800032b4:	1101                	addi	sp,sp,-32
    800032b6:	ec06                	sd	ra,24(sp)
    800032b8:	e822                	sd	s0,16(sp)
    800032ba:	e426                	sd	s1,8(sp)
    800032bc:	e04a                	sd	s2,0(sp)
    800032be:	1000                	addi	s0,sp,32
    800032c0:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800032c2:	415c                	lw	a5,4(a0)
    800032c4:	0047d79b          	srliw	a5,a5,0x4
    800032c8:	0001e597          	auipc	a1,0x1e
    800032cc:	aa85a583          	lw	a1,-1368(a1) # 80020d70 <sb+0x18>
    800032d0:	9dbd                	addw	a1,a1,a5
    800032d2:	4108                	lw	a0,0(a0)
    800032d4:	95dff0ef          	jal	80002c30 <bread>
    800032d8:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800032da:	05850793          	addi	a5,a0,88
    800032de:	40d8                	lw	a4,4(s1)
    800032e0:	8b3d                	andi	a4,a4,15
    800032e2:	071a                	slli	a4,a4,0x6
    800032e4:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800032e6:	04449703          	lh	a4,68(s1)
    800032ea:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800032ee:	04649703          	lh	a4,70(s1)
    800032f2:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800032f6:	04849703          	lh	a4,72(s1)
    800032fa:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800032fe:	04a49703          	lh	a4,74(s1)
    80003302:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003306:	44f8                	lw	a4,76(s1)
    80003308:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000330a:	03400613          	li	a2,52
    8000330e:	05048593          	addi	a1,s1,80
    80003312:	00c78513          	addi	a0,a5,12
    80003316:	a0ffd0ef          	jal	80000d24 <memmove>
  log_write(bp);
    8000331a:	854a                	mv	a0,s2
    8000331c:	267000ef          	jal	80003d82 <log_write>
  brelse(bp);
    80003320:	854a                	mv	a0,s2
    80003322:	a17ff0ef          	jal	80002d38 <brelse>
}
    80003326:	60e2                	ld	ra,24(sp)
    80003328:	6442                	ld	s0,16(sp)
    8000332a:	64a2                	ld	s1,8(sp)
    8000332c:	6902                	ld	s2,0(sp)
    8000332e:	6105                	addi	sp,sp,32
    80003330:	8082                	ret

0000000080003332 <idup>:
{
    80003332:	1101                	addi	sp,sp,-32
    80003334:	ec06                	sd	ra,24(sp)
    80003336:	e822                	sd	s0,16(sp)
    80003338:	e426                	sd	s1,8(sp)
    8000333a:	1000                	addi	s0,sp,32
    8000333c:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000333e:	0001e517          	auipc	a0,0x1e
    80003342:	a3a50513          	addi	a0,a0,-1478 # 80020d78 <itable>
    80003346:	8affd0ef          	jal	80000bf4 <acquire>
  ip->ref++;
    8000334a:	449c                	lw	a5,8(s1)
    8000334c:	2785                	addiw	a5,a5,1
    8000334e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003350:	0001e517          	auipc	a0,0x1e
    80003354:	a2850513          	addi	a0,a0,-1496 # 80020d78 <itable>
    80003358:	935fd0ef          	jal	80000c8c <release>
}
    8000335c:	8526                	mv	a0,s1
    8000335e:	60e2                	ld	ra,24(sp)
    80003360:	6442                	ld	s0,16(sp)
    80003362:	64a2                	ld	s1,8(sp)
    80003364:	6105                	addi	sp,sp,32
    80003366:	8082                	ret

0000000080003368 <ilock>:
{
    80003368:	1101                	addi	sp,sp,-32
    8000336a:	ec06                	sd	ra,24(sp)
    8000336c:	e822                	sd	s0,16(sp)
    8000336e:	e426                	sd	s1,8(sp)
    80003370:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003372:	cd19                	beqz	a0,80003390 <ilock+0x28>
    80003374:	84aa                	mv	s1,a0
    80003376:	451c                	lw	a5,8(a0)
    80003378:	00f05c63          	blez	a5,80003390 <ilock+0x28>
  acquiresleep(&ip->lock);
    8000337c:	0541                	addi	a0,a0,16
    8000337e:	30b000ef          	jal	80003e88 <acquiresleep>
  if(ip->valid == 0){
    80003382:	40bc                	lw	a5,64(s1)
    80003384:	cf89                	beqz	a5,8000339e <ilock+0x36>
}
    80003386:	60e2                	ld	ra,24(sp)
    80003388:	6442                	ld	s0,16(sp)
    8000338a:	64a2                	ld	s1,8(sp)
    8000338c:	6105                	addi	sp,sp,32
    8000338e:	8082                	ret
    80003390:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003392:	00004517          	auipc	a0,0x4
    80003396:	18e50513          	addi	a0,a0,398 # 80007520 <etext+0x520>
    8000339a:	bfafd0ef          	jal	80000794 <panic>
    8000339e:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800033a0:	40dc                	lw	a5,4(s1)
    800033a2:	0047d79b          	srliw	a5,a5,0x4
    800033a6:	0001e597          	auipc	a1,0x1e
    800033aa:	9ca5a583          	lw	a1,-1590(a1) # 80020d70 <sb+0x18>
    800033ae:	9dbd                	addw	a1,a1,a5
    800033b0:	4088                	lw	a0,0(s1)
    800033b2:	87fff0ef          	jal	80002c30 <bread>
    800033b6:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800033b8:	05850593          	addi	a1,a0,88
    800033bc:	40dc                	lw	a5,4(s1)
    800033be:	8bbd                	andi	a5,a5,15
    800033c0:	079a                	slli	a5,a5,0x6
    800033c2:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800033c4:	00059783          	lh	a5,0(a1)
    800033c8:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800033cc:	00259783          	lh	a5,2(a1)
    800033d0:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800033d4:	00459783          	lh	a5,4(a1)
    800033d8:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800033dc:	00659783          	lh	a5,6(a1)
    800033e0:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800033e4:	459c                	lw	a5,8(a1)
    800033e6:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800033e8:	03400613          	li	a2,52
    800033ec:	05b1                	addi	a1,a1,12
    800033ee:	05048513          	addi	a0,s1,80
    800033f2:	933fd0ef          	jal	80000d24 <memmove>
    brelse(bp);
    800033f6:	854a                	mv	a0,s2
    800033f8:	941ff0ef          	jal	80002d38 <brelse>
    ip->valid = 1;
    800033fc:	4785                	li	a5,1
    800033fe:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003400:	04449783          	lh	a5,68(s1)
    80003404:	c399                	beqz	a5,8000340a <ilock+0xa2>
    80003406:	6902                	ld	s2,0(sp)
    80003408:	bfbd                	j	80003386 <ilock+0x1e>
      panic("ilock: no type");
    8000340a:	00004517          	auipc	a0,0x4
    8000340e:	11e50513          	addi	a0,a0,286 # 80007528 <etext+0x528>
    80003412:	b82fd0ef          	jal	80000794 <panic>

0000000080003416 <iunlock>:
{
    80003416:	1101                	addi	sp,sp,-32
    80003418:	ec06                	sd	ra,24(sp)
    8000341a:	e822                	sd	s0,16(sp)
    8000341c:	e426                	sd	s1,8(sp)
    8000341e:	e04a                	sd	s2,0(sp)
    80003420:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003422:	c505                	beqz	a0,8000344a <iunlock+0x34>
    80003424:	84aa                	mv	s1,a0
    80003426:	01050913          	addi	s2,a0,16
    8000342a:	854a                	mv	a0,s2
    8000342c:	2db000ef          	jal	80003f06 <holdingsleep>
    80003430:	cd09                	beqz	a0,8000344a <iunlock+0x34>
    80003432:	449c                	lw	a5,8(s1)
    80003434:	00f05b63          	blez	a5,8000344a <iunlock+0x34>
  releasesleep(&ip->lock);
    80003438:	854a                	mv	a0,s2
    8000343a:	295000ef          	jal	80003ece <releasesleep>
}
    8000343e:	60e2                	ld	ra,24(sp)
    80003440:	6442                	ld	s0,16(sp)
    80003442:	64a2                	ld	s1,8(sp)
    80003444:	6902                	ld	s2,0(sp)
    80003446:	6105                	addi	sp,sp,32
    80003448:	8082                	ret
    panic("iunlock");
    8000344a:	00004517          	auipc	a0,0x4
    8000344e:	0ee50513          	addi	a0,a0,238 # 80007538 <etext+0x538>
    80003452:	b42fd0ef          	jal	80000794 <panic>

0000000080003456 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003456:	7179                	addi	sp,sp,-48
    80003458:	f406                	sd	ra,40(sp)
    8000345a:	f022                	sd	s0,32(sp)
    8000345c:	ec26                	sd	s1,24(sp)
    8000345e:	e84a                	sd	s2,16(sp)
    80003460:	e44e                	sd	s3,8(sp)
    80003462:	1800                	addi	s0,sp,48
    80003464:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003466:	05050493          	addi	s1,a0,80
    8000346a:	08050913          	addi	s2,a0,128
    8000346e:	a021                	j	80003476 <itrunc+0x20>
    80003470:	0491                	addi	s1,s1,4
    80003472:	01248b63          	beq	s1,s2,80003488 <itrunc+0x32>
    if(ip->addrs[i]){
    80003476:	408c                	lw	a1,0(s1)
    80003478:	dde5                	beqz	a1,80003470 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000347a:	0009a503          	lw	a0,0(s3)
    8000347e:	9abff0ef          	jal	80002e28 <bfree>
      ip->addrs[i] = 0;
    80003482:	0004a023          	sw	zero,0(s1)
    80003486:	b7ed                	j	80003470 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003488:	0809a583          	lw	a1,128(s3)
    8000348c:	ed89                	bnez	a1,800034a6 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000348e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003492:	854e                	mv	a0,s3
    80003494:	e21ff0ef          	jal	800032b4 <iupdate>
}
    80003498:	70a2                	ld	ra,40(sp)
    8000349a:	7402                	ld	s0,32(sp)
    8000349c:	64e2                	ld	s1,24(sp)
    8000349e:	6942                	ld	s2,16(sp)
    800034a0:	69a2                	ld	s3,8(sp)
    800034a2:	6145                	addi	sp,sp,48
    800034a4:	8082                	ret
    800034a6:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800034a8:	0009a503          	lw	a0,0(s3)
    800034ac:	f84ff0ef          	jal	80002c30 <bread>
    800034b0:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800034b2:	05850493          	addi	s1,a0,88
    800034b6:	45850913          	addi	s2,a0,1112
    800034ba:	a021                	j	800034c2 <itrunc+0x6c>
    800034bc:	0491                	addi	s1,s1,4
    800034be:	01248963          	beq	s1,s2,800034d0 <itrunc+0x7a>
      if(a[j])
    800034c2:	408c                	lw	a1,0(s1)
    800034c4:	dde5                	beqz	a1,800034bc <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800034c6:	0009a503          	lw	a0,0(s3)
    800034ca:	95fff0ef          	jal	80002e28 <bfree>
    800034ce:	b7fd                	j	800034bc <itrunc+0x66>
    brelse(bp);
    800034d0:	8552                	mv	a0,s4
    800034d2:	867ff0ef          	jal	80002d38 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800034d6:	0809a583          	lw	a1,128(s3)
    800034da:	0009a503          	lw	a0,0(s3)
    800034de:	94bff0ef          	jal	80002e28 <bfree>
    ip->addrs[NDIRECT] = 0;
    800034e2:	0809a023          	sw	zero,128(s3)
    800034e6:	6a02                	ld	s4,0(sp)
    800034e8:	b75d                	j	8000348e <itrunc+0x38>

00000000800034ea <iput>:
{
    800034ea:	1101                	addi	sp,sp,-32
    800034ec:	ec06                	sd	ra,24(sp)
    800034ee:	e822                	sd	s0,16(sp)
    800034f0:	e426                	sd	s1,8(sp)
    800034f2:	1000                	addi	s0,sp,32
    800034f4:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800034f6:	0001e517          	auipc	a0,0x1e
    800034fa:	88250513          	addi	a0,a0,-1918 # 80020d78 <itable>
    800034fe:	ef6fd0ef          	jal	80000bf4 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003502:	4498                	lw	a4,8(s1)
    80003504:	4785                	li	a5,1
    80003506:	02f70063          	beq	a4,a5,80003526 <iput+0x3c>
  ip->ref--;
    8000350a:	449c                	lw	a5,8(s1)
    8000350c:	37fd                	addiw	a5,a5,-1
    8000350e:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003510:	0001e517          	auipc	a0,0x1e
    80003514:	86850513          	addi	a0,a0,-1944 # 80020d78 <itable>
    80003518:	f74fd0ef          	jal	80000c8c <release>
}
    8000351c:	60e2                	ld	ra,24(sp)
    8000351e:	6442                	ld	s0,16(sp)
    80003520:	64a2                	ld	s1,8(sp)
    80003522:	6105                	addi	sp,sp,32
    80003524:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003526:	40bc                	lw	a5,64(s1)
    80003528:	d3ed                	beqz	a5,8000350a <iput+0x20>
    8000352a:	04a49783          	lh	a5,74(s1)
    8000352e:	fff1                	bnez	a5,8000350a <iput+0x20>
    80003530:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003532:	01048913          	addi	s2,s1,16
    80003536:	854a                	mv	a0,s2
    80003538:	151000ef          	jal	80003e88 <acquiresleep>
    release(&itable.lock);
    8000353c:	0001e517          	auipc	a0,0x1e
    80003540:	83c50513          	addi	a0,a0,-1988 # 80020d78 <itable>
    80003544:	f48fd0ef          	jal	80000c8c <release>
    itrunc(ip);
    80003548:	8526                	mv	a0,s1
    8000354a:	f0dff0ef          	jal	80003456 <itrunc>
    ip->type = 0;
    8000354e:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003552:	8526                	mv	a0,s1
    80003554:	d61ff0ef          	jal	800032b4 <iupdate>
    ip->valid = 0;
    80003558:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000355c:	854a                	mv	a0,s2
    8000355e:	171000ef          	jal	80003ece <releasesleep>
    acquire(&itable.lock);
    80003562:	0001e517          	auipc	a0,0x1e
    80003566:	81650513          	addi	a0,a0,-2026 # 80020d78 <itable>
    8000356a:	e8afd0ef          	jal	80000bf4 <acquire>
    8000356e:	6902                	ld	s2,0(sp)
    80003570:	bf69                	j	8000350a <iput+0x20>

0000000080003572 <iunlockput>:
{
    80003572:	1101                	addi	sp,sp,-32
    80003574:	ec06                	sd	ra,24(sp)
    80003576:	e822                	sd	s0,16(sp)
    80003578:	e426                	sd	s1,8(sp)
    8000357a:	1000                	addi	s0,sp,32
    8000357c:	84aa                	mv	s1,a0
  iunlock(ip);
    8000357e:	e99ff0ef          	jal	80003416 <iunlock>
  iput(ip);
    80003582:	8526                	mv	a0,s1
    80003584:	f67ff0ef          	jal	800034ea <iput>
}
    80003588:	60e2                	ld	ra,24(sp)
    8000358a:	6442                	ld	s0,16(sp)
    8000358c:	64a2                	ld	s1,8(sp)
    8000358e:	6105                	addi	sp,sp,32
    80003590:	8082                	ret

0000000080003592 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003592:	1141                	addi	sp,sp,-16
    80003594:	e422                	sd	s0,8(sp)
    80003596:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003598:	411c                	lw	a5,0(a0)
    8000359a:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000359c:	415c                	lw	a5,4(a0)
    8000359e:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800035a0:	04451783          	lh	a5,68(a0)
    800035a4:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800035a8:	04a51783          	lh	a5,74(a0)
    800035ac:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800035b0:	04c56783          	lwu	a5,76(a0)
    800035b4:	e99c                	sd	a5,16(a1)
}
    800035b6:	6422                	ld	s0,8(sp)
    800035b8:	0141                	addi	sp,sp,16
    800035ba:	8082                	ret

00000000800035bc <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800035bc:	457c                	lw	a5,76(a0)
    800035be:	0ed7eb63          	bltu	a5,a3,800036b4 <readi+0xf8>
{
    800035c2:	7159                	addi	sp,sp,-112
    800035c4:	f486                	sd	ra,104(sp)
    800035c6:	f0a2                	sd	s0,96(sp)
    800035c8:	eca6                	sd	s1,88(sp)
    800035ca:	e0d2                	sd	s4,64(sp)
    800035cc:	fc56                	sd	s5,56(sp)
    800035ce:	f85a                	sd	s6,48(sp)
    800035d0:	f45e                	sd	s7,40(sp)
    800035d2:	1880                	addi	s0,sp,112
    800035d4:	8b2a                	mv	s6,a0
    800035d6:	8bae                	mv	s7,a1
    800035d8:	8a32                	mv	s4,a2
    800035da:	84b6                	mv	s1,a3
    800035dc:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800035de:	9f35                	addw	a4,a4,a3
    return 0;
    800035e0:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800035e2:	0cd76063          	bltu	a4,a3,800036a2 <readi+0xe6>
    800035e6:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    800035e8:	00e7f463          	bgeu	a5,a4,800035f0 <readi+0x34>
    n = ip->size - off;
    800035ec:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800035f0:	080a8f63          	beqz	s5,8000368e <readi+0xd2>
    800035f4:	e8ca                	sd	s2,80(sp)
    800035f6:	f062                	sd	s8,32(sp)
    800035f8:	ec66                	sd	s9,24(sp)
    800035fa:	e86a                	sd	s10,16(sp)
    800035fc:	e46e                	sd	s11,8(sp)
    800035fe:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003600:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003604:	5c7d                	li	s8,-1
    80003606:	a80d                	j	80003638 <readi+0x7c>
    80003608:	020d1d93          	slli	s11,s10,0x20
    8000360c:	020ddd93          	srli	s11,s11,0x20
    80003610:	05890613          	addi	a2,s2,88
    80003614:	86ee                	mv	a3,s11
    80003616:	963a                	add	a2,a2,a4
    80003618:	85d2                	mv	a1,s4
    8000361a:	855e                	mv	a0,s7
    8000361c:	ca7fe0ef          	jal	800022c2 <either_copyout>
    80003620:	05850763          	beq	a0,s8,8000366e <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003624:	854a                	mv	a0,s2
    80003626:	f12ff0ef          	jal	80002d38 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000362a:	013d09bb          	addw	s3,s10,s3
    8000362e:	009d04bb          	addw	s1,s10,s1
    80003632:	9a6e                	add	s4,s4,s11
    80003634:	0559f763          	bgeu	s3,s5,80003682 <readi+0xc6>
    uint addr = bmap(ip, off/BSIZE);
    80003638:	00a4d59b          	srliw	a1,s1,0xa
    8000363c:	855a                	mv	a0,s6
    8000363e:	977ff0ef          	jal	80002fb4 <bmap>
    80003642:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003646:	c5b1                	beqz	a1,80003692 <readi+0xd6>
    bp = bread(ip->dev, addr);
    80003648:	000b2503          	lw	a0,0(s6)
    8000364c:	de4ff0ef          	jal	80002c30 <bread>
    80003650:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003652:	3ff4f713          	andi	a4,s1,1023
    80003656:	40ec87bb          	subw	a5,s9,a4
    8000365a:	413a86bb          	subw	a3,s5,s3
    8000365e:	8d3e                	mv	s10,a5
    80003660:	2781                	sext.w	a5,a5
    80003662:	0006861b          	sext.w	a2,a3
    80003666:	faf671e3          	bgeu	a2,a5,80003608 <readi+0x4c>
    8000366a:	8d36                	mv	s10,a3
    8000366c:	bf71                	j	80003608 <readi+0x4c>
      brelse(bp);
    8000366e:	854a                	mv	a0,s2
    80003670:	ec8ff0ef          	jal	80002d38 <brelse>
      tot = -1;
    80003674:	59fd                	li	s3,-1
      break;
    80003676:	6946                	ld	s2,80(sp)
    80003678:	7c02                	ld	s8,32(sp)
    8000367a:	6ce2                	ld	s9,24(sp)
    8000367c:	6d42                	ld	s10,16(sp)
    8000367e:	6da2                	ld	s11,8(sp)
    80003680:	a831                	j	8000369c <readi+0xe0>
    80003682:	6946                	ld	s2,80(sp)
    80003684:	7c02                	ld	s8,32(sp)
    80003686:	6ce2                	ld	s9,24(sp)
    80003688:	6d42                	ld	s10,16(sp)
    8000368a:	6da2                	ld	s11,8(sp)
    8000368c:	a801                	j	8000369c <readi+0xe0>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000368e:	89d6                	mv	s3,s5
    80003690:	a031                	j	8000369c <readi+0xe0>
    80003692:	6946                	ld	s2,80(sp)
    80003694:	7c02                	ld	s8,32(sp)
    80003696:	6ce2                	ld	s9,24(sp)
    80003698:	6d42                	ld	s10,16(sp)
    8000369a:	6da2                	ld	s11,8(sp)
  }
  return tot;
    8000369c:	0009851b          	sext.w	a0,s3
    800036a0:	69a6                	ld	s3,72(sp)
}
    800036a2:	70a6                	ld	ra,104(sp)
    800036a4:	7406                	ld	s0,96(sp)
    800036a6:	64e6                	ld	s1,88(sp)
    800036a8:	6a06                	ld	s4,64(sp)
    800036aa:	7ae2                	ld	s5,56(sp)
    800036ac:	7b42                	ld	s6,48(sp)
    800036ae:	7ba2                	ld	s7,40(sp)
    800036b0:	6165                	addi	sp,sp,112
    800036b2:	8082                	ret
    return 0;
    800036b4:	4501                	li	a0,0
}
    800036b6:	8082                	ret

00000000800036b8 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800036b8:	457c                	lw	a5,76(a0)
    800036ba:	10d7e063          	bltu	a5,a3,800037ba <writei+0x102>
{
    800036be:	7159                	addi	sp,sp,-112
    800036c0:	f486                	sd	ra,104(sp)
    800036c2:	f0a2                	sd	s0,96(sp)
    800036c4:	e8ca                	sd	s2,80(sp)
    800036c6:	e0d2                	sd	s4,64(sp)
    800036c8:	fc56                	sd	s5,56(sp)
    800036ca:	f85a                	sd	s6,48(sp)
    800036cc:	f45e                	sd	s7,40(sp)
    800036ce:	1880                	addi	s0,sp,112
    800036d0:	8aaa                	mv	s5,a0
    800036d2:	8bae                	mv	s7,a1
    800036d4:	8a32                	mv	s4,a2
    800036d6:	8936                	mv	s2,a3
    800036d8:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800036da:	00e687bb          	addw	a5,a3,a4
    800036de:	0ed7e063          	bltu	a5,a3,800037be <writei+0x106>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800036e2:	00043737          	lui	a4,0x43
    800036e6:	0cf76e63          	bltu	a4,a5,800037c2 <writei+0x10a>
    800036ea:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800036ec:	0a0b0f63          	beqz	s6,800037aa <writei+0xf2>
    800036f0:	eca6                	sd	s1,88(sp)
    800036f2:	f062                	sd	s8,32(sp)
    800036f4:	ec66                	sd	s9,24(sp)
    800036f6:	e86a                	sd	s10,16(sp)
    800036f8:	e46e                	sd	s11,8(sp)
    800036fa:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800036fc:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003700:	5c7d                	li	s8,-1
    80003702:	a825                	j	8000373a <writei+0x82>
    80003704:	020d1d93          	slli	s11,s10,0x20
    80003708:	020ddd93          	srli	s11,s11,0x20
    8000370c:	05848513          	addi	a0,s1,88
    80003710:	86ee                	mv	a3,s11
    80003712:	8652                	mv	a2,s4
    80003714:	85de                	mv	a1,s7
    80003716:	953a                	add	a0,a0,a4
    80003718:	bf5fe0ef          	jal	8000230c <either_copyin>
    8000371c:	05850a63          	beq	a0,s8,80003770 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003720:	8526                	mv	a0,s1
    80003722:	660000ef          	jal	80003d82 <log_write>
    brelse(bp);
    80003726:	8526                	mv	a0,s1
    80003728:	e10ff0ef          	jal	80002d38 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    8000372c:	013d09bb          	addw	s3,s10,s3
    80003730:	012d093b          	addw	s2,s10,s2
    80003734:	9a6e                	add	s4,s4,s11
    80003736:	0569f063          	bgeu	s3,s6,80003776 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    8000373a:	00a9559b          	srliw	a1,s2,0xa
    8000373e:	8556                	mv	a0,s5
    80003740:	875ff0ef          	jal	80002fb4 <bmap>
    80003744:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003748:	c59d                	beqz	a1,80003776 <writei+0xbe>
    bp = bread(ip->dev, addr);
    8000374a:	000aa503          	lw	a0,0(s5)
    8000374e:	ce2ff0ef          	jal	80002c30 <bread>
    80003752:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003754:	3ff97713          	andi	a4,s2,1023
    80003758:	40ec87bb          	subw	a5,s9,a4
    8000375c:	413b06bb          	subw	a3,s6,s3
    80003760:	8d3e                	mv	s10,a5
    80003762:	2781                	sext.w	a5,a5
    80003764:	0006861b          	sext.w	a2,a3
    80003768:	f8f67ee3          	bgeu	a2,a5,80003704 <writei+0x4c>
    8000376c:	8d36                	mv	s10,a3
    8000376e:	bf59                	j	80003704 <writei+0x4c>
      brelse(bp);
    80003770:	8526                	mv	a0,s1
    80003772:	dc6ff0ef          	jal	80002d38 <brelse>
  }

  if(off > ip->size)
    80003776:	04caa783          	lw	a5,76(s5)
    8000377a:	0327fa63          	bgeu	a5,s2,800037ae <writei+0xf6>
    ip->size = off;
    8000377e:	052aa623          	sw	s2,76(s5)
    80003782:	64e6                	ld	s1,88(sp)
    80003784:	7c02                	ld	s8,32(sp)
    80003786:	6ce2                	ld	s9,24(sp)
    80003788:	6d42                	ld	s10,16(sp)
    8000378a:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    8000378c:	8556                	mv	a0,s5
    8000378e:	b27ff0ef          	jal	800032b4 <iupdate>

  return tot;
    80003792:	0009851b          	sext.w	a0,s3
    80003796:	69a6                	ld	s3,72(sp)
}
    80003798:	70a6                	ld	ra,104(sp)
    8000379a:	7406                	ld	s0,96(sp)
    8000379c:	6946                	ld	s2,80(sp)
    8000379e:	6a06                	ld	s4,64(sp)
    800037a0:	7ae2                	ld	s5,56(sp)
    800037a2:	7b42                	ld	s6,48(sp)
    800037a4:	7ba2                	ld	s7,40(sp)
    800037a6:	6165                	addi	sp,sp,112
    800037a8:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800037aa:	89da                	mv	s3,s6
    800037ac:	b7c5                	j	8000378c <writei+0xd4>
    800037ae:	64e6                	ld	s1,88(sp)
    800037b0:	7c02                	ld	s8,32(sp)
    800037b2:	6ce2                	ld	s9,24(sp)
    800037b4:	6d42                	ld	s10,16(sp)
    800037b6:	6da2                	ld	s11,8(sp)
    800037b8:	bfd1                	j	8000378c <writei+0xd4>
    return -1;
    800037ba:	557d                	li	a0,-1
}
    800037bc:	8082                	ret
    return -1;
    800037be:	557d                	li	a0,-1
    800037c0:	bfe1                	j	80003798 <writei+0xe0>
    return -1;
    800037c2:	557d                	li	a0,-1
    800037c4:	bfd1                	j	80003798 <writei+0xe0>

00000000800037c6 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    800037c6:	1141                	addi	sp,sp,-16
    800037c8:	e406                	sd	ra,8(sp)
    800037ca:	e022                	sd	s0,0(sp)
    800037cc:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    800037ce:	4639                	li	a2,14
    800037d0:	dc4fd0ef          	jal	80000d94 <strncmp>
}
    800037d4:	60a2                	ld	ra,8(sp)
    800037d6:	6402                	ld	s0,0(sp)
    800037d8:	0141                	addi	sp,sp,16
    800037da:	8082                	ret

00000000800037dc <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    800037dc:	7139                	addi	sp,sp,-64
    800037de:	fc06                	sd	ra,56(sp)
    800037e0:	f822                	sd	s0,48(sp)
    800037e2:	f426                	sd	s1,40(sp)
    800037e4:	f04a                	sd	s2,32(sp)
    800037e6:	ec4e                	sd	s3,24(sp)
    800037e8:	e852                	sd	s4,16(sp)
    800037ea:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    800037ec:	04451703          	lh	a4,68(a0)
    800037f0:	4785                	li	a5,1
    800037f2:	00f71a63          	bne	a4,a5,80003806 <dirlookup+0x2a>
    800037f6:	892a                	mv	s2,a0
    800037f8:	89ae                	mv	s3,a1
    800037fa:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    800037fc:	457c                	lw	a5,76(a0)
    800037fe:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003800:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003802:	e39d                	bnez	a5,80003828 <dirlookup+0x4c>
    80003804:	a095                	j	80003868 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003806:	00004517          	auipc	a0,0x4
    8000380a:	d3a50513          	addi	a0,a0,-710 # 80007540 <etext+0x540>
    8000380e:	f87fc0ef          	jal	80000794 <panic>
      panic("dirlookup read");
    80003812:	00004517          	auipc	a0,0x4
    80003816:	d4650513          	addi	a0,a0,-698 # 80007558 <etext+0x558>
    8000381a:	f7bfc0ef          	jal	80000794 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000381e:	24c1                	addiw	s1,s1,16
    80003820:	04c92783          	lw	a5,76(s2)
    80003824:	04f4f163          	bgeu	s1,a5,80003866 <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003828:	4741                	li	a4,16
    8000382a:	86a6                	mv	a3,s1
    8000382c:	fc040613          	addi	a2,s0,-64
    80003830:	4581                	li	a1,0
    80003832:	854a                	mv	a0,s2
    80003834:	d89ff0ef          	jal	800035bc <readi>
    80003838:	47c1                	li	a5,16
    8000383a:	fcf51ce3          	bne	a0,a5,80003812 <dirlookup+0x36>
    if(de.inum == 0)
    8000383e:	fc045783          	lhu	a5,-64(s0)
    80003842:	dff1                	beqz	a5,8000381e <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80003844:	fc240593          	addi	a1,s0,-62
    80003848:	854e                	mv	a0,s3
    8000384a:	f7dff0ef          	jal	800037c6 <namecmp>
    8000384e:	f961                	bnez	a0,8000381e <dirlookup+0x42>
      if(poff)
    80003850:	000a0463          	beqz	s4,80003858 <dirlookup+0x7c>
        *poff = off;
    80003854:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003858:	fc045583          	lhu	a1,-64(s0)
    8000385c:	00092503          	lw	a0,0(s2)
    80003860:	829ff0ef          	jal	80003088 <iget>
    80003864:	a011                	j	80003868 <dirlookup+0x8c>
  return 0;
    80003866:	4501                	li	a0,0
}
    80003868:	70e2                	ld	ra,56(sp)
    8000386a:	7442                	ld	s0,48(sp)
    8000386c:	74a2                	ld	s1,40(sp)
    8000386e:	7902                	ld	s2,32(sp)
    80003870:	69e2                	ld	s3,24(sp)
    80003872:	6a42                	ld	s4,16(sp)
    80003874:	6121                	addi	sp,sp,64
    80003876:	8082                	ret

0000000080003878 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003878:	711d                	addi	sp,sp,-96
    8000387a:	ec86                	sd	ra,88(sp)
    8000387c:	e8a2                	sd	s0,80(sp)
    8000387e:	e4a6                	sd	s1,72(sp)
    80003880:	e0ca                	sd	s2,64(sp)
    80003882:	fc4e                	sd	s3,56(sp)
    80003884:	f852                	sd	s4,48(sp)
    80003886:	f456                	sd	s5,40(sp)
    80003888:	f05a                	sd	s6,32(sp)
    8000388a:	ec5e                	sd	s7,24(sp)
    8000388c:	e862                	sd	s8,16(sp)
    8000388e:	e466                	sd	s9,8(sp)
    80003890:	1080                	addi	s0,sp,96
    80003892:	84aa                	mv	s1,a0
    80003894:	8b2e                	mv	s6,a1
    80003896:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003898:	00054703          	lbu	a4,0(a0)
    8000389c:	02f00793          	li	a5,47
    800038a0:	00f70e63          	beq	a4,a5,800038bc <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    800038a4:	83cfe0ef          	jal	800018e0 <myproc>
    800038a8:	15053503          	ld	a0,336(a0)
    800038ac:	a87ff0ef          	jal	80003332 <idup>
    800038b0:	8a2a                	mv	s4,a0
  while(*path == '/')
    800038b2:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    800038b6:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    800038b8:	4b85                	li	s7,1
    800038ba:	a871                	j	80003956 <namex+0xde>
    ip = iget(ROOTDEV, ROOTINO);
    800038bc:	4585                	li	a1,1
    800038be:	4505                	li	a0,1
    800038c0:	fc8ff0ef          	jal	80003088 <iget>
    800038c4:	8a2a                	mv	s4,a0
    800038c6:	b7f5                	j	800038b2 <namex+0x3a>
      iunlockput(ip);
    800038c8:	8552                	mv	a0,s4
    800038ca:	ca9ff0ef          	jal	80003572 <iunlockput>
      return 0;
    800038ce:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    800038d0:	8552                	mv	a0,s4
    800038d2:	60e6                	ld	ra,88(sp)
    800038d4:	6446                	ld	s0,80(sp)
    800038d6:	64a6                	ld	s1,72(sp)
    800038d8:	6906                	ld	s2,64(sp)
    800038da:	79e2                	ld	s3,56(sp)
    800038dc:	7a42                	ld	s4,48(sp)
    800038de:	7aa2                	ld	s5,40(sp)
    800038e0:	7b02                	ld	s6,32(sp)
    800038e2:	6be2                	ld	s7,24(sp)
    800038e4:	6c42                	ld	s8,16(sp)
    800038e6:	6ca2                	ld	s9,8(sp)
    800038e8:	6125                	addi	sp,sp,96
    800038ea:	8082                	ret
      iunlock(ip);
    800038ec:	8552                	mv	a0,s4
    800038ee:	b29ff0ef          	jal	80003416 <iunlock>
      return ip;
    800038f2:	bff9                	j	800038d0 <namex+0x58>
      iunlockput(ip);
    800038f4:	8552                	mv	a0,s4
    800038f6:	c7dff0ef          	jal	80003572 <iunlockput>
      return 0;
    800038fa:	8a4e                	mv	s4,s3
    800038fc:	bfd1                	j	800038d0 <namex+0x58>
  len = path - s;
    800038fe:	40998633          	sub	a2,s3,s1
    80003902:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003906:	099c5063          	bge	s8,s9,80003986 <namex+0x10e>
    memmove(name, s, DIRSIZ);
    8000390a:	4639                	li	a2,14
    8000390c:	85a6                	mv	a1,s1
    8000390e:	8556                	mv	a0,s5
    80003910:	c14fd0ef          	jal	80000d24 <memmove>
    80003914:	84ce                	mv	s1,s3
  while(*path == '/')
    80003916:	0004c783          	lbu	a5,0(s1)
    8000391a:	01279763          	bne	a5,s2,80003928 <namex+0xb0>
    path++;
    8000391e:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003920:	0004c783          	lbu	a5,0(s1)
    80003924:	ff278de3          	beq	a5,s2,8000391e <namex+0xa6>
    ilock(ip);
    80003928:	8552                	mv	a0,s4
    8000392a:	a3fff0ef          	jal	80003368 <ilock>
    if(ip->type != T_DIR){
    8000392e:	044a1783          	lh	a5,68(s4)
    80003932:	f9779be3          	bne	a5,s7,800038c8 <namex+0x50>
    if(nameiparent && *path == '\0'){
    80003936:	000b0563          	beqz	s6,80003940 <namex+0xc8>
    8000393a:	0004c783          	lbu	a5,0(s1)
    8000393e:	d7dd                	beqz	a5,800038ec <namex+0x74>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003940:	4601                	li	a2,0
    80003942:	85d6                	mv	a1,s5
    80003944:	8552                	mv	a0,s4
    80003946:	e97ff0ef          	jal	800037dc <dirlookup>
    8000394a:	89aa                	mv	s3,a0
    8000394c:	d545                	beqz	a0,800038f4 <namex+0x7c>
    iunlockput(ip);
    8000394e:	8552                	mv	a0,s4
    80003950:	c23ff0ef          	jal	80003572 <iunlockput>
    ip = next;
    80003954:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003956:	0004c783          	lbu	a5,0(s1)
    8000395a:	01279763          	bne	a5,s2,80003968 <namex+0xf0>
    path++;
    8000395e:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003960:	0004c783          	lbu	a5,0(s1)
    80003964:	ff278de3          	beq	a5,s2,8000395e <namex+0xe6>
  if(*path == 0)
    80003968:	cb8d                	beqz	a5,8000399a <namex+0x122>
  while(*path != '/' && *path != 0)
    8000396a:	0004c783          	lbu	a5,0(s1)
    8000396e:	89a6                	mv	s3,s1
  len = path - s;
    80003970:	4c81                	li	s9,0
    80003972:	4601                	li	a2,0
  while(*path != '/' && *path != 0)
    80003974:	01278963          	beq	a5,s2,80003986 <namex+0x10e>
    80003978:	d3d9                	beqz	a5,800038fe <namex+0x86>
    path++;
    8000397a:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    8000397c:	0009c783          	lbu	a5,0(s3)
    80003980:	ff279ce3          	bne	a5,s2,80003978 <namex+0x100>
    80003984:	bfad                	j	800038fe <namex+0x86>
    memmove(name, s, len);
    80003986:	2601                	sext.w	a2,a2
    80003988:	85a6                	mv	a1,s1
    8000398a:	8556                	mv	a0,s5
    8000398c:	b98fd0ef          	jal	80000d24 <memmove>
    name[len] = 0;
    80003990:	9cd6                	add	s9,s9,s5
    80003992:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003996:	84ce                	mv	s1,s3
    80003998:	bfbd                	j	80003916 <namex+0x9e>
  if(nameiparent){
    8000399a:	f20b0be3          	beqz	s6,800038d0 <namex+0x58>
    iput(ip);
    8000399e:	8552                	mv	a0,s4
    800039a0:	b4bff0ef          	jal	800034ea <iput>
    return 0;
    800039a4:	4a01                	li	s4,0
    800039a6:	b72d                	j	800038d0 <namex+0x58>

00000000800039a8 <dirlink>:
{
    800039a8:	7139                	addi	sp,sp,-64
    800039aa:	fc06                	sd	ra,56(sp)
    800039ac:	f822                	sd	s0,48(sp)
    800039ae:	f04a                	sd	s2,32(sp)
    800039b0:	ec4e                	sd	s3,24(sp)
    800039b2:	e852                	sd	s4,16(sp)
    800039b4:	0080                	addi	s0,sp,64
    800039b6:	892a                	mv	s2,a0
    800039b8:	8a2e                	mv	s4,a1
    800039ba:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    800039bc:	4601                	li	a2,0
    800039be:	e1fff0ef          	jal	800037dc <dirlookup>
    800039c2:	e535                	bnez	a0,80003a2e <dirlink+0x86>
    800039c4:	f426                	sd	s1,40(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    800039c6:	04c92483          	lw	s1,76(s2)
    800039ca:	c48d                	beqz	s1,800039f4 <dirlink+0x4c>
    800039cc:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800039ce:	4741                	li	a4,16
    800039d0:	86a6                	mv	a3,s1
    800039d2:	fc040613          	addi	a2,s0,-64
    800039d6:	4581                	li	a1,0
    800039d8:	854a                	mv	a0,s2
    800039da:	be3ff0ef          	jal	800035bc <readi>
    800039de:	47c1                	li	a5,16
    800039e0:	04f51b63          	bne	a0,a5,80003a36 <dirlink+0x8e>
    if(de.inum == 0)
    800039e4:	fc045783          	lhu	a5,-64(s0)
    800039e8:	c791                	beqz	a5,800039f4 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800039ea:	24c1                	addiw	s1,s1,16
    800039ec:	04c92783          	lw	a5,76(s2)
    800039f0:	fcf4efe3          	bltu	s1,a5,800039ce <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    800039f4:	4639                	li	a2,14
    800039f6:	85d2                	mv	a1,s4
    800039f8:	fc240513          	addi	a0,s0,-62
    800039fc:	bcefd0ef          	jal	80000dca <strncpy>
  de.inum = inum;
    80003a00:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a04:	4741                	li	a4,16
    80003a06:	86a6                	mv	a3,s1
    80003a08:	fc040613          	addi	a2,s0,-64
    80003a0c:	4581                	li	a1,0
    80003a0e:	854a                	mv	a0,s2
    80003a10:	ca9ff0ef          	jal	800036b8 <writei>
    80003a14:	1541                	addi	a0,a0,-16
    80003a16:	00a03533          	snez	a0,a0
    80003a1a:	40a00533          	neg	a0,a0
    80003a1e:	74a2                	ld	s1,40(sp)
}
    80003a20:	70e2                	ld	ra,56(sp)
    80003a22:	7442                	ld	s0,48(sp)
    80003a24:	7902                	ld	s2,32(sp)
    80003a26:	69e2                	ld	s3,24(sp)
    80003a28:	6a42                	ld	s4,16(sp)
    80003a2a:	6121                	addi	sp,sp,64
    80003a2c:	8082                	ret
    iput(ip);
    80003a2e:	abdff0ef          	jal	800034ea <iput>
    return -1;
    80003a32:	557d                	li	a0,-1
    80003a34:	b7f5                	j	80003a20 <dirlink+0x78>
      panic("dirlink read");
    80003a36:	00004517          	auipc	a0,0x4
    80003a3a:	b3250513          	addi	a0,a0,-1230 # 80007568 <etext+0x568>
    80003a3e:	d57fc0ef          	jal	80000794 <panic>

0000000080003a42 <namei>:

struct inode*
namei(char *path)
{
    80003a42:	1101                	addi	sp,sp,-32
    80003a44:	ec06                	sd	ra,24(sp)
    80003a46:	e822                	sd	s0,16(sp)
    80003a48:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003a4a:	fe040613          	addi	a2,s0,-32
    80003a4e:	4581                	li	a1,0
    80003a50:	e29ff0ef          	jal	80003878 <namex>
}
    80003a54:	60e2                	ld	ra,24(sp)
    80003a56:	6442                	ld	s0,16(sp)
    80003a58:	6105                	addi	sp,sp,32
    80003a5a:	8082                	ret

0000000080003a5c <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003a5c:	1141                	addi	sp,sp,-16
    80003a5e:	e406                	sd	ra,8(sp)
    80003a60:	e022                	sd	s0,0(sp)
    80003a62:	0800                	addi	s0,sp,16
    80003a64:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003a66:	4585                	li	a1,1
    80003a68:	e11ff0ef          	jal	80003878 <namex>
}
    80003a6c:	60a2                	ld	ra,8(sp)
    80003a6e:	6402                	ld	s0,0(sp)
    80003a70:	0141                	addi	sp,sp,16
    80003a72:	8082                	ret

0000000080003a74 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003a74:	1101                	addi	sp,sp,-32
    80003a76:	ec06                	sd	ra,24(sp)
    80003a78:	e822                	sd	s0,16(sp)
    80003a7a:	e426                	sd	s1,8(sp)
    80003a7c:	e04a                	sd	s2,0(sp)
    80003a7e:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003a80:	0001f917          	auipc	s2,0x1f
    80003a84:	da090913          	addi	s2,s2,-608 # 80022820 <log>
    80003a88:	01892583          	lw	a1,24(s2)
    80003a8c:	02892503          	lw	a0,40(s2)
    80003a90:	9a0ff0ef          	jal	80002c30 <bread>
    80003a94:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003a96:	02c92603          	lw	a2,44(s2)
    80003a9a:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003a9c:	00c05f63          	blez	a2,80003aba <write_head+0x46>
    80003aa0:	0001f717          	auipc	a4,0x1f
    80003aa4:	db070713          	addi	a4,a4,-592 # 80022850 <log+0x30>
    80003aa8:	87aa                	mv	a5,a0
    80003aaa:	060a                	slli	a2,a2,0x2
    80003aac:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003aae:	4314                	lw	a3,0(a4)
    80003ab0:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003ab2:	0711                	addi	a4,a4,4
    80003ab4:	0791                	addi	a5,a5,4
    80003ab6:	fec79ce3          	bne	a5,a2,80003aae <write_head+0x3a>
  }
  bwrite(buf);
    80003aba:	8526                	mv	a0,s1
    80003abc:	a4aff0ef          	jal	80002d06 <bwrite>
  brelse(buf);
    80003ac0:	8526                	mv	a0,s1
    80003ac2:	a76ff0ef          	jal	80002d38 <brelse>
}
    80003ac6:	60e2                	ld	ra,24(sp)
    80003ac8:	6442                	ld	s0,16(sp)
    80003aca:	64a2                	ld	s1,8(sp)
    80003acc:	6902                	ld	s2,0(sp)
    80003ace:	6105                	addi	sp,sp,32
    80003ad0:	8082                	ret

0000000080003ad2 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ad2:	0001f797          	auipc	a5,0x1f
    80003ad6:	d7a7a783          	lw	a5,-646(a5) # 8002284c <log+0x2c>
    80003ada:	08f05f63          	blez	a5,80003b78 <install_trans+0xa6>
{
    80003ade:	7139                	addi	sp,sp,-64
    80003ae0:	fc06                	sd	ra,56(sp)
    80003ae2:	f822                	sd	s0,48(sp)
    80003ae4:	f426                	sd	s1,40(sp)
    80003ae6:	f04a                	sd	s2,32(sp)
    80003ae8:	ec4e                	sd	s3,24(sp)
    80003aea:	e852                	sd	s4,16(sp)
    80003aec:	e456                	sd	s5,8(sp)
    80003aee:	e05a                	sd	s6,0(sp)
    80003af0:	0080                	addi	s0,sp,64
    80003af2:	8b2a                	mv	s6,a0
    80003af4:	0001fa97          	auipc	s5,0x1f
    80003af8:	d5ca8a93          	addi	s5,s5,-676 # 80022850 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003afc:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003afe:	0001f997          	auipc	s3,0x1f
    80003b02:	d2298993          	addi	s3,s3,-734 # 80022820 <log>
    80003b06:	a829                	j	80003b20 <install_trans+0x4e>
    brelse(lbuf);
    80003b08:	854a                	mv	a0,s2
    80003b0a:	a2eff0ef          	jal	80002d38 <brelse>
    brelse(dbuf);
    80003b0e:	8526                	mv	a0,s1
    80003b10:	a28ff0ef          	jal	80002d38 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b14:	2a05                	addiw	s4,s4,1
    80003b16:	0a91                	addi	s5,s5,4
    80003b18:	02c9a783          	lw	a5,44(s3)
    80003b1c:	04fa5463          	bge	s4,a5,80003b64 <install_trans+0x92>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003b20:	0189a583          	lw	a1,24(s3)
    80003b24:	014585bb          	addw	a1,a1,s4
    80003b28:	2585                	addiw	a1,a1,1
    80003b2a:	0289a503          	lw	a0,40(s3)
    80003b2e:	902ff0ef          	jal	80002c30 <bread>
    80003b32:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003b34:	000aa583          	lw	a1,0(s5)
    80003b38:	0289a503          	lw	a0,40(s3)
    80003b3c:	8f4ff0ef          	jal	80002c30 <bread>
    80003b40:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003b42:	40000613          	li	a2,1024
    80003b46:	05890593          	addi	a1,s2,88
    80003b4a:	05850513          	addi	a0,a0,88
    80003b4e:	9d6fd0ef          	jal	80000d24 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003b52:	8526                	mv	a0,s1
    80003b54:	9b2ff0ef          	jal	80002d06 <bwrite>
    if(recovering == 0)
    80003b58:	fa0b18e3          	bnez	s6,80003b08 <install_trans+0x36>
      bunpin(dbuf);
    80003b5c:	8526                	mv	a0,s1
    80003b5e:	a96ff0ef          	jal	80002df4 <bunpin>
    80003b62:	b75d                	j	80003b08 <install_trans+0x36>
}
    80003b64:	70e2                	ld	ra,56(sp)
    80003b66:	7442                	ld	s0,48(sp)
    80003b68:	74a2                	ld	s1,40(sp)
    80003b6a:	7902                	ld	s2,32(sp)
    80003b6c:	69e2                	ld	s3,24(sp)
    80003b6e:	6a42                	ld	s4,16(sp)
    80003b70:	6aa2                	ld	s5,8(sp)
    80003b72:	6b02                	ld	s6,0(sp)
    80003b74:	6121                	addi	sp,sp,64
    80003b76:	8082                	ret
    80003b78:	8082                	ret

0000000080003b7a <initlog>:
{
    80003b7a:	7179                	addi	sp,sp,-48
    80003b7c:	f406                	sd	ra,40(sp)
    80003b7e:	f022                	sd	s0,32(sp)
    80003b80:	ec26                	sd	s1,24(sp)
    80003b82:	e84a                	sd	s2,16(sp)
    80003b84:	e44e                	sd	s3,8(sp)
    80003b86:	1800                	addi	s0,sp,48
    80003b88:	892a                	mv	s2,a0
    80003b8a:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003b8c:	0001f497          	auipc	s1,0x1f
    80003b90:	c9448493          	addi	s1,s1,-876 # 80022820 <log>
    80003b94:	00004597          	auipc	a1,0x4
    80003b98:	9e458593          	addi	a1,a1,-1564 # 80007578 <etext+0x578>
    80003b9c:	8526                	mv	a0,s1
    80003b9e:	fd7fc0ef          	jal	80000b74 <initlock>
  log.start = sb->logstart;
    80003ba2:	0149a583          	lw	a1,20(s3)
    80003ba6:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80003ba8:	0109a783          	lw	a5,16(s3)
    80003bac:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003bae:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003bb2:	854a                	mv	a0,s2
    80003bb4:	87cff0ef          	jal	80002c30 <bread>
  log.lh.n = lh->n;
    80003bb8:	4d30                	lw	a2,88(a0)
    80003bba:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003bbc:	00c05f63          	blez	a2,80003bda <initlog+0x60>
    80003bc0:	87aa                	mv	a5,a0
    80003bc2:	0001f717          	auipc	a4,0x1f
    80003bc6:	c8e70713          	addi	a4,a4,-882 # 80022850 <log+0x30>
    80003bca:	060a                	slli	a2,a2,0x2
    80003bcc:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003bce:	4ff4                	lw	a3,92(a5)
    80003bd0:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003bd2:	0791                	addi	a5,a5,4
    80003bd4:	0711                	addi	a4,a4,4
    80003bd6:	fec79ce3          	bne	a5,a2,80003bce <initlog+0x54>
  brelse(buf);
    80003bda:	95eff0ef          	jal	80002d38 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003bde:	4505                	li	a0,1
    80003be0:	ef3ff0ef          	jal	80003ad2 <install_trans>
  log.lh.n = 0;
    80003be4:	0001f797          	auipc	a5,0x1f
    80003be8:	c607a423          	sw	zero,-920(a5) # 8002284c <log+0x2c>
  write_head(); // clear the log
    80003bec:	e89ff0ef          	jal	80003a74 <write_head>
}
    80003bf0:	70a2                	ld	ra,40(sp)
    80003bf2:	7402                	ld	s0,32(sp)
    80003bf4:	64e2                	ld	s1,24(sp)
    80003bf6:	6942                	ld	s2,16(sp)
    80003bf8:	69a2                	ld	s3,8(sp)
    80003bfa:	6145                	addi	sp,sp,48
    80003bfc:	8082                	ret

0000000080003bfe <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003bfe:	1101                	addi	sp,sp,-32
    80003c00:	ec06                	sd	ra,24(sp)
    80003c02:	e822                	sd	s0,16(sp)
    80003c04:	e426                	sd	s1,8(sp)
    80003c06:	e04a                	sd	s2,0(sp)
    80003c08:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003c0a:	0001f517          	auipc	a0,0x1f
    80003c0e:	c1650513          	addi	a0,a0,-1002 # 80022820 <log>
    80003c12:	fe3fc0ef          	jal	80000bf4 <acquire>
  while(1){
    if(log.committing){
    80003c16:	0001f497          	auipc	s1,0x1f
    80003c1a:	c0a48493          	addi	s1,s1,-1014 # 80022820 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003c1e:	4979                	li	s2,30
    80003c20:	a029                	j	80003c2a <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003c22:	85a6                	mv	a1,s1
    80003c24:	8526                	mv	a0,s1
    80003c26:	b40fe0ef          	jal	80001f66 <sleep>
    if(log.committing){
    80003c2a:	50dc                	lw	a5,36(s1)
    80003c2c:	fbfd                	bnez	a5,80003c22 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003c2e:	5098                	lw	a4,32(s1)
    80003c30:	2705                	addiw	a4,a4,1
    80003c32:	0027179b          	slliw	a5,a4,0x2
    80003c36:	9fb9                	addw	a5,a5,a4
    80003c38:	0017979b          	slliw	a5,a5,0x1
    80003c3c:	54d4                	lw	a3,44(s1)
    80003c3e:	9fb5                	addw	a5,a5,a3
    80003c40:	00f95763          	bge	s2,a5,80003c4e <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003c44:	85a6                	mv	a1,s1
    80003c46:	8526                	mv	a0,s1
    80003c48:	b1efe0ef          	jal	80001f66 <sleep>
    80003c4c:	bff9                	j	80003c2a <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003c4e:	0001f517          	auipc	a0,0x1f
    80003c52:	bd250513          	addi	a0,a0,-1070 # 80022820 <log>
    80003c56:	d118                	sw	a4,32(a0)
      release(&log.lock);
    80003c58:	834fd0ef          	jal	80000c8c <release>
      break;
    }
  }
}
    80003c5c:	60e2                	ld	ra,24(sp)
    80003c5e:	6442                	ld	s0,16(sp)
    80003c60:	64a2                	ld	s1,8(sp)
    80003c62:	6902                	ld	s2,0(sp)
    80003c64:	6105                	addi	sp,sp,32
    80003c66:	8082                	ret

0000000080003c68 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003c68:	7139                	addi	sp,sp,-64
    80003c6a:	fc06                	sd	ra,56(sp)
    80003c6c:	f822                	sd	s0,48(sp)
    80003c6e:	f426                	sd	s1,40(sp)
    80003c70:	f04a                	sd	s2,32(sp)
    80003c72:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003c74:	0001f497          	auipc	s1,0x1f
    80003c78:	bac48493          	addi	s1,s1,-1108 # 80022820 <log>
    80003c7c:	8526                	mv	a0,s1
    80003c7e:	f77fc0ef          	jal	80000bf4 <acquire>
  log.outstanding -= 1;
    80003c82:	509c                	lw	a5,32(s1)
    80003c84:	37fd                	addiw	a5,a5,-1
    80003c86:	0007891b          	sext.w	s2,a5
    80003c8a:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003c8c:	50dc                	lw	a5,36(s1)
    80003c8e:	ef9d                	bnez	a5,80003ccc <end_op+0x64>
    panic("log.committing");
  if(log.outstanding == 0){
    80003c90:	04091763          	bnez	s2,80003cde <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003c94:	0001f497          	auipc	s1,0x1f
    80003c98:	b8c48493          	addi	s1,s1,-1140 # 80022820 <log>
    80003c9c:	4785                	li	a5,1
    80003c9e:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003ca0:	8526                	mv	a0,s1
    80003ca2:	febfc0ef          	jal	80000c8c <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003ca6:	54dc                	lw	a5,44(s1)
    80003ca8:	04f04b63          	bgtz	a5,80003cfe <end_op+0x96>
    acquire(&log.lock);
    80003cac:	0001f497          	auipc	s1,0x1f
    80003cb0:	b7448493          	addi	s1,s1,-1164 # 80022820 <log>
    80003cb4:	8526                	mv	a0,s1
    80003cb6:	f3ffc0ef          	jal	80000bf4 <acquire>
    log.committing = 0;
    80003cba:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    80003cbe:	8526                	mv	a0,s1
    80003cc0:	af2fe0ef          	jal	80001fb2 <wakeup>
    release(&log.lock);
    80003cc4:	8526                	mv	a0,s1
    80003cc6:	fc7fc0ef          	jal	80000c8c <release>
}
    80003cca:	a025                	j	80003cf2 <end_op+0x8a>
    80003ccc:	ec4e                	sd	s3,24(sp)
    80003cce:	e852                	sd	s4,16(sp)
    80003cd0:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003cd2:	00004517          	auipc	a0,0x4
    80003cd6:	8ae50513          	addi	a0,a0,-1874 # 80007580 <etext+0x580>
    80003cda:	abbfc0ef          	jal	80000794 <panic>
    wakeup(&log);
    80003cde:	0001f497          	auipc	s1,0x1f
    80003ce2:	b4248493          	addi	s1,s1,-1214 # 80022820 <log>
    80003ce6:	8526                	mv	a0,s1
    80003ce8:	acafe0ef          	jal	80001fb2 <wakeup>
  release(&log.lock);
    80003cec:	8526                	mv	a0,s1
    80003cee:	f9ffc0ef          	jal	80000c8c <release>
}
    80003cf2:	70e2                	ld	ra,56(sp)
    80003cf4:	7442                	ld	s0,48(sp)
    80003cf6:	74a2                	ld	s1,40(sp)
    80003cf8:	7902                	ld	s2,32(sp)
    80003cfa:	6121                	addi	sp,sp,64
    80003cfc:	8082                	ret
    80003cfe:	ec4e                	sd	s3,24(sp)
    80003d00:	e852                	sd	s4,16(sp)
    80003d02:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d04:	0001fa97          	auipc	s5,0x1f
    80003d08:	b4ca8a93          	addi	s5,s5,-1204 # 80022850 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003d0c:	0001fa17          	auipc	s4,0x1f
    80003d10:	b14a0a13          	addi	s4,s4,-1260 # 80022820 <log>
    80003d14:	018a2583          	lw	a1,24(s4)
    80003d18:	012585bb          	addw	a1,a1,s2
    80003d1c:	2585                	addiw	a1,a1,1
    80003d1e:	028a2503          	lw	a0,40(s4)
    80003d22:	f0ffe0ef          	jal	80002c30 <bread>
    80003d26:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003d28:	000aa583          	lw	a1,0(s5)
    80003d2c:	028a2503          	lw	a0,40(s4)
    80003d30:	f01fe0ef          	jal	80002c30 <bread>
    80003d34:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003d36:	40000613          	li	a2,1024
    80003d3a:	05850593          	addi	a1,a0,88
    80003d3e:	05848513          	addi	a0,s1,88
    80003d42:	fe3fc0ef          	jal	80000d24 <memmove>
    bwrite(to);  // write the log
    80003d46:	8526                	mv	a0,s1
    80003d48:	fbffe0ef          	jal	80002d06 <bwrite>
    brelse(from);
    80003d4c:	854e                	mv	a0,s3
    80003d4e:	febfe0ef          	jal	80002d38 <brelse>
    brelse(to);
    80003d52:	8526                	mv	a0,s1
    80003d54:	fe5fe0ef          	jal	80002d38 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d58:	2905                	addiw	s2,s2,1
    80003d5a:	0a91                	addi	s5,s5,4
    80003d5c:	02ca2783          	lw	a5,44(s4)
    80003d60:	faf94ae3          	blt	s2,a5,80003d14 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003d64:	d11ff0ef          	jal	80003a74 <write_head>
    install_trans(0); // Now install writes to home locations
    80003d68:	4501                	li	a0,0
    80003d6a:	d69ff0ef          	jal	80003ad2 <install_trans>
    log.lh.n = 0;
    80003d6e:	0001f797          	auipc	a5,0x1f
    80003d72:	ac07af23          	sw	zero,-1314(a5) # 8002284c <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003d76:	cffff0ef          	jal	80003a74 <write_head>
    80003d7a:	69e2                	ld	s3,24(sp)
    80003d7c:	6a42                	ld	s4,16(sp)
    80003d7e:	6aa2                	ld	s5,8(sp)
    80003d80:	b735                	j	80003cac <end_op+0x44>

0000000080003d82 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003d82:	1101                	addi	sp,sp,-32
    80003d84:	ec06                	sd	ra,24(sp)
    80003d86:	e822                	sd	s0,16(sp)
    80003d88:	e426                	sd	s1,8(sp)
    80003d8a:	e04a                	sd	s2,0(sp)
    80003d8c:	1000                	addi	s0,sp,32
    80003d8e:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003d90:	0001f917          	auipc	s2,0x1f
    80003d94:	a9090913          	addi	s2,s2,-1392 # 80022820 <log>
    80003d98:	854a                	mv	a0,s2
    80003d9a:	e5bfc0ef          	jal	80000bf4 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003d9e:	02c92603          	lw	a2,44(s2)
    80003da2:	47f5                	li	a5,29
    80003da4:	06c7c363          	blt	a5,a2,80003e0a <log_write+0x88>
    80003da8:	0001f797          	auipc	a5,0x1f
    80003dac:	a947a783          	lw	a5,-1388(a5) # 8002283c <log+0x1c>
    80003db0:	37fd                	addiw	a5,a5,-1
    80003db2:	04f65c63          	bge	a2,a5,80003e0a <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003db6:	0001f797          	auipc	a5,0x1f
    80003dba:	a8a7a783          	lw	a5,-1398(a5) # 80022840 <log+0x20>
    80003dbe:	04f05c63          	blez	a5,80003e16 <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003dc2:	4781                	li	a5,0
    80003dc4:	04c05f63          	blez	a2,80003e22 <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003dc8:	44cc                	lw	a1,12(s1)
    80003dca:	0001f717          	auipc	a4,0x1f
    80003dce:	a8670713          	addi	a4,a4,-1402 # 80022850 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003dd2:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003dd4:	4314                	lw	a3,0(a4)
    80003dd6:	04b68663          	beq	a3,a1,80003e22 <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    80003dda:	2785                	addiw	a5,a5,1
    80003ddc:	0711                	addi	a4,a4,4
    80003dde:	fef61be3          	bne	a2,a5,80003dd4 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003de2:	0621                	addi	a2,a2,8
    80003de4:	060a                	slli	a2,a2,0x2
    80003de6:	0001f797          	auipc	a5,0x1f
    80003dea:	a3a78793          	addi	a5,a5,-1478 # 80022820 <log>
    80003dee:	97b2                	add	a5,a5,a2
    80003df0:	44d8                	lw	a4,12(s1)
    80003df2:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003df4:	8526                	mv	a0,s1
    80003df6:	fcbfe0ef          	jal	80002dc0 <bpin>
    log.lh.n++;
    80003dfa:	0001f717          	auipc	a4,0x1f
    80003dfe:	a2670713          	addi	a4,a4,-1498 # 80022820 <log>
    80003e02:	575c                	lw	a5,44(a4)
    80003e04:	2785                	addiw	a5,a5,1
    80003e06:	d75c                	sw	a5,44(a4)
    80003e08:	a80d                	j	80003e3a <log_write+0xb8>
    panic("too big a transaction");
    80003e0a:	00003517          	auipc	a0,0x3
    80003e0e:	78650513          	addi	a0,a0,1926 # 80007590 <etext+0x590>
    80003e12:	983fc0ef          	jal	80000794 <panic>
    panic("log_write outside of trans");
    80003e16:	00003517          	auipc	a0,0x3
    80003e1a:	79250513          	addi	a0,a0,1938 # 800075a8 <etext+0x5a8>
    80003e1e:	977fc0ef          	jal	80000794 <panic>
  log.lh.block[i] = b->blockno;
    80003e22:	00878693          	addi	a3,a5,8
    80003e26:	068a                	slli	a3,a3,0x2
    80003e28:	0001f717          	auipc	a4,0x1f
    80003e2c:	9f870713          	addi	a4,a4,-1544 # 80022820 <log>
    80003e30:	9736                	add	a4,a4,a3
    80003e32:	44d4                	lw	a3,12(s1)
    80003e34:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003e36:	faf60fe3          	beq	a2,a5,80003df4 <log_write+0x72>
  }
  release(&log.lock);
    80003e3a:	0001f517          	auipc	a0,0x1f
    80003e3e:	9e650513          	addi	a0,a0,-1562 # 80022820 <log>
    80003e42:	e4bfc0ef          	jal	80000c8c <release>
}
    80003e46:	60e2                	ld	ra,24(sp)
    80003e48:	6442                	ld	s0,16(sp)
    80003e4a:	64a2                	ld	s1,8(sp)
    80003e4c:	6902                	ld	s2,0(sp)
    80003e4e:	6105                	addi	sp,sp,32
    80003e50:	8082                	ret

0000000080003e52 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003e52:	1101                	addi	sp,sp,-32
    80003e54:	ec06                	sd	ra,24(sp)
    80003e56:	e822                	sd	s0,16(sp)
    80003e58:	e426                	sd	s1,8(sp)
    80003e5a:	e04a                	sd	s2,0(sp)
    80003e5c:	1000                	addi	s0,sp,32
    80003e5e:	84aa                	mv	s1,a0
    80003e60:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003e62:	00003597          	auipc	a1,0x3
    80003e66:	76658593          	addi	a1,a1,1894 # 800075c8 <etext+0x5c8>
    80003e6a:	0521                	addi	a0,a0,8
    80003e6c:	d09fc0ef          	jal	80000b74 <initlock>
  lk->name = name;
    80003e70:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003e74:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003e78:	0204a423          	sw	zero,40(s1)
}
    80003e7c:	60e2                	ld	ra,24(sp)
    80003e7e:	6442                	ld	s0,16(sp)
    80003e80:	64a2                	ld	s1,8(sp)
    80003e82:	6902                	ld	s2,0(sp)
    80003e84:	6105                	addi	sp,sp,32
    80003e86:	8082                	ret

0000000080003e88 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003e88:	1101                	addi	sp,sp,-32
    80003e8a:	ec06                	sd	ra,24(sp)
    80003e8c:	e822                	sd	s0,16(sp)
    80003e8e:	e426                	sd	s1,8(sp)
    80003e90:	e04a                	sd	s2,0(sp)
    80003e92:	1000                	addi	s0,sp,32
    80003e94:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003e96:	00850913          	addi	s2,a0,8
    80003e9a:	854a                	mv	a0,s2
    80003e9c:	d59fc0ef          	jal	80000bf4 <acquire>
  while (lk->locked) {
    80003ea0:	409c                	lw	a5,0(s1)
    80003ea2:	c799                	beqz	a5,80003eb0 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003ea4:	85ca                	mv	a1,s2
    80003ea6:	8526                	mv	a0,s1
    80003ea8:	8befe0ef          	jal	80001f66 <sleep>
  while (lk->locked) {
    80003eac:	409c                	lw	a5,0(s1)
    80003eae:	fbfd                	bnez	a5,80003ea4 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003eb0:	4785                	li	a5,1
    80003eb2:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003eb4:	a2dfd0ef          	jal	800018e0 <myproc>
    80003eb8:	591c                	lw	a5,48(a0)
    80003eba:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003ebc:	854a                	mv	a0,s2
    80003ebe:	dcffc0ef          	jal	80000c8c <release>
}
    80003ec2:	60e2                	ld	ra,24(sp)
    80003ec4:	6442                	ld	s0,16(sp)
    80003ec6:	64a2                	ld	s1,8(sp)
    80003ec8:	6902                	ld	s2,0(sp)
    80003eca:	6105                	addi	sp,sp,32
    80003ecc:	8082                	ret

0000000080003ece <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003ece:	1101                	addi	sp,sp,-32
    80003ed0:	ec06                	sd	ra,24(sp)
    80003ed2:	e822                	sd	s0,16(sp)
    80003ed4:	e426                	sd	s1,8(sp)
    80003ed6:	e04a                	sd	s2,0(sp)
    80003ed8:	1000                	addi	s0,sp,32
    80003eda:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003edc:	00850913          	addi	s2,a0,8
    80003ee0:	854a                	mv	a0,s2
    80003ee2:	d13fc0ef          	jal	80000bf4 <acquire>
  lk->locked = 0;
    80003ee6:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003eea:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003eee:	8526                	mv	a0,s1
    80003ef0:	8c2fe0ef          	jal	80001fb2 <wakeup>
  release(&lk->lk);
    80003ef4:	854a                	mv	a0,s2
    80003ef6:	d97fc0ef          	jal	80000c8c <release>
}
    80003efa:	60e2                	ld	ra,24(sp)
    80003efc:	6442                	ld	s0,16(sp)
    80003efe:	64a2                	ld	s1,8(sp)
    80003f00:	6902                	ld	s2,0(sp)
    80003f02:	6105                	addi	sp,sp,32
    80003f04:	8082                	ret

0000000080003f06 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003f06:	7179                	addi	sp,sp,-48
    80003f08:	f406                	sd	ra,40(sp)
    80003f0a:	f022                	sd	s0,32(sp)
    80003f0c:	ec26                	sd	s1,24(sp)
    80003f0e:	e84a                	sd	s2,16(sp)
    80003f10:	1800                	addi	s0,sp,48
    80003f12:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003f14:	00850913          	addi	s2,a0,8
    80003f18:	854a                	mv	a0,s2
    80003f1a:	cdbfc0ef          	jal	80000bf4 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003f1e:	409c                	lw	a5,0(s1)
    80003f20:	ef81                	bnez	a5,80003f38 <holdingsleep+0x32>
    80003f22:	4481                	li	s1,0
  release(&lk->lk);
    80003f24:	854a                	mv	a0,s2
    80003f26:	d67fc0ef          	jal	80000c8c <release>
  return r;
}
    80003f2a:	8526                	mv	a0,s1
    80003f2c:	70a2                	ld	ra,40(sp)
    80003f2e:	7402                	ld	s0,32(sp)
    80003f30:	64e2                	ld	s1,24(sp)
    80003f32:	6942                	ld	s2,16(sp)
    80003f34:	6145                	addi	sp,sp,48
    80003f36:	8082                	ret
    80003f38:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003f3a:	0284a983          	lw	s3,40(s1)
    80003f3e:	9a3fd0ef          	jal	800018e0 <myproc>
    80003f42:	5904                	lw	s1,48(a0)
    80003f44:	413484b3          	sub	s1,s1,s3
    80003f48:	0014b493          	seqz	s1,s1
    80003f4c:	69a2                	ld	s3,8(sp)
    80003f4e:	bfd9                	j	80003f24 <holdingsleep+0x1e>

0000000080003f50 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003f50:	1141                	addi	sp,sp,-16
    80003f52:	e406                	sd	ra,8(sp)
    80003f54:	e022                	sd	s0,0(sp)
    80003f56:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003f58:	00003597          	auipc	a1,0x3
    80003f5c:	68058593          	addi	a1,a1,1664 # 800075d8 <etext+0x5d8>
    80003f60:	0001f517          	auipc	a0,0x1f
    80003f64:	a0850513          	addi	a0,a0,-1528 # 80022968 <ftable>
    80003f68:	c0dfc0ef          	jal	80000b74 <initlock>
}
    80003f6c:	60a2                	ld	ra,8(sp)
    80003f6e:	6402                	ld	s0,0(sp)
    80003f70:	0141                	addi	sp,sp,16
    80003f72:	8082                	ret

0000000080003f74 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003f74:	1101                	addi	sp,sp,-32
    80003f76:	ec06                	sd	ra,24(sp)
    80003f78:	e822                	sd	s0,16(sp)
    80003f7a:	e426                	sd	s1,8(sp)
    80003f7c:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003f7e:	0001f517          	auipc	a0,0x1f
    80003f82:	9ea50513          	addi	a0,a0,-1558 # 80022968 <ftable>
    80003f86:	c6ffc0ef          	jal	80000bf4 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003f8a:	0001f497          	auipc	s1,0x1f
    80003f8e:	9f648493          	addi	s1,s1,-1546 # 80022980 <ftable+0x18>
    80003f92:	00020717          	auipc	a4,0x20
    80003f96:	98e70713          	addi	a4,a4,-1650 # 80023920 <disk>
    if(f->ref == 0){
    80003f9a:	40dc                	lw	a5,4(s1)
    80003f9c:	cf89                	beqz	a5,80003fb6 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003f9e:	02848493          	addi	s1,s1,40
    80003fa2:	fee49ce3          	bne	s1,a4,80003f9a <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003fa6:	0001f517          	auipc	a0,0x1f
    80003faa:	9c250513          	addi	a0,a0,-1598 # 80022968 <ftable>
    80003fae:	cdffc0ef          	jal	80000c8c <release>
  return 0;
    80003fb2:	4481                	li	s1,0
    80003fb4:	a809                	j	80003fc6 <filealloc+0x52>
      f->ref = 1;
    80003fb6:	4785                	li	a5,1
    80003fb8:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003fba:	0001f517          	auipc	a0,0x1f
    80003fbe:	9ae50513          	addi	a0,a0,-1618 # 80022968 <ftable>
    80003fc2:	ccbfc0ef          	jal	80000c8c <release>
}
    80003fc6:	8526                	mv	a0,s1
    80003fc8:	60e2                	ld	ra,24(sp)
    80003fca:	6442                	ld	s0,16(sp)
    80003fcc:	64a2                	ld	s1,8(sp)
    80003fce:	6105                	addi	sp,sp,32
    80003fd0:	8082                	ret

0000000080003fd2 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003fd2:	1101                	addi	sp,sp,-32
    80003fd4:	ec06                	sd	ra,24(sp)
    80003fd6:	e822                	sd	s0,16(sp)
    80003fd8:	e426                	sd	s1,8(sp)
    80003fda:	1000                	addi	s0,sp,32
    80003fdc:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003fde:	0001f517          	auipc	a0,0x1f
    80003fe2:	98a50513          	addi	a0,a0,-1654 # 80022968 <ftable>
    80003fe6:	c0ffc0ef          	jal	80000bf4 <acquire>
  if(f->ref < 1)
    80003fea:	40dc                	lw	a5,4(s1)
    80003fec:	02f05063          	blez	a5,8000400c <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003ff0:	2785                	addiw	a5,a5,1
    80003ff2:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003ff4:	0001f517          	auipc	a0,0x1f
    80003ff8:	97450513          	addi	a0,a0,-1676 # 80022968 <ftable>
    80003ffc:	c91fc0ef          	jal	80000c8c <release>
  return f;
}
    80004000:	8526                	mv	a0,s1
    80004002:	60e2                	ld	ra,24(sp)
    80004004:	6442                	ld	s0,16(sp)
    80004006:	64a2                	ld	s1,8(sp)
    80004008:	6105                	addi	sp,sp,32
    8000400a:	8082                	ret
    panic("filedup");
    8000400c:	00003517          	auipc	a0,0x3
    80004010:	5d450513          	addi	a0,a0,1492 # 800075e0 <etext+0x5e0>
    80004014:	f80fc0ef          	jal	80000794 <panic>

0000000080004018 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004018:	7139                	addi	sp,sp,-64
    8000401a:	fc06                	sd	ra,56(sp)
    8000401c:	f822                	sd	s0,48(sp)
    8000401e:	f426                	sd	s1,40(sp)
    80004020:	0080                	addi	s0,sp,64
    80004022:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004024:	0001f517          	auipc	a0,0x1f
    80004028:	94450513          	addi	a0,a0,-1724 # 80022968 <ftable>
    8000402c:	bc9fc0ef          	jal	80000bf4 <acquire>
  if(f->ref < 1)
    80004030:	40dc                	lw	a5,4(s1)
    80004032:	04f05a63          	blez	a5,80004086 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    80004036:	37fd                	addiw	a5,a5,-1
    80004038:	0007871b          	sext.w	a4,a5
    8000403c:	c0dc                	sw	a5,4(s1)
    8000403e:	04e04e63          	bgtz	a4,8000409a <fileclose+0x82>
    80004042:	f04a                	sd	s2,32(sp)
    80004044:	ec4e                	sd	s3,24(sp)
    80004046:	e852                	sd	s4,16(sp)
    80004048:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000404a:	0004a903          	lw	s2,0(s1)
    8000404e:	0094ca83          	lbu	s5,9(s1)
    80004052:	0104ba03          	ld	s4,16(s1)
    80004056:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000405a:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000405e:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004062:	0001f517          	auipc	a0,0x1f
    80004066:	90650513          	addi	a0,a0,-1786 # 80022968 <ftable>
    8000406a:	c23fc0ef          	jal	80000c8c <release>

  if(ff.type == FD_PIPE){
    8000406e:	4785                	li	a5,1
    80004070:	04f90063          	beq	s2,a5,800040b0 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004074:	3979                	addiw	s2,s2,-2
    80004076:	4785                	li	a5,1
    80004078:	0527f563          	bgeu	a5,s2,800040c2 <fileclose+0xaa>
    8000407c:	7902                	ld	s2,32(sp)
    8000407e:	69e2                	ld	s3,24(sp)
    80004080:	6a42                	ld	s4,16(sp)
    80004082:	6aa2                	ld	s5,8(sp)
    80004084:	a00d                	j	800040a6 <fileclose+0x8e>
    80004086:	f04a                	sd	s2,32(sp)
    80004088:	ec4e                	sd	s3,24(sp)
    8000408a:	e852                	sd	s4,16(sp)
    8000408c:	e456                	sd	s5,8(sp)
    panic("fileclose");
    8000408e:	00003517          	auipc	a0,0x3
    80004092:	55a50513          	addi	a0,a0,1370 # 800075e8 <etext+0x5e8>
    80004096:	efefc0ef          	jal	80000794 <panic>
    release(&ftable.lock);
    8000409a:	0001f517          	auipc	a0,0x1f
    8000409e:	8ce50513          	addi	a0,a0,-1842 # 80022968 <ftable>
    800040a2:	bebfc0ef          	jal	80000c8c <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800040a6:	70e2                	ld	ra,56(sp)
    800040a8:	7442                	ld	s0,48(sp)
    800040aa:	74a2                	ld	s1,40(sp)
    800040ac:	6121                	addi	sp,sp,64
    800040ae:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800040b0:	85d6                	mv	a1,s5
    800040b2:	8552                	mv	a0,s4
    800040b4:	336000ef          	jal	800043ea <pipeclose>
    800040b8:	7902                	ld	s2,32(sp)
    800040ba:	69e2                	ld	s3,24(sp)
    800040bc:	6a42                	ld	s4,16(sp)
    800040be:	6aa2                	ld	s5,8(sp)
    800040c0:	b7dd                	j	800040a6 <fileclose+0x8e>
    begin_op();
    800040c2:	b3dff0ef          	jal	80003bfe <begin_op>
    iput(ff.ip);
    800040c6:	854e                	mv	a0,s3
    800040c8:	c22ff0ef          	jal	800034ea <iput>
    end_op();
    800040cc:	b9dff0ef          	jal	80003c68 <end_op>
    800040d0:	7902                	ld	s2,32(sp)
    800040d2:	69e2                	ld	s3,24(sp)
    800040d4:	6a42                	ld	s4,16(sp)
    800040d6:	6aa2                	ld	s5,8(sp)
    800040d8:	b7f9                	j	800040a6 <fileclose+0x8e>

00000000800040da <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800040da:	715d                	addi	sp,sp,-80
    800040dc:	e486                	sd	ra,72(sp)
    800040de:	e0a2                	sd	s0,64(sp)
    800040e0:	fc26                	sd	s1,56(sp)
    800040e2:	f44e                	sd	s3,40(sp)
    800040e4:	0880                	addi	s0,sp,80
    800040e6:	84aa                	mv	s1,a0
    800040e8:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800040ea:	ff6fd0ef          	jal	800018e0 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800040ee:	409c                	lw	a5,0(s1)
    800040f0:	37f9                	addiw	a5,a5,-2
    800040f2:	4705                	li	a4,1
    800040f4:	04f76063          	bltu	a4,a5,80004134 <filestat+0x5a>
    800040f8:	f84a                	sd	s2,48(sp)
    800040fa:	892a                	mv	s2,a0
    ilock(f->ip);
    800040fc:	6c88                	ld	a0,24(s1)
    800040fe:	a6aff0ef          	jal	80003368 <ilock>
    stati(f->ip, &st);
    80004102:	fb840593          	addi	a1,s0,-72
    80004106:	6c88                	ld	a0,24(s1)
    80004108:	c8aff0ef          	jal	80003592 <stati>
    iunlock(f->ip);
    8000410c:	6c88                	ld	a0,24(s1)
    8000410e:	b08ff0ef          	jal	80003416 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80004112:	46e1                	li	a3,24
    80004114:	fb840613          	addi	a2,s0,-72
    80004118:	85ce                	mv	a1,s3
    8000411a:	05093503          	ld	a0,80(s2)
    8000411e:	c34fd0ef          	jal	80001552 <copyout>
    80004122:	41f5551b          	sraiw	a0,a0,0x1f
    80004126:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004128:	60a6                	ld	ra,72(sp)
    8000412a:	6406                	ld	s0,64(sp)
    8000412c:	74e2                	ld	s1,56(sp)
    8000412e:	79a2                	ld	s3,40(sp)
    80004130:	6161                	addi	sp,sp,80
    80004132:	8082                	ret
  return -1;
    80004134:	557d                	li	a0,-1
    80004136:	bfcd                	j	80004128 <filestat+0x4e>

0000000080004138 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004138:	7179                	addi	sp,sp,-48
    8000413a:	f406                	sd	ra,40(sp)
    8000413c:	f022                	sd	s0,32(sp)
    8000413e:	e84a                	sd	s2,16(sp)
    80004140:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004142:	00854783          	lbu	a5,8(a0)
    80004146:	cfd1                	beqz	a5,800041e2 <fileread+0xaa>
    80004148:	ec26                	sd	s1,24(sp)
    8000414a:	e44e                	sd	s3,8(sp)
    8000414c:	84aa                	mv	s1,a0
    8000414e:	89ae                	mv	s3,a1
    80004150:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80004152:	411c                	lw	a5,0(a0)
    80004154:	4705                	li	a4,1
    80004156:	04e78363          	beq	a5,a4,8000419c <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000415a:	470d                	li	a4,3
    8000415c:	04e78763          	beq	a5,a4,800041aa <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004160:	4709                	li	a4,2
    80004162:	06e79a63          	bne	a5,a4,800041d6 <fileread+0x9e>
    ilock(f->ip);
    80004166:	6d08                	ld	a0,24(a0)
    80004168:	a00ff0ef          	jal	80003368 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000416c:	874a                	mv	a4,s2
    8000416e:	5094                	lw	a3,32(s1)
    80004170:	864e                	mv	a2,s3
    80004172:	4585                	li	a1,1
    80004174:	6c88                	ld	a0,24(s1)
    80004176:	c46ff0ef          	jal	800035bc <readi>
    8000417a:	892a                	mv	s2,a0
    8000417c:	00a05563          	blez	a0,80004186 <fileread+0x4e>
      f->off += r;
    80004180:	509c                	lw	a5,32(s1)
    80004182:	9fa9                	addw	a5,a5,a0
    80004184:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004186:	6c88                	ld	a0,24(s1)
    80004188:	a8eff0ef          	jal	80003416 <iunlock>
    8000418c:	64e2                	ld	s1,24(sp)
    8000418e:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004190:	854a                	mv	a0,s2
    80004192:	70a2                	ld	ra,40(sp)
    80004194:	7402                	ld	s0,32(sp)
    80004196:	6942                	ld	s2,16(sp)
    80004198:	6145                	addi	sp,sp,48
    8000419a:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000419c:	6908                	ld	a0,16(a0)
    8000419e:	388000ef          	jal	80004526 <piperead>
    800041a2:	892a                	mv	s2,a0
    800041a4:	64e2                	ld	s1,24(sp)
    800041a6:	69a2                	ld	s3,8(sp)
    800041a8:	b7e5                	j	80004190 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800041aa:	02451783          	lh	a5,36(a0)
    800041ae:	03079693          	slli	a3,a5,0x30
    800041b2:	92c1                	srli	a3,a3,0x30
    800041b4:	4725                	li	a4,9
    800041b6:	02d76863          	bltu	a4,a3,800041e6 <fileread+0xae>
    800041ba:	0792                	slli	a5,a5,0x4
    800041bc:	0001e717          	auipc	a4,0x1e
    800041c0:	70c70713          	addi	a4,a4,1804 # 800228c8 <devsw>
    800041c4:	97ba                	add	a5,a5,a4
    800041c6:	639c                	ld	a5,0(a5)
    800041c8:	c39d                	beqz	a5,800041ee <fileread+0xb6>
    r = devsw[f->major].read(1, addr, n);
    800041ca:	4505                	li	a0,1
    800041cc:	9782                	jalr	a5
    800041ce:	892a                	mv	s2,a0
    800041d0:	64e2                	ld	s1,24(sp)
    800041d2:	69a2                	ld	s3,8(sp)
    800041d4:	bf75                	j	80004190 <fileread+0x58>
    panic("fileread");
    800041d6:	00003517          	auipc	a0,0x3
    800041da:	42250513          	addi	a0,a0,1058 # 800075f8 <etext+0x5f8>
    800041de:	db6fc0ef          	jal	80000794 <panic>
    return -1;
    800041e2:	597d                	li	s2,-1
    800041e4:	b775                	j	80004190 <fileread+0x58>
      return -1;
    800041e6:	597d                	li	s2,-1
    800041e8:	64e2                	ld	s1,24(sp)
    800041ea:	69a2                	ld	s3,8(sp)
    800041ec:	b755                	j	80004190 <fileread+0x58>
    800041ee:	597d                	li	s2,-1
    800041f0:	64e2                	ld	s1,24(sp)
    800041f2:	69a2                	ld	s3,8(sp)
    800041f4:	bf71                	j	80004190 <fileread+0x58>

00000000800041f6 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    800041f6:	00954783          	lbu	a5,9(a0)
    800041fa:	10078b63          	beqz	a5,80004310 <filewrite+0x11a>
{
    800041fe:	715d                	addi	sp,sp,-80
    80004200:	e486                	sd	ra,72(sp)
    80004202:	e0a2                	sd	s0,64(sp)
    80004204:	f84a                	sd	s2,48(sp)
    80004206:	f052                	sd	s4,32(sp)
    80004208:	e85a                	sd	s6,16(sp)
    8000420a:	0880                	addi	s0,sp,80
    8000420c:	892a                	mv	s2,a0
    8000420e:	8b2e                	mv	s6,a1
    80004210:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    80004212:	411c                	lw	a5,0(a0)
    80004214:	4705                	li	a4,1
    80004216:	02e78763          	beq	a5,a4,80004244 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000421a:	470d                	li	a4,3
    8000421c:	02e78863          	beq	a5,a4,8000424c <filewrite+0x56>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80004220:	4709                	li	a4,2
    80004222:	0ce79c63          	bne	a5,a4,800042fa <filewrite+0x104>
    80004226:	f44e                	sd	s3,40(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80004228:	0ac05863          	blez	a2,800042d8 <filewrite+0xe2>
    8000422c:	fc26                	sd	s1,56(sp)
    8000422e:	ec56                	sd	s5,24(sp)
    80004230:	e45e                	sd	s7,8(sp)
    80004232:	e062                	sd	s8,0(sp)
    int i = 0;
    80004234:	4981                	li	s3,0
      int n1 = n - i;
      if(n1 > max)
    80004236:	6b85                	lui	s7,0x1
    80004238:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    8000423c:	6c05                	lui	s8,0x1
    8000423e:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    80004242:	a8b5                	j	800042be <filewrite+0xc8>
    ret = pipewrite(f->pipe, addr, n);
    80004244:	6908                	ld	a0,16(a0)
    80004246:	1fc000ef          	jal	80004442 <pipewrite>
    8000424a:	a04d                	j	800042ec <filewrite+0xf6>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000424c:	02451783          	lh	a5,36(a0)
    80004250:	03079693          	slli	a3,a5,0x30
    80004254:	92c1                	srli	a3,a3,0x30
    80004256:	4725                	li	a4,9
    80004258:	0ad76e63          	bltu	a4,a3,80004314 <filewrite+0x11e>
    8000425c:	0792                	slli	a5,a5,0x4
    8000425e:	0001e717          	auipc	a4,0x1e
    80004262:	66a70713          	addi	a4,a4,1642 # 800228c8 <devsw>
    80004266:	97ba                	add	a5,a5,a4
    80004268:	679c                	ld	a5,8(a5)
    8000426a:	c7dd                	beqz	a5,80004318 <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    8000426c:	4505                	li	a0,1
    8000426e:	9782                	jalr	a5
    80004270:	a8b5                	j	800042ec <filewrite+0xf6>
      if(n1 > max)
    80004272:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    80004276:	989ff0ef          	jal	80003bfe <begin_op>
      ilock(f->ip);
    8000427a:	01893503          	ld	a0,24(s2)
    8000427e:	8eaff0ef          	jal	80003368 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004282:	8756                	mv	a4,s5
    80004284:	02092683          	lw	a3,32(s2)
    80004288:	01698633          	add	a2,s3,s6
    8000428c:	4585                	li	a1,1
    8000428e:	01893503          	ld	a0,24(s2)
    80004292:	c26ff0ef          	jal	800036b8 <writei>
    80004296:	84aa                	mv	s1,a0
    80004298:	00a05763          	blez	a0,800042a6 <filewrite+0xb0>
        f->off += r;
    8000429c:	02092783          	lw	a5,32(s2)
    800042a0:	9fa9                	addw	a5,a5,a0
    800042a2:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800042a6:	01893503          	ld	a0,24(s2)
    800042aa:	96cff0ef          	jal	80003416 <iunlock>
      end_op();
    800042ae:	9bbff0ef          	jal	80003c68 <end_op>

      if(r != n1){
    800042b2:	029a9563          	bne	s5,s1,800042dc <filewrite+0xe6>
        // error from writei
        break;
      }
      i += r;
    800042b6:	013489bb          	addw	s3,s1,s3
    while(i < n){
    800042ba:	0149da63          	bge	s3,s4,800042ce <filewrite+0xd8>
      int n1 = n - i;
    800042be:	413a04bb          	subw	s1,s4,s3
      if(n1 > max)
    800042c2:	0004879b          	sext.w	a5,s1
    800042c6:	fafbd6e3          	bge	s7,a5,80004272 <filewrite+0x7c>
    800042ca:	84e2                	mv	s1,s8
    800042cc:	b75d                	j	80004272 <filewrite+0x7c>
    800042ce:	74e2                	ld	s1,56(sp)
    800042d0:	6ae2                	ld	s5,24(sp)
    800042d2:	6ba2                	ld	s7,8(sp)
    800042d4:	6c02                	ld	s8,0(sp)
    800042d6:	a039                	j	800042e4 <filewrite+0xee>
    int i = 0;
    800042d8:	4981                	li	s3,0
    800042da:	a029                	j	800042e4 <filewrite+0xee>
    800042dc:	74e2                	ld	s1,56(sp)
    800042de:	6ae2                	ld	s5,24(sp)
    800042e0:	6ba2                	ld	s7,8(sp)
    800042e2:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    800042e4:	033a1c63          	bne	s4,s3,8000431c <filewrite+0x126>
    800042e8:	8552                	mv	a0,s4
    800042ea:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800042ec:	60a6                	ld	ra,72(sp)
    800042ee:	6406                	ld	s0,64(sp)
    800042f0:	7942                	ld	s2,48(sp)
    800042f2:	7a02                	ld	s4,32(sp)
    800042f4:	6b42                	ld	s6,16(sp)
    800042f6:	6161                	addi	sp,sp,80
    800042f8:	8082                	ret
    800042fa:	fc26                	sd	s1,56(sp)
    800042fc:	f44e                	sd	s3,40(sp)
    800042fe:	ec56                	sd	s5,24(sp)
    80004300:	e45e                	sd	s7,8(sp)
    80004302:	e062                	sd	s8,0(sp)
    panic("filewrite");
    80004304:	00003517          	auipc	a0,0x3
    80004308:	30450513          	addi	a0,a0,772 # 80007608 <etext+0x608>
    8000430c:	c88fc0ef          	jal	80000794 <panic>
    return -1;
    80004310:	557d                	li	a0,-1
}
    80004312:	8082                	ret
      return -1;
    80004314:	557d                	li	a0,-1
    80004316:	bfd9                	j	800042ec <filewrite+0xf6>
    80004318:	557d                	li	a0,-1
    8000431a:	bfc9                	j	800042ec <filewrite+0xf6>
    ret = (i == n ? n : -1);
    8000431c:	557d                	li	a0,-1
    8000431e:	79a2                	ld	s3,40(sp)
    80004320:	b7f1                	j	800042ec <filewrite+0xf6>

0000000080004322 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004322:	7179                	addi	sp,sp,-48
    80004324:	f406                	sd	ra,40(sp)
    80004326:	f022                	sd	s0,32(sp)
    80004328:	ec26                	sd	s1,24(sp)
    8000432a:	e052                	sd	s4,0(sp)
    8000432c:	1800                	addi	s0,sp,48
    8000432e:	84aa                	mv	s1,a0
    80004330:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004332:	0005b023          	sd	zero,0(a1)
    80004336:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    8000433a:	c3bff0ef          	jal	80003f74 <filealloc>
    8000433e:	e088                	sd	a0,0(s1)
    80004340:	c549                	beqz	a0,800043ca <pipealloc+0xa8>
    80004342:	c33ff0ef          	jal	80003f74 <filealloc>
    80004346:	00aa3023          	sd	a0,0(s4)
    8000434a:	cd25                	beqz	a0,800043c2 <pipealloc+0xa0>
    8000434c:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    8000434e:	fd6fc0ef          	jal	80000b24 <kalloc>
    80004352:	892a                	mv	s2,a0
    80004354:	c12d                	beqz	a0,800043b6 <pipealloc+0x94>
    80004356:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004358:	4985                	li	s3,1
    8000435a:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000435e:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004362:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004366:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000436a:	00003597          	auipc	a1,0x3
    8000436e:	2ae58593          	addi	a1,a1,686 # 80007618 <etext+0x618>
    80004372:	803fc0ef          	jal	80000b74 <initlock>
  (*f0)->type = FD_PIPE;
    80004376:	609c                	ld	a5,0(s1)
    80004378:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000437c:	609c                	ld	a5,0(s1)
    8000437e:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004382:	609c                	ld	a5,0(s1)
    80004384:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004388:	609c                	ld	a5,0(s1)
    8000438a:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    8000438e:	000a3783          	ld	a5,0(s4)
    80004392:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004396:	000a3783          	ld	a5,0(s4)
    8000439a:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    8000439e:	000a3783          	ld	a5,0(s4)
    800043a2:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800043a6:	000a3783          	ld	a5,0(s4)
    800043aa:	0127b823          	sd	s2,16(a5)
  return 0;
    800043ae:	4501                	li	a0,0
    800043b0:	6942                	ld	s2,16(sp)
    800043b2:	69a2                	ld	s3,8(sp)
    800043b4:	a01d                	j	800043da <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800043b6:	6088                	ld	a0,0(s1)
    800043b8:	c119                	beqz	a0,800043be <pipealloc+0x9c>
    800043ba:	6942                	ld	s2,16(sp)
    800043bc:	a029                	j	800043c6 <pipealloc+0xa4>
    800043be:	6942                	ld	s2,16(sp)
    800043c0:	a029                	j	800043ca <pipealloc+0xa8>
    800043c2:	6088                	ld	a0,0(s1)
    800043c4:	c10d                	beqz	a0,800043e6 <pipealloc+0xc4>
    fileclose(*f0);
    800043c6:	c53ff0ef          	jal	80004018 <fileclose>
  if(*f1)
    800043ca:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800043ce:	557d                	li	a0,-1
  if(*f1)
    800043d0:	c789                	beqz	a5,800043da <pipealloc+0xb8>
    fileclose(*f1);
    800043d2:	853e                	mv	a0,a5
    800043d4:	c45ff0ef          	jal	80004018 <fileclose>
  return -1;
    800043d8:	557d                	li	a0,-1
}
    800043da:	70a2                	ld	ra,40(sp)
    800043dc:	7402                	ld	s0,32(sp)
    800043de:	64e2                	ld	s1,24(sp)
    800043e0:	6a02                	ld	s4,0(sp)
    800043e2:	6145                	addi	sp,sp,48
    800043e4:	8082                	ret
  return -1;
    800043e6:	557d                	li	a0,-1
    800043e8:	bfcd                	j	800043da <pipealloc+0xb8>

00000000800043ea <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800043ea:	1101                	addi	sp,sp,-32
    800043ec:	ec06                	sd	ra,24(sp)
    800043ee:	e822                	sd	s0,16(sp)
    800043f0:	e426                	sd	s1,8(sp)
    800043f2:	e04a                	sd	s2,0(sp)
    800043f4:	1000                	addi	s0,sp,32
    800043f6:	84aa                	mv	s1,a0
    800043f8:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800043fa:	ffafc0ef          	jal	80000bf4 <acquire>
  if(writable){
    800043fe:	02090763          	beqz	s2,8000442c <pipeclose+0x42>
    pi->writeopen = 0;
    80004402:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004406:	21848513          	addi	a0,s1,536
    8000440a:	ba9fd0ef          	jal	80001fb2 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    8000440e:	2204b783          	ld	a5,544(s1)
    80004412:	e785                	bnez	a5,8000443a <pipeclose+0x50>
    release(&pi->lock);
    80004414:	8526                	mv	a0,s1
    80004416:	877fc0ef          	jal	80000c8c <release>
    kfree((char*)pi);
    8000441a:	8526                	mv	a0,s1
    8000441c:	e26fc0ef          	jal	80000a42 <kfree>
  } else
    release(&pi->lock);
}
    80004420:	60e2                	ld	ra,24(sp)
    80004422:	6442                	ld	s0,16(sp)
    80004424:	64a2                	ld	s1,8(sp)
    80004426:	6902                	ld	s2,0(sp)
    80004428:	6105                	addi	sp,sp,32
    8000442a:	8082                	ret
    pi->readopen = 0;
    8000442c:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004430:	21c48513          	addi	a0,s1,540
    80004434:	b7ffd0ef          	jal	80001fb2 <wakeup>
    80004438:	bfd9                	j	8000440e <pipeclose+0x24>
    release(&pi->lock);
    8000443a:	8526                	mv	a0,s1
    8000443c:	851fc0ef          	jal	80000c8c <release>
}
    80004440:	b7c5                	j	80004420 <pipeclose+0x36>

0000000080004442 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004442:	711d                	addi	sp,sp,-96
    80004444:	ec86                	sd	ra,88(sp)
    80004446:	e8a2                	sd	s0,80(sp)
    80004448:	e4a6                	sd	s1,72(sp)
    8000444a:	e0ca                	sd	s2,64(sp)
    8000444c:	fc4e                	sd	s3,56(sp)
    8000444e:	f852                	sd	s4,48(sp)
    80004450:	f456                	sd	s5,40(sp)
    80004452:	1080                	addi	s0,sp,96
    80004454:	84aa                	mv	s1,a0
    80004456:	8aae                	mv	s5,a1
    80004458:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000445a:	c86fd0ef          	jal	800018e0 <myproc>
    8000445e:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004460:	8526                	mv	a0,s1
    80004462:	f92fc0ef          	jal	80000bf4 <acquire>
  while(i < n){
    80004466:	0b405a63          	blez	s4,8000451a <pipewrite+0xd8>
    8000446a:	f05a                	sd	s6,32(sp)
    8000446c:	ec5e                	sd	s7,24(sp)
    8000446e:	e862                	sd	s8,16(sp)
  int i = 0;
    80004470:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004472:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004474:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004478:	21c48b93          	addi	s7,s1,540
    8000447c:	a81d                	j	800044b2 <pipewrite+0x70>
      release(&pi->lock);
    8000447e:	8526                	mv	a0,s1
    80004480:	80dfc0ef          	jal	80000c8c <release>
      return -1;
    80004484:	597d                	li	s2,-1
    80004486:	7b02                	ld	s6,32(sp)
    80004488:	6be2                	ld	s7,24(sp)
    8000448a:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000448c:	854a                	mv	a0,s2
    8000448e:	60e6                	ld	ra,88(sp)
    80004490:	6446                	ld	s0,80(sp)
    80004492:	64a6                	ld	s1,72(sp)
    80004494:	6906                	ld	s2,64(sp)
    80004496:	79e2                	ld	s3,56(sp)
    80004498:	7a42                	ld	s4,48(sp)
    8000449a:	7aa2                	ld	s5,40(sp)
    8000449c:	6125                	addi	sp,sp,96
    8000449e:	8082                	ret
      wakeup(&pi->nread);
    800044a0:	8562                	mv	a0,s8
    800044a2:	b11fd0ef          	jal	80001fb2 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    800044a6:	85a6                	mv	a1,s1
    800044a8:	855e                	mv	a0,s7
    800044aa:	abdfd0ef          	jal	80001f66 <sleep>
  while(i < n){
    800044ae:	05495b63          	bge	s2,s4,80004504 <pipewrite+0xc2>
    if(pi->readopen == 0 || killed(pr)){
    800044b2:	2204a783          	lw	a5,544(s1)
    800044b6:	d7e1                	beqz	a5,8000447e <pipewrite+0x3c>
    800044b8:	854e                	mv	a0,s3
    800044ba:	ce5fd0ef          	jal	8000219e <killed>
    800044be:	f161                	bnez	a0,8000447e <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800044c0:	2184a783          	lw	a5,536(s1)
    800044c4:	21c4a703          	lw	a4,540(s1)
    800044c8:	2007879b          	addiw	a5,a5,512
    800044cc:	fcf70ae3          	beq	a4,a5,800044a0 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800044d0:	4685                	li	a3,1
    800044d2:	01590633          	add	a2,s2,s5
    800044d6:	faf40593          	addi	a1,s0,-81
    800044da:	0509b503          	ld	a0,80(s3)
    800044de:	94afd0ef          	jal	80001628 <copyin>
    800044e2:	03650e63          	beq	a0,s6,8000451e <pipewrite+0xdc>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800044e6:	21c4a783          	lw	a5,540(s1)
    800044ea:	0017871b          	addiw	a4,a5,1
    800044ee:	20e4ae23          	sw	a4,540(s1)
    800044f2:	1ff7f793          	andi	a5,a5,511
    800044f6:	97a6                	add	a5,a5,s1
    800044f8:	faf44703          	lbu	a4,-81(s0)
    800044fc:	00e78c23          	sb	a4,24(a5)
      i++;
    80004500:	2905                	addiw	s2,s2,1
    80004502:	b775                	j	800044ae <pipewrite+0x6c>
    80004504:	7b02                	ld	s6,32(sp)
    80004506:	6be2                	ld	s7,24(sp)
    80004508:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    8000450a:	21848513          	addi	a0,s1,536
    8000450e:	aa5fd0ef          	jal	80001fb2 <wakeup>
  release(&pi->lock);
    80004512:	8526                	mv	a0,s1
    80004514:	f78fc0ef          	jal	80000c8c <release>
  return i;
    80004518:	bf95                	j	8000448c <pipewrite+0x4a>
  int i = 0;
    8000451a:	4901                	li	s2,0
    8000451c:	b7fd                	j	8000450a <pipewrite+0xc8>
    8000451e:	7b02                	ld	s6,32(sp)
    80004520:	6be2                	ld	s7,24(sp)
    80004522:	6c42                	ld	s8,16(sp)
    80004524:	b7dd                	j	8000450a <pipewrite+0xc8>

0000000080004526 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004526:	715d                	addi	sp,sp,-80
    80004528:	e486                	sd	ra,72(sp)
    8000452a:	e0a2                	sd	s0,64(sp)
    8000452c:	fc26                	sd	s1,56(sp)
    8000452e:	f84a                	sd	s2,48(sp)
    80004530:	f44e                	sd	s3,40(sp)
    80004532:	f052                	sd	s4,32(sp)
    80004534:	ec56                	sd	s5,24(sp)
    80004536:	0880                	addi	s0,sp,80
    80004538:	84aa                	mv	s1,a0
    8000453a:	892e                	mv	s2,a1
    8000453c:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000453e:	ba2fd0ef          	jal	800018e0 <myproc>
    80004542:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004544:	8526                	mv	a0,s1
    80004546:	eaefc0ef          	jal	80000bf4 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000454a:	2184a703          	lw	a4,536(s1)
    8000454e:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004552:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004556:	02f71563          	bne	a4,a5,80004580 <piperead+0x5a>
    8000455a:	2244a783          	lw	a5,548(s1)
    8000455e:	cb85                	beqz	a5,8000458e <piperead+0x68>
    if(killed(pr)){
    80004560:	8552                	mv	a0,s4
    80004562:	c3dfd0ef          	jal	8000219e <killed>
    80004566:	ed19                	bnez	a0,80004584 <piperead+0x5e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004568:	85a6                	mv	a1,s1
    8000456a:	854e                	mv	a0,s3
    8000456c:	9fbfd0ef          	jal	80001f66 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004570:	2184a703          	lw	a4,536(s1)
    80004574:	21c4a783          	lw	a5,540(s1)
    80004578:	fef701e3          	beq	a4,a5,8000455a <piperead+0x34>
    8000457c:	e85a                	sd	s6,16(sp)
    8000457e:	a809                	j	80004590 <piperead+0x6a>
    80004580:	e85a                	sd	s6,16(sp)
    80004582:	a039                	j	80004590 <piperead+0x6a>
      release(&pi->lock);
    80004584:	8526                	mv	a0,s1
    80004586:	f06fc0ef          	jal	80000c8c <release>
      return -1;
    8000458a:	59fd                	li	s3,-1
    8000458c:	a8b1                	j	800045e8 <piperead+0xc2>
    8000458e:	e85a                	sd	s6,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004590:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004592:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004594:	05505263          	blez	s5,800045d8 <piperead+0xb2>
    if(pi->nread == pi->nwrite)
    80004598:	2184a783          	lw	a5,536(s1)
    8000459c:	21c4a703          	lw	a4,540(s1)
    800045a0:	02f70c63          	beq	a4,a5,800045d8 <piperead+0xb2>
    ch = pi->data[pi->nread++ % PIPESIZE];
    800045a4:	0017871b          	addiw	a4,a5,1
    800045a8:	20e4ac23          	sw	a4,536(s1)
    800045ac:	1ff7f793          	andi	a5,a5,511
    800045b0:	97a6                	add	a5,a5,s1
    800045b2:	0187c783          	lbu	a5,24(a5)
    800045b6:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800045ba:	4685                	li	a3,1
    800045bc:	fbf40613          	addi	a2,s0,-65
    800045c0:	85ca                	mv	a1,s2
    800045c2:	050a3503          	ld	a0,80(s4)
    800045c6:	f8dfc0ef          	jal	80001552 <copyout>
    800045ca:	01650763          	beq	a0,s6,800045d8 <piperead+0xb2>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800045ce:	2985                	addiw	s3,s3,1
    800045d0:	0905                	addi	s2,s2,1
    800045d2:	fd3a93e3          	bne	s5,s3,80004598 <piperead+0x72>
    800045d6:	89d6                	mv	s3,s5
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    800045d8:	21c48513          	addi	a0,s1,540
    800045dc:	9d7fd0ef          	jal	80001fb2 <wakeup>
  release(&pi->lock);
    800045e0:	8526                	mv	a0,s1
    800045e2:	eaafc0ef          	jal	80000c8c <release>
    800045e6:	6b42                	ld	s6,16(sp)
  return i;
}
    800045e8:	854e                	mv	a0,s3
    800045ea:	60a6                	ld	ra,72(sp)
    800045ec:	6406                	ld	s0,64(sp)
    800045ee:	74e2                	ld	s1,56(sp)
    800045f0:	7942                	ld	s2,48(sp)
    800045f2:	79a2                	ld	s3,40(sp)
    800045f4:	7a02                	ld	s4,32(sp)
    800045f6:	6ae2                	ld	s5,24(sp)
    800045f8:	6161                	addi	sp,sp,80
    800045fa:	8082                	ret

00000000800045fc <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    800045fc:	1141                	addi	sp,sp,-16
    800045fe:	e422                	sd	s0,8(sp)
    80004600:	0800                	addi	s0,sp,16
    80004602:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004604:	8905                	andi	a0,a0,1
    80004606:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    80004608:	8b89                	andi	a5,a5,2
    8000460a:	c399                	beqz	a5,80004610 <flags2perm+0x14>
      perm |= PTE_W;
    8000460c:	00456513          	ori	a0,a0,4
    return perm;
}
    80004610:	6422                	ld	s0,8(sp)
    80004612:	0141                	addi	sp,sp,16
    80004614:	8082                	ret

0000000080004616 <exec>:

int
exec(char *path, char **argv)
{
    80004616:	df010113          	addi	sp,sp,-528
    8000461a:	20113423          	sd	ra,520(sp)
    8000461e:	20813023          	sd	s0,512(sp)
    80004622:	ffa6                	sd	s1,504(sp)
    80004624:	fbca                	sd	s2,496(sp)
    80004626:	0c00                	addi	s0,sp,528
    80004628:	892a                	mv	s2,a0
    8000462a:	dea43c23          	sd	a0,-520(s0)
    8000462e:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004632:	aaefd0ef          	jal	800018e0 <myproc>
    80004636:	84aa                	mv	s1,a0

  begin_op();
    80004638:	dc6ff0ef          	jal	80003bfe <begin_op>

  if((ip = namei(path)) == 0){
    8000463c:	854a                	mv	a0,s2
    8000463e:	c04ff0ef          	jal	80003a42 <namei>
    80004642:	c931                	beqz	a0,80004696 <exec+0x80>
    80004644:	f3d2                	sd	s4,480(sp)
    80004646:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004648:	d21fe0ef          	jal	80003368 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    8000464c:	04000713          	li	a4,64
    80004650:	4681                	li	a3,0
    80004652:	e5040613          	addi	a2,s0,-432
    80004656:	4581                	li	a1,0
    80004658:	8552                	mv	a0,s4
    8000465a:	f63fe0ef          	jal	800035bc <readi>
    8000465e:	04000793          	li	a5,64
    80004662:	00f51a63          	bne	a0,a5,80004676 <exec+0x60>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004666:	e5042703          	lw	a4,-432(s0)
    8000466a:	464c47b7          	lui	a5,0x464c4
    8000466e:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004672:	02f70663          	beq	a4,a5,8000469e <exec+0x88>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004676:	8552                	mv	a0,s4
    80004678:	efbfe0ef          	jal	80003572 <iunlockput>
    end_op();
    8000467c:	decff0ef          	jal	80003c68 <end_op>
  }
  return -1;
    80004680:	557d                	li	a0,-1
    80004682:	7a1e                	ld	s4,480(sp)
}
    80004684:	20813083          	ld	ra,520(sp)
    80004688:	20013403          	ld	s0,512(sp)
    8000468c:	74fe                	ld	s1,504(sp)
    8000468e:	795e                	ld	s2,496(sp)
    80004690:	21010113          	addi	sp,sp,528
    80004694:	8082                	ret
    end_op();
    80004696:	dd2ff0ef          	jal	80003c68 <end_op>
    return -1;
    8000469a:	557d                	li	a0,-1
    8000469c:	b7e5                	j	80004684 <exec+0x6e>
    8000469e:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    800046a0:	8526                	mv	a0,s1
    800046a2:	ae6fd0ef          	jal	80001988 <proc_pagetable>
    800046a6:	8b2a                	mv	s6,a0
    800046a8:	2c050b63          	beqz	a0,8000497e <exec+0x368>
    800046ac:	f7ce                	sd	s3,488(sp)
    800046ae:	efd6                	sd	s5,472(sp)
    800046b0:	e7de                	sd	s7,456(sp)
    800046b2:	e3e2                	sd	s8,448(sp)
    800046b4:	ff66                	sd	s9,440(sp)
    800046b6:	fb6a                	sd	s10,432(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800046b8:	e7042d03          	lw	s10,-400(s0)
    800046bc:	e8845783          	lhu	a5,-376(s0)
    800046c0:	12078963          	beqz	a5,800047f2 <exec+0x1dc>
    800046c4:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800046c6:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800046c8:	4d81                	li	s11,0
    if(ph.vaddr % PGSIZE != 0)
    800046ca:	6c85                	lui	s9,0x1
    800046cc:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800046d0:	def43823          	sd	a5,-528(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800046d4:	6a85                	lui	s5,0x1
    800046d6:	a085                	j	80004736 <exec+0x120>
      panic("loadseg: address should exist");
    800046d8:	00003517          	auipc	a0,0x3
    800046dc:	f4850513          	addi	a0,a0,-184 # 80007620 <etext+0x620>
    800046e0:	8b4fc0ef          	jal	80000794 <panic>
    if(sz - i < PGSIZE)
    800046e4:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800046e6:	8726                	mv	a4,s1
    800046e8:	012c06bb          	addw	a3,s8,s2
    800046ec:	4581                	li	a1,0
    800046ee:	8552                	mv	a0,s4
    800046f0:	ecdfe0ef          	jal	800035bc <readi>
    800046f4:	2501                	sext.w	a0,a0
    800046f6:	24a49a63          	bne	s1,a0,8000494a <exec+0x334>
  for(i = 0; i < sz; i += PGSIZE){
    800046fa:	012a893b          	addw	s2,s5,s2
    800046fe:	03397363          	bgeu	s2,s3,80004724 <exec+0x10e>
    pa = walkaddr(pagetable, va + i);
    80004702:	02091593          	slli	a1,s2,0x20
    80004706:	9181                	srli	a1,a1,0x20
    80004708:	95de                	add	a1,a1,s7
    8000470a:	855a                	mv	a0,s6
    8000470c:	8cbfc0ef          	jal	80000fd6 <walkaddr>
    80004710:	862a                	mv	a2,a0
    if(pa == 0)
    80004712:	d179                	beqz	a0,800046d8 <exec+0xc2>
    if(sz - i < PGSIZE)
    80004714:	412984bb          	subw	s1,s3,s2
    80004718:	0004879b          	sext.w	a5,s1
    8000471c:	fcfcf4e3          	bgeu	s9,a5,800046e4 <exec+0xce>
    80004720:	84d6                	mv	s1,s5
    80004722:	b7c9                	j	800046e4 <exec+0xce>
    sz = sz1;
    80004724:	e0843903          	ld	s2,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004728:	2d85                	addiw	s11,s11,1
    8000472a:	038d0d1b          	addiw	s10,s10,56 # 1038 <_entry-0x7fffefc8>
    8000472e:	e8845783          	lhu	a5,-376(s0)
    80004732:	08fdd063          	bge	s11,a5,800047b2 <exec+0x19c>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004736:	2d01                	sext.w	s10,s10
    80004738:	03800713          	li	a4,56
    8000473c:	86ea                	mv	a3,s10
    8000473e:	e1840613          	addi	a2,s0,-488
    80004742:	4581                	li	a1,0
    80004744:	8552                	mv	a0,s4
    80004746:	e77fe0ef          	jal	800035bc <readi>
    8000474a:	03800793          	li	a5,56
    8000474e:	1cf51663          	bne	a0,a5,8000491a <exec+0x304>
    if(ph.type != ELF_PROG_LOAD)
    80004752:	e1842783          	lw	a5,-488(s0)
    80004756:	4705                	li	a4,1
    80004758:	fce798e3          	bne	a5,a4,80004728 <exec+0x112>
    if(ph.memsz < ph.filesz)
    8000475c:	e4043483          	ld	s1,-448(s0)
    80004760:	e3843783          	ld	a5,-456(s0)
    80004764:	1af4ef63          	bltu	s1,a5,80004922 <exec+0x30c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004768:	e2843783          	ld	a5,-472(s0)
    8000476c:	94be                	add	s1,s1,a5
    8000476e:	1af4ee63          	bltu	s1,a5,8000492a <exec+0x314>
    if(ph.vaddr % PGSIZE != 0)
    80004772:	df043703          	ld	a4,-528(s0)
    80004776:	8ff9                	and	a5,a5,a4
    80004778:	1a079d63          	bnez	a5,80004932 <exec+0x31c>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    8000477c:	e1c42503          	lw	a0,-484(s0)
    80004780:	e7dff0ef          	jal	800045fc <flags2perm>
    80004784:	86aa                	mv	a3,a0
    80004786:	8626                	mv	a2,s1
    80004788:	85ca                	mv	a1,s2
    8000478a:	855a                	mv	a0,s6
    8000478c:	bb3fc0ef          	jal	8000133e <uvmalloc>
    80004790:	e0a43423          	sd	a0,-504(s0)
    80004794:	1a050363          	beqz	a0,8000493a <exec+0x324>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004798:	e2843b83          	ld	s7,-472(s0)
    8000479c:	e2042c03          	lw	s8,-480(s0)
    800047a0:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    800047a4:	00098463          	beqz	s3,800047ac <exec+0x196>
    800047a8:	4901                	li	s2,0
    800047aa:	bfa1                	j	80004702 <exec+0xec>
    sz = sz1;
    800047ac:	e0843903          	ld	s2,-504(s0)
    800047b0:	bfa5                	j	80004728 <exec+0x112>
    800047b2:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    800047b4:	8552                	mv	a0,s4
    800047b6:	dbdfe0ef          	jal	80003572 <iunlockput>
  end_op();
    800047ba:	caeff0ef          	jal	80003c68 <end_op>
  p = myproc();
    800047be:	922fd0ef          	jal	800018e0 <myproc>
    800047c2:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    800047c4:	04853c83          	ld	s9,72(a0)
  sz = PGROUNDUP(sz);
    800047c8:	6985                	lui	s3,0x1
    800047ca:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    800047cc:	99ca                	add	s3,s3,s2
    800047ce:	77fd                	lui	a5,0xfffff
    800047d0:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800047d4:	4691                	li	a3,4
    800047d6:	6609                	lui	a2,0x2
    800047d8:	964e                	add	a2,a2,s3
    800047da:	85ce                	mv	a1,s3
    800047dc:	855a                	mv	a0,s6
    800047de:	b61fc0ef          	jal	8000133e <uvmalloc>
    800047e2:	892a                	mv	s2,a0
    800047e4:	e0a43423          	sd	a0,-504(s0)
    800047e8:	e519                	bnez	a0,800047f6 <exec+0x1e0>
  if(pagetable)
    800047ea:	e1343423          	sd	s3,-504(s0)
    800047ee:	4a01                	li	s4,0
    800047f0:	aab1                	j	8000494c <exec+0x336>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800047f2:	4901                	li	s2,0
    800047f4:	b7c1                	j	800047b4 <exec+0x19e>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800047f6:	75f9                	lui	a1,0xffffe
    800047f8:	95aa                	add	a1,a1,a0
    800047fa:	855a                	mv	a0,s6
    800047fc:	d2dfc0ef          	jal	80001528 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004800:	7bfd                	lui	s7,0xfffff
    80004802:	9bca                	add	s7,s7,s2
  for(argc = 0; argv[argc]; argc++) {
    80004804:	e0043783          	ld	a5,-512(s0)
    80004808:	6388                	ld	a0,0(a5)
    8000480a:	cd39                	beqz	a0,80004868 <exec+0x252>
    8000480c:	e9040993          	addi	s3,s0,-368
    80004810:	f9040c13          	addi	s8,s0,-112
    80004814:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004816:	e22fc0ef          	jal	80000e38 <strlen>
    8000481a:	0015079b          	addiw	a5,a0,1
    8000481e:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004822:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004826:	11796e63          	bltu	s2,s7,80004942 <exec+0x32c>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    8000482a:	e0043d03          	ld	s10,-512(s0)
    8000482e:	000d3a03          	ld	s4,0(s10)
    80004832:	8552                	mv	a0,s4
    80004834:	e04fc0ef          	jal	80000e38 <strlen>
    80004838:	0015069b          	addiw	a3,a0,1
    8000483c:	8652                	mv	a2,s4
    8000483e:	85ca                	mv	a1,s2
    80004840:	855a                	mv	a0,s6
    80004842:	d11fc0ef          	jal	80001552 <copyout>
    80004846:	10054063          	bltz	a0,80004946 <exec+0x330>
    ustack[argc] = sp;
    8000484a:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    8000484e:	0485                	addi	s1,s1,1
    80004850:	008d0793          	addi	a5,s10,8
    80004854:	e0f43023          	sd	a5,-512(s0)
    80004858:	008d3503          	ld	a0,8(s10)
    8000485c:	c909                	beqz	a0,8000486e <exec+0x258>
    if(argc >= MAXARG)
    8000485e:	09a1                	addi	s3,s3,8
    80004860:	fb899be3          	bne	s3,s8,80004816 <exec+0x200>
  ip = 0;
    80004864:	4a01                	li	s4,0
    80004866:	a0dd                	j	8000494c <exec+0x336>
  sp = sz;
    80004868:	e0843903          	ld	s2,-504(s0)
  for(argc = 0; argv[argc]; argc++) {
    8000486c:	4481                	li	s1,0
  ustack[argc] = 0;
    8000486e:	00349793          	slli	a5,s1,0x3
    80004872:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffdb530>
    80004876:	97a2                	add	a5,a5,s0
    80004878:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    8000487c:	00148693          	addi	a3,s1,1
    80004880:	068e                	slli	a3,a3,0x3
    80004882:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004886:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    8000488a:	e0843983          	ld	s3,-504(s0)
  if(sp < stackbase)
    8000488e:	f5796ee3          	bltu	s2,s7,800047ea <exec+0x1d4>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004892:	e9040613          	addi	a2,s0,-368
    80004896:	85ca                	mv	a1,s2
    80004898:	855a                	mv	a0,s6
    8000489a:	cb9fc0ef          	jal	80001552 <copyout>
    8000489e:	0e054263          	bltz	a0,80004982 <exec+0x36c>
  p->trapframe->a1 = sp;
    800048a2:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    800048a6:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    800048aa:	df843783          	ld	a5,-520(s0)
    800048ae:	0007c703          	lbu	a4,0(a5)
    800048b2:	cf11                	beqz	a4,800048ce <exec+0x2b8>
    800048b4:	0785                	addi	a5,a5,1
    if(*s == '/')
    800048b6:	02f00693          	li	a3,47
    800048ba:	a039                	j	800048c8 <exec+0x2b2>
      last = s+1;
    800048bc:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    800048c0:	0785                	addi	a5,a5,1
    800048c2:	fff7c703          	lbu	a4,-1(a5)
    800048c6:	c701                	beqz	a4,800048ce <exec+0x2b8>
    if(*s == '/')
    800048c8:	fed71ce3          	bne	a4,a3,800048c0 <exec+0x2aa>
    800048cc:	bfc5                	j	800048bc <exec+0x2a6>
  safestrcpy(p->name, last, sizeof(p->name));
    800048ce:	4641                	li	a2,16
    800048d0:	df843583          	ld	a1,-520(s0)
    800048d4:	158a8513          	addi	a0,s5,344
    800048d8:	d2efc0ef          	jal	80000e06 <safestrcpy>
  oldpagetable = p->pagetable;
    800048dc:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    800048e0:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    800048e4:	e0843783          	ld	a5,-504(s0)
    800048e8:	04fab423          	sd	a5,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    800048ec:	058ab783          	ld	a5,88(s5)
    800048f0:	e6843703          	ld	a4,-408(s0)
    800048f4:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800048f6:	058ab783          	ld	a5,88(s5)
    800048fa:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800048fe:	85e6                	mv	a1,s9
    80004900:	90cfd0ef          	jal	80001a0c <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004904:	0004851b          	sext.w	a0,s1
    80004908:	79be                	ld	s3,488(sp)
    8000490a:	7a1e                	ld	s4,480(sp)
    8000490c:	6afe                	ld	s5,472(sp)
    8000490e:	6b5e                	ld	s6,464(sp)
    80004910:	6bbe                	ld	s7,456(sp)
    80004912:	6c1e                	ld	s8,448(sp)
    80004914:	7cfa                	ld	s9,440(sp)
    80004916:	7d5a                	ld	s10,432(sp)
    80004918:	b3b5                	j	80004684 <exec+0x6e>
    8000491a:	e1243423          	sd	s2,-504(s0)
    8000491e:	7dba                	ld	s11,424(sp)
    80004920:	a035                	j	8000494c <exec+0x336>
    80004922:	e1243423          	sd	s2,-504(s0)
    80004926:	7dba                	ld	s11,424(sp)
    80004928:	a015                	j	8000494c <exec+0x336>
    8000492a:	e1243423          	sd	s2,-504(s0)
    8000492e:	7dba                	ld	s11,424(sp)
    80004930:	a831                	j	8000494c <exec+0x336>
    80004932:	e1243423          	sd	s2,-504(s0)
    80004936:	7dba                	ld	s11,424(sp)
    80004938:	a811                	j	8000494c <exec+0x336>
    8000493a:	e1243423          	sd	s2,-504(s0)
    8000493e:	7dba                	ld	s11,424(sp)
    80004940:	a031                	j	8000494c <exec+0x336>
  ip = 0;
    80004942:	4a01                	li	s4,0
    80004944:	a021                	j	8000494c <exec+0x336>
    80004946:	4a01                	li	s4,0
  if(pagetable)
    80004948:	a011                	j	8000494c <exec+0x336>
    8000494a:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    8000494c:	e0843583          	ld	a1,-504(s0)
    80004950:	855a                	mv	a0,s6
    80004952:	8bafd0ef          	jal	80001a0c <proc_freepagetable>
  return -1;
    80004956:	557d                	li	a0,-1
  if(ip){
    80004958:	000a1b63          	bnez	s4,8000496e <exec+0x358>
    8000495c:	79be                	ld	s3,488(sp)
    8000495e:	7a1e                	ld	s4,480(sp)
    80004960:	6afe                	ld	s5,472(sp)
    80004962:	6b5e                	ld	s6,464(sp)
    80004964:	6bbe                	ld	s7,456(sp)
    80004966:	6c1e                	ld	s8,448(sp)
    80004968:	7cfa                	ld	s9,440(sp)
    8000496a:	7d5a                	ld	s10,432(sp)
    8000496c:	bb21                	j	80004684 <exec+0x6e>
    8000496e:	79be                	ld	s3,488(sp)
    80004970:	6afe                	ld	s5,472(sp)
    80004972:	6b5e                	ld	s6,464(sp)
    80004974:	6bbe                	ld	s7,456(sp)
    80004976:	6c1e                	ld	s8,448(sp)
    80004978:	7cfa                	ld	s9,440(sp)
    8000497a:	7d5a                	ld	s10,432(sp)
    8000497c:	b9ed                	j	80004676 <exec+0x60>
    8000497e:	6b5e                	ld	s6,464(sp)
    80004980:	b9dd                	j	80004676 <exec+0x60>
  sz = sz1;
    80004982:	e0843983          	ld	s3,-504(s0)
    80004986:	b595                	j	800047ea <exec+0x1d4>

0000000080004988 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004988:	7179                	addi	sp,sp,-48
    8000498a:	f406                	sd	ra,40(sp)
    8000498c:	f022                	sd	s0,32(sp)
    8000498e:	ec26                	sd	s1,24(sp)
    80004990:	e84a                	sd	s2,16(sp)
    80004992:	1800                	addi	s0,sp,48
    80004994:	892e                	mv	s2,a1
    80004996:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004998:	fdc40593          	addi	a1,s0,-36
    8000499c:	f6bfd0ef          	jal	80002906 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    800049a0:	fdc42703          	lw	a4,-36(s0)
    800049a4:	47bd                	li	a5,15
    800049a6:	02e7e963          	bltu	a5,a4,800049d8 <argfd+0x50>
    800049aa:	f37fc0ef          	jal	800018e0 <myproc>
    800049ae:	fdc42703          	lw	a4,-36(s0)
    800049b2:	01a70793          	addi	a5,a4,26
    800049b6:	078e                	slli	a5,a5,0x3
    800049b8:	953e                	add	a0,a0,a5
    800049ba:	611c                	ld	a5,0(a0)
    800049bc:	c385                	beqz	a5,800049dc <argfd+0x54>
    return -1;
  if(pfd)
    800049be:	00090463          	beqz	s2,800049c6 <argfd+0x3e>
    *pfd = fd;
    800049c2:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    800049c6:	4501                	li	a0,0
  if(pf)
    800049c8:	c091                	beqz	s1,800049cc <argfd+0x44>
    *pf = f;
    800049ca:	e09c                	sd	a5,0(s1)
}
    800049cc:	70a2                	ld	ra,40(sp)
    800049ce:	7402                	ld	s0,32(sp)
    800049d0:	64e2                	ld	s1,24(sp)
    800049d2:	6942                	ld	s2,16(sp)
    800049d4:	6145                	addi	sp,sp,48
    800049d6:	8082                	ret
    return -1;
    800049d8:	557d                	li	a0,-1
    800049da:	bfcd                	j	800049cc <argfd+0x44>
    800049dc:	557d                	li	a0,-1
    800049de:	b7fd                	j	800049cc <argfd+0x44>

00000000800049e0 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    800049e0:	1101                	addi	sp,sp,-32
    800049e2:	ec06                	sd	ra,24(sp)
    800049e4:	e822                	sd	s0,16(sp)
    800049e6:	e426                	sd	s1,8(sp)
    800049e8:	1000                	addi	s0,sp,32
    800049ea:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    800049ec:	ef5fc0ef          	jal	800018e0 <myproc>
    800049f0:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    800049f2:	0d050793          	addi	a5,a0,208
    800049f6:	4501                	li	a0,0
    800049f8:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    800049fa:	6398                	ld	a4,0(a5)
    800049fc:	cb19                	beqz	a4,80004a12 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    800049fe:	2505                	addiw	a0,a0,1
    80004a00:	07a1                	addi	a5,a5,8
    80004a02:	fed51ce3          	bne	a0,a3,800049fa <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004a06:	557d                	li	a0,-1
}
    80004a08:	60e2                	ld	ra,24(sp)
    80004a0a:	6442                	ld	s0,16(sp)
    80004a0c:	64a2                	ld	s1,8(sp)
    80004a0e:	6105                	addi	sp,sp,32
    80004a10:	8082                	ret
      p->ofile[fd] = f;
    80004a12:	01a50793          	addi	a5,a0,26
    80004a16:	078e                	slli	a5,a5,0x3
    80004a18:	963e                	add	a2,a2,a5
    80004a1a:	e204                	sd	s1,0(a2)
      return fd;
    80004a1c:	b7f5                	j	80004a08 <fdalloc+0x28>

0000000080004a1e <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004a1e:	715d                	addi	sp,sp,-80
    80004a20:	e486                	sd	ra,72(sp)
    80004a22:	e0a2                	sd	s0,64(sp)
    80004a24:	fc26                	sd	s1,56(sp)
    80004a26:	f84a                	sd	s2,48(sp)
    80004a28:	f44e                	sd	s3,40(sp)
    80004a2a:	ec56                	sd	s5,24(sp)
    80004a2c:	e85a                	sd	s6,16(sp)
    80004a2e:	0880                	addi	s0,sp,80
    80004a30:	8b2e                	mv	s6,a1
    80004a32:	89b2                	mv	s3,a2
    80004a34:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004a36:	fb040593          	addi	a1,s0,-80
    80004a3a:	822ff0ef          	jal	80003a5c <nameiparent>
    80004a3e:	84aa                	mv	s1,a0
    80004a40:	10050a63          	beqz	a0,80004b54 <create+0x136>
    return 0;

  ilock(dp);
    80004a44:	925fe0ef          	jal	80003368 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004a48:	4601                	li	a2,0
    80004a4a:	fb040593          	addi	a1,s0,-80
    80004a4e:	8526                	mv	a0,s1
    80004a50:	d8dfe0ef          	jal	800037dc <dirlookup>
    80004a54:	8aaa                	mv	s5,a0
    80004a56:	c129                	beqz	a0,80004a98 <create+0x7a>
    iunlockput(dp);
    80004a58:	8526                	mv	a0,s1
    80004a5a:	b19fe0ef          	jal	80003572 <iunlockput>
    ilock(ip);
    80004a5e:	8556                	mv	a0,s5
    80004a60:	909fe0ef          	jal	80003368 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004a64:	4789                	li	a5,2
    80004a66:	02fb1463          	bne	s6,a5,80004a8e <create+0x70>
    80004a6a:	044ad783          	lhu	a5,68(s5)
    80004a6e:	37f9                	addiw	a5,a5,-2
    80004a70:	17c2                	slli	a5,a5,0x30
    80004a72:	93c1                	srli	a5,a5,0x30
    80004a74:	4705                	li	a4,1
    80004a76:	00f76c63          	bltu	a4,a5,80004a8e <create+0x70>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004a7a:	8556                	mv	a0,s5
    80004a7c:	60a6                	ld	ra,72(sp)
    80004a7e:	6406                	ld	s0,64(sp)
    80004a80:	74e2                	ld	s1,56(sp)
    80004a82:	7942                	ld	s2,48(sp)
    80004a84:	79a2                	ld	s3,40(sp)
    80004a86:	6ae2                	ld	s5,24(sp)
    80004a88:	6b42                	ld	s6,16(sp)
    80004a8a:	6161                	addi	sp,sp,80
    80004a8c:	8082                	ret
    iunlockput(ip);
    80004a8e:	8556                	mv	a0,s5
    80004a90:	ae3fe0ef          	jal	80003572 <iunlockput>
    return 0;
    80004a94:	4a81                	li	s5,0
    80004a96:	b7d5                	j	80004a7a <create+0x5c>
    80004a98:	f052                	sd	s4,32(sp)
  if((ip = ialloc(dp->dev, type)) == 0){
    80004a9a:	85da                	mv	a1,s6
    80004a9c:	4088                	lw	a0,0(s1)
    80004a9e:	f5afe0ef          	jal	800031f8 <ialloc>
    80004aa2:	8a2a                	mv	s4,a0
    80004aa4:	cd15                	beqz	a0,80004ae0 <create+0xc2>
  ilock(ip);
    80004aa6:	8c3fe0ef          	jal	80003368 <ilock>
  ip->major = major;
    80004aaa:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004aae:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004ab2:	4905                	li	s2,1
    80004ab4:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004ab8:	8552                	mv	a0,s4
    80004aba:	ffafe0ef          	jal	800032b4 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004abe:	032b0763          	beq	s6,s2,80004aec <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004ac2:	004a2603          	lw	a2,4(s4)
    80004ac6:	fb040593          	addi	a1,s0,-80
    80004aca:	8526                	mv	a0,s1
    80004acc:	eddfe0ef          	jal	800039a8 <dirlink>
    80004ad0:	06054563          	bltz	a0,80004b3a <create+0x11c>
  iunlockput(dp);
    80004ad4:	8526                	mv	a0,s1
    80004ad6:	a9dfe0ef          	jal	80003572 <iunlockput>
  return ip;
    80004ada:	8ad2                	mv	s5,s4
    80004adc:	7a02                	ld	s4,32(sp)
    80004ade:	bf71                	j	80004a7a <create+0x5c>
    iunlockput(dp);
    80004ae0:	8526                	mv	a0,s1
    80004ae2:	a91fe0ef          	jal	80003572 <iunlockput>
    return 0;
    80004ae6:	8ad2                	mv	s5,s4
    80004ae8:	7a02                	ld	s4,32(sp)
    80004aea:	bf41                	j	80004a7a <create+0x5c>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004aec:	004a2603          	lw	a2,4(s4)
    80004af0:	00003597          	auipc	a1,0x3
    80004af4:	b5058593          	addi	a1,a1,-1200 # 80007640 <etext+0x640>
    80004af8:	8552                	mv	a0,s4
    80004afa:	eaffe0ef          	jal	800039a8 <dirlink>
    80004afe:	02054e63          	bltz	a0,80004b3a <create+0x11c>
    80004b02:	40d0                	lw	a2,4(s1)
    80004b04:	00003597          	auipc	a1,0x3
    80004b08:	b4458593          	addi	a1,a1,-1212 # 80007648 <etext+0x648>
    80004b0c:	8552                	mv	a0,s4
    80004b0e:	e9bfe0ef          	jal	800039a8 <dirlink>
    80004b12:	02054463          	bltz	a0,80004b3a <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004b16:	004a2603          	lw	a2,4(s4)
    80004b1a:	fb040593          	addi	a1,s0,-80
    80004b1e:	8526                	mv	a0,s1
    80004b20:	e89fe0ef          	jal	800039a8 <dirlink>
    80004b24:	00054b63          	bltz	a0,80004b3a <create+0x11c>
    dp->nlink++;  // for ".."
    80004b28:	04a4d783          	lhu	a5,74(s1)
    80004b2c:	2785                	addiw	a5,a5,1
    80004b2e:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004b32:	8526                	mv	a0,s1
    80004b34:	f80fe0ef          	jal	800032b4 <iupdate>
    80004b38:	bf71                	j	80004ad4 <create+0xb6>
  ip->nlink = 0;
    80004b3a:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004b3e:	8552                	mv	a0,s4
    80004b40:	f74fe0ef          	jal	800032b4 <iupdate>
  iunlockput(ip);
    80004b44:	8552                	mv	a0,s4
    80004b46:	a2dfe0ef          	jal	80003572 <iunlockput>
  iunlockput(dp);
    80004b4a:	8526                	mv	a0,s1
    80004b4c:	a27fe0ef          	jal	80003572 <iunlockput>
  return 0;
    80004b50:	7a02                	ld	s4,32(sp)
    80004b52:	b725                	j	80004a7a <create+0x5c>
    return 0;
    80004b54:	8aaa                	mv	s5,a0
    80004b56:	b715                	j	80004a7a <create+0x5c>

0000000080004b58 <sys_dup>:
{
    80004b58:	7179                	addi	sp,sp,-48
    80004b5a:	f406                	sd	ra,40(sp)
    80004b5c:	f022                	sd	s0,32(sp)
    80004b5e:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004b60:	fd840613          	addi	a2,s0,-40
    80004b64:	4581                	li	a1,0
    80004b66:	4501                	li	a0,0
    80004b68:	e21ff0ef          	jal	80004988 <argfd>
    return -1;
    80004b6c:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004b6e:	02054363          	bltz	a0,80004b94 <sys_dup+0x3c>
    80004b72:	ec26                	sd	s1,24(sp)
    80004b74:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004b76:	fd843903          	ld	s2,-40(s0)
    80004b7a:	854a                	mv	a0,s2
    80004b7c:	e65ff0ef          	jal	800049e0 <fdalloc>
    80004b80:	84aa                	mv	s1,a0
    return -1;
    80004b82:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004b84:	00054d63          	bltz	a0,80004b9e <sys_dup+0x46>
  filedup(f);
    80004b88:	854a                	mv	a0,s2
    80004b8a:	c48ff0ef          	jal	80003fd2 <filedup>
  return fd;
    80004b8e:	87a6                	mv	a5,s1
    80004b90:	64e2                	ld	s1,24(sp)
    80004b92:	6942                	ld	s2,16(sp)
}
    80004b94:	853e                	mv	a0,a5
    80004b96:	70a2                	ld	ra,40(sp)
    80004b98:	7402                	ld	s0,32(sp)
    80004b9a:	6145                	addi	sp,sp,48
    80004b9c:	8082                	ret
    80004b9e:	64e2                	ld	s1,24(sp)
    80004ba0:	6942                	ld	s2,16(sp)
    80004ba2:	bfcd                	j	80004b94 <sys_dup+0x3c>

0000000080004ba4 <sys_read>:
{
    80004ba4:	7179                	addi	sp,sp,-48
    80004ba6:	f406                	sd	ra,40(sp)
    80004ba8:	f022                	sd	s0,32(sp)
    80004baa:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004bac:	fd840593          	addi	a1,s0,-40
    80004bb0:	4505                	li	a0,1
    80004bb2:	d71fd0ef          	jal	80002922 <argaddr>
  argint(2, &n);
    80004bb6:	fe440593          	addi	a1,s0,-28
    80004bba:	4509                	li	a0,2
    80004bbc:	d4bfd0ef          	jal	80002906 <argint>
  if(argfd(0, 0, &f) < 0)
    80004bc0:	fe840613          	addi	a2,s0,-24
    80004bc4:	4581                	li	a1,0
    80004bc6:	4501                	li	a0,0
    80004bc8:	dc1ff0ef          	jal	80004988 <argfd>
    80004bcc:	87aa                	mv	a5,a0
    return -1;
    80004bce:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004bd0:	0007ca63          	bltz	a5,80004be4 <sys_read+0x40>
  return fileread(f, p, n);
    80004bd4:	fe442603          	lw	a2,-28(s0)
    80004bd8:	fd843583          	ld	a1,-40(s0)
    80004bdc:	fe843503          	ld	a0,-24(s0)
    80004be0:	d58ff0ef          	jal	80004138 <fileread>
}
    80004be4:	70a2                	ld	ra,40(sp)
    80004be6:	7402                	ld	s0,32(sp)
    80004be8:	6145                	addi	sp,sp,48
    80004bea:	8082                	ret

0000000080004bec <sys_write>:
{
    80004bec:	7179                	addi	sp,sp,-48
    80004bee:	f406                	sd	ra,40(sp)
    80004bf0:	f022                	sd	s0,32(sp)
    80004bf2:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004bf4:	fd840593          	addi	a1,s0,-40
    80004bf8:	4505                	li	a0,1
    80004bfa:	d29fd0ef          	jal	80002922 <argaddr>
  argint(2, &n);
    80004bfe:	fe440593          	addi	a1,s0,-28
    80004c02:	4509                	li	a0,2
    80004c04:	d03fd0ef          	jal	80002906 <argint>
  if(argfd(0, 0, &f) < 0)
    80004c08:	fe840613          	addi	a2,s0,-24
    80004c0c:	4581                	li	a1,0
    80004c0e:	4501                	li	a0,0
    80004c10:	d79ff0ef          	jal	80004988 <argfd>
    80004c14:	87aa                	mv	a5,a0
    return -1;
    80004c16:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004c18:	0007ca63          	bltz	a5,80004c2c <sys_write+0x40>
  return filewrite(f, p, n);
    80004c1c:	fe442603          	lw	a2,-28(s0)
    80004c20:	fd843583          	ld	a1,-40(s0)
    80004c24:	fe843503          	ld	a0,-24(s0)
    80004c28:	dceff0ef          	jal	800041f6 <filewrite>
}
    80004c2c:	70a2                	ld	ra,40(sp)
    80004c2e:	7402                	ld	s0,32(sp)
    80004c30:	6145                	addi	sp,sp,48
    80004c32:	8082                	ret

0000000080004c34 <sys_close>:
{
    80004c34:	1101                	addi	sp,sp,-32
    80004c36:	ec06                	sd	ra,24(sp)
    80004c38:	e822                	sd	s0,16(sp)
    80004c3a:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004c3c:	fe040613          	addi	a2,s0,-32
    80004c40:	fec40593          	addi	a1,s0,-20
    80004c44:	4501                	li	a0,0
    80004c46:	d43ff0ef          	jal	80004988 <argfd>
    return -1;
    80004c4a:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004c4c:	02054063          	bltz	a0,80004c6c <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004c50:	c91fc0ef          	jal	800018e0 <myproc>
    80004c54:	fec42783          	lw	a5,-20(s0)
    80004c58:	07e9                	addi	a5,a5,26
    80004c5a:	078e                	slli	a5,a5,0x3
    80004c5c:	953e                	add	a0,a0,a5
    80004c5e:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004c62:	fe043503          	ld	a0,-32(s0)
    80004c66:	bb2ff0ef          	jal	80004018 <fileclose>
  return 0;
    80004c6a:	4781                	li	a5,0
}
    80004c6c:	853e                	mv	a0,a5
    80004c6e:	60e2                	ld	ra,24(sp)
    80004c70:	6442                	ld	s0,16(sp)
    80004c72:	6105                	addi	sp,sp,32
    80004c74:	8082                	ret

0000000080004c76 <sys_fstat>:
{
    80004c76:	1101                	addi	sp,sp,-32
    80004c78:	ec06                	sd	ra,24(sp)
    80004c7a:	e822                	sd	s0,16(sp)
    80004c7c:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004c7e:	fe040593          	addi	a1,s0,-32
    80004c82:	4505                	li	a0,1
    80004c84:	c9ffd0ef          	jal	80002922 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004c88:	fe840613          	addi	a2,s0,-24
    80004c8c:	4581                	li	a1,0
    80004c8e:	4501                	li	a0,0
    80004c90:	cf9ff0ef          	jal	80004988 <argfd>
    80004c94:	87aa                	mv	a5,a0
    return -1;
    80004c96:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004c98:	0007c863          	bltz	a5,80004ca8 <sys_fstat+0x32>
  return filestat(f, st);
    80004c9c:	fe043583          	ld	a1,-32(s0)
    80004ca0:	fe843503          	ld	a0,-24(s0)
    80004ca4:	c36ff0ef          	jal	800040da <filestat>
}
    80004ca8:	60e2                	ld	ra,24(sp)
    80004caa:	6442                	ld	s0,16(sp)
    80004cac:	6105                	addi	sp,sp,32
    80004cae:	8082                	ret

0000000080004cb0 <sys_link>:
{
    80004cb0:	7169                	addi	sp,sp,-304
    80004cb2:	f606                	sd	ra,296(sp)
    80004cb4:	f222                	sd	s0,288(sp)
    80004cb6:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004cb8:	08000613          	li	a2,128
    80004cbc:	ed040593          	addi	a1,s0,-304
    80004cc0:	4501                	li	a0,0
    80004cc2:	c7dfd0ef          	jal	8000293e <argstr>
    return -1;
    80004cc6:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004cc8:	0c054e63          	bltz	a0,80004da4 <sys_link+0xf4>
    80004ccc:	08000613          	li	a2,128
    80004cd0:	f5040593          	addi	a1,s0,-176
    80004cd4:	4505                	li	a0,1
    80004cd6:	c69fd0ef          	jal	8000293e <argstr>
    return -1;
    80004cda:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004cdc:	0c054463          	bltz	a0,80004da4 <sys_link+0xf4>
    80004ce0:	ee26                	sd	s1,280(sp)
  begin_op();
    80004ce2:	f1dfe0ef          	jal	80003bfe <begin_op>
  if((ip = namei(old)) == 0){
    80004ce6:	ed040513          	addi	a0,s0,-304
    80004cea:	d59fe0ef          	jal	80003a42 <namei>
    80004cee:	84aa                	mv	s1,a0
    80004cf0:	c53d                	beqz	a0,80004d5e <sys_link+0xae>
  ilock(ip);
    80004cf2:	e76fe0ef          	jal	80003368 <ilock>
  if(ip->type == T_DIR){
    80004cf6:	04449703          	lh	a4,68(s1)
    80004cfa:	4785                	li	a5,1
    80004cfc:	06f70663          	beq	a4,a5,80004d68 <sys_link+0xb8>
    80004d00:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004d02:	04a4d783          	lhu	a5,74(s1)
    80004d06:	2785                	addiw	a5,a5,1
    80004d08:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004d0c:	8526                	mv	a0,s1
    80004d0e:	da6fe0ef          	jal	800032b4 <iupdate>
  iunlock(ip);
    80004d12:	8526                	mv	a0,s1
    80004d14:	f02fe0ef          	jal	80003416 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004d18:	fd040593          	addi	a1,s0,-48
    80004d1c:	f5040513          	addi	a0,s0,-176
    80004d20:	d3dfe0ef          	jal	80003a5c <nameiparent>
    80004d24:	892a                	mv	s2,a0
    80004d26:	cd21                	beqz	a0,80004d7e <sys_link+0xce>
  ilock(dp);
    80004d28:	e40fe0ef          	jal	80003368 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004d2c:	00092703          	lw	a4,0(s2)
    80004d30:	409c                	lw	a5,0(s1)
    80004d32:	04f71363          	bne	a4,a5,80004d78 <sys_link+0xc8>
    80004d36:	40d0                	lw	a2,4(s1)
    80004d38:	fd040593          	addi	a1,s0,-48
    80004d3c:	854a                	mv	a0,s2
    80004d3e:	c6bfe0ef          	jal	800039a8 <dirlink>
    80004d42:	02054b63          	bltz	a0,80004d78 <sys_link+0xc8>
  iunlockput(dp);
    80004d46:	854a                	mv	a0,s2
    80004d48:	82bfe0ef          	jal	80003572 <iunlockput>
  iput(ip);
    80004d4c:	8526                	mv	a0,s1
    80004d4e:	f9cfe0ef          	jal	800034ea <iput>
  end_op();
    80004d52:	f17fe0ef          	jal	80003c68 <end_op>
  return 0;
    80004d56:	4781                	li	a5,0
    80004d58:	64f2                	ld	s1,280(sp)
    80004d5a:	6952                	ld	s2,272(sp)
    80004d5c:	a0a1                	j	80004da4 <sys_link+0xf4>
    end_op();
    80004d5e:	f0bfe0ef          	jal	80003c68 <end_op>
    return -1;
    80004d62:	57fd                	li	a5,-1
    80004d64:	64f2                	ld	s1,280(sp)
    80004d66:	a83d                	j	80004da4 <sys_link+0xf4>
    iunlockput(ip);
    80004d68:	8526                	mv	a0,s1
    80004d6a:	809fe0ef          	jal	80003572 <iunlockput>
    end_op();
    80004d6e:	efbfe0ef          	jal	80003c68 <end_op>
    return -1;
    80004d72:	57fd                	li	a5,-1
    80004d74:	64f2                	ld	s1,280(sp)
    80004d76:	a03d                	j	80004da4 <sys_link+0xf4>
    iunlockput(dp);
    80004d78:	854a                	mv	a0,s2
    80004d7a:	ff8fe0ef          	jal	80003572 <iunlockput>
  ilock(ip);
    80004d7e:	8526                	mv	a0,s1
    80004d80:	de8fe0ef          	jal	80003368 <ilock>
  ip->nlink--;
    80004d84:	04a4d783          	lhu	a5,74(s1)
    80004d88:	37fd                	addiw	a5,a5,-1
    80004d8a:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004d8e:	8526                	mv	a0,s1
    80004d90:	d24fe0ef          	jal	800032b4 <iupdate>
  iunlockput(ip);
    80004d94:	8526                	mv	a0,s1
    80004d96:	fdcfe0ef          	jal	80003572 <iunlockput>
  end_op();
    80004d9a:	ecffe0ef          	jal	80003c68 <end_op>
  return -1;
    80004d9e:	57fd                	li	a5,-1
    80004da0:	64f2                	ld	s1,280(sp)
    80004da2:	6952                	ld	s2,272(sp)
}
    80004da4:	853e                	mv	a0,a5
    80004da6:	70b2                	ld	ra,296(sp)
    80004da8:	7412                	ld	s0,288(sp)
    80004daa:	6155                	addi	sp,sp,304
    80004dac:	8082                	ret

0000000080004dae <sys_unlink>:
{
    80004dae:	7151                	addi	sp,sp,-240
    80004db0:	f586                	sd	ra,232(sp)
    80004db2:	f1a2                	sd	s0,224(sp)
    80004db4:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004db6:	08000613          	li	a2,128
    80004dba:	f3040593          	addi	a1,s0,-208
    80004dbe:	4501                	li	a0,0
    80004dc0:	b7ffd0ef          	jal	8000293e <argstr>
    80004dc4:	16054063          	bltz	a0,80004f24 <sys_unlink+0x176>
    80004dc8:	eda6                	sd	s1,216(sp)
  begin_op();
    80004dca:	e35fe0ef          	jal	80003bfe <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004dce:	fb040593          	addi	a1,s0,-80
    80004dd2:	f3040513          	addi	a0,s0,-208
    80004dd6:	c87fe0ef          	jal	80003a5c <nameiparent>
    80004dda:	84aa                	mv	s1,a0
    80004ddc:	c945                	beqz	a0,80004e8c <sys_unlink+0xde>
  ilock(dp);
    80004dde:	d8afe0ef          	jal	80003368 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004de2:	00003597          	auipc	a1,0x3
    80004de6:	85e58593          	addi	a1,a1,-1954 # 80007640 <etext+0x640>
    80004dea:	fb040513          	addi	a0,s0,-80
    80004dee:	9d9fe0ef          	jal	800037c6 <namecmp>
    80004df2:	10050e63          	beqz	a0,80004f0e <sys_unlink+0x160>
    80004df6:	00003597          	auipc	a1,0x3
    80004dfa:	85258593          	addi	a1,a1,-1966 # 80007648 <etext+0x648>
    80004dfe:	fb040513          	addi	a0,s0,-80
    80004e02:	9c5fe0ef          	jal	800037c6 <namecmp>
    80004e06:	10050463          	beqz	a0,80004f0e <sys_unlink+0x160>
    80004e0a:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004e0c:	f2c40613          	addi	a2,s0,-212
    80004e10:	fb040593          	addi	a1,s0,-80
    80004e14:	8526                	mv	a0,s1
    80004e16:	9c7fe0ef          	jal	800037dc <dirlookup>
    80004e1a:	892a                	mv	s2,a0
    80004e1c:	0e050863          	beqz	a0,80004f0c <sys_unlink+0x15e>
  ilock(ip);
    80004e20:	d48fe0ef          	jal	80003368 <ilock>
  if(ip->nlink < 1)
    80004e24:	04a91783          	lh	a5,74(s2)
    80004e28:	06f05763          	blez	a5,80004e96 <sys_unlink+0xe8>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004e2c:	04491703          	lh	a4,68(s2)
    80004e30:	4785                	li	a5,1
    80004e32:	06f70963          	beq	a4,a5,80004ea4 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80004e36:	4641                	li	a2,16
    80004e38:	4581                	li	a1,0
    80004e3a:	fc040513          	addi	a0,s0,-64
    80004e3e:	e8bfb0ef          	jal	80000cc8 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004e42:	4741                	li	a4,16
    80004e44:	f2c42683          	lw	a3,-212(s0)
    80004e48:	fc040613          	addi	a2,s0,-64
    80004e4c:	4581                	li	a1,0
    80004e4e:	8526                	mv	a0,s1
    80004e50:	869fe0ef          	jal	800036b8 <writei>
    80004e54:	47c1                	li	a5,16
    80004e56:	08f51b63          	bne	a0,a5,80004eec <sys_unlink+0x13e>
  if(ip->type == T_DIR){
    80004e5a:	04491703          	lh	a4,68(s2)
    80004e5e:	4785                	li	a5,1
    80004e60:	08f70d63          	beq	a4,a5,80004efa <sys_unlink+0x14c>
  iunlockput(dp);
    80004e64:	8526                	mv	a0,s1
    80004e66:	f0cfe0ef          	jal	80003572 <iunlockput>
  ip->nlink--;
    80004e6a:	04a95783          	lhu	a5,74(s2)
    80004e6e:	37fd                	addiw	a5,a5,-1
    80004e70:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004e74:	854a                	mv	a0,s2
    80004e76:	c3efe0ef          	jal	800032b4 <iupdate>
  iunlockput(ip);
    80004e7a:	854a                	mv	a0,s2
    80004e7c:	ef6fe0ef          	jal	80003572 <iunlockput>
  end_op();
    80004e80:	de9fe0ef          	jal	80003c68 <end_op>
  return 0;
    80004e84:	4501                	li	a0,0
    80004e86:	64ee                	ld	s1,216(sp)
    80004e88:	694e                	ld	s2,208(sp)
    80004e8a:	a849                	j	80004f1c <sys_unlink+0x16e>
    end_op();
    80004e8c:	dddfe0ef          	jal	80003c68 <end_op>
    return -1;
    80004e90:	557d                	li	a0,-1
    80004e92:	64ee                	ld	s1,216(sp)
    80004e94:	a061                	j	80004f1c <sys_unlink+0x16e>
    80004e96:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80004e98:	00002517          	auipc	a0,0x2
    80004e9c:	7b850513          	addi	a0,a0,1976 # 80007650 <etext+0x650>
    80004ea0:	8f5fb0ef          	jal	80000794 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004ea4:	04c92703          	lw	a4,76(s2)
    80004ea8:	02000793          	li	a5,32
    80004eac:	f8e7f5e3          	bgeu	a5,a4,80004e36 <sys_unlink+0x88>
    80004eb0:	e5ce                	sd	s3,200(sp)
    80004eb2:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004eb6:	4741                	li	a4,16
    80004eb8:	86ce                	mv	a3,s3
    80004eba:	f1840613          	addi	a2,s0,-232
    80004ebe:	4581                	li	a1,0
    80004ec0:	854a                	mv	a0,s2
    80004ec2:	efafe0ef          	jal	800035bc <readi>
    80004ec6:	47c1                	li	a5,16
    80004ec8:	00f51c63          	bne	a0,a5,80004ee0 <sys_unlink+0x132>
    if(de.inum != 0)
    80004ecc:	f1845783          	lhu	a5,-232(s0)
    80004ed0:	efa1                	bnez	a5,80004f28 <sys_unlink+0x17a>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004ed2:	29c1                	addiw	s3,s3,16
    80004ed4:	04c92783          	lw	a5,76(s2)
    80004ed8:	fcf9efe3          	bltu	s3,a5,80004eb6 <sys_unlink+0x108>
    80004edc:	69ae                	ld	s3,200(sp)
    80004ede:	bfa1                	j	80004e36 <sys_unlink+0x88>
      panic("isdirempty: readi");
    80004ee0:	00002517          	auipc	a0,0x2
    80004ee4:	78850513          	addi	a0,a0,1928 # 80007668 <etext+0x668>
    80004ee8:	8adfb0ef          	jal	80000794 <panic>
    80004eec:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    80004eee:	00002517          	auipc	a0,0x2
    80004ef2:	79250513          	addi	a0,a0,1938 # 80007680 <etext+0x680>
    80004ef6:	89ffb0ef          	jal	80000794 <panic>
    dp->nlink--;
    80004efa:	04a4d783          	lhu	a5,74(s1)
    80004efe:	37fd                	addiw	a5,a5,-1
    80004f00:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004f04:	8526                	mv	a0,s1
    80004f06:	baefe0ef          	jal	800032b4 <iupdate>
    80004f0a:	bfa9                	j	80004e64 <sys_unlink+0xb6>
    80004f0c:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004f0e:	8526                	mv	a0,s1
    80004f10:	e62fe0ef          	jal	80003572 <iunlockput>
  end_op();
    80004f14:	d55fe0ef          	jal	80003c68 <end_op>
  return -1;
    80004f18:	557d                	li	a0,-1
    80004f1a:	64ee                	ld	s1,216(sp)
}
    80004f1c:	70ae                	ld	ra,232(sp)
    80004f1e:	740e                	ld	s0,224(sp)
    80004f20:	616d                	addi	sp,sp,240
    80004f22:	8082                	ret
    return -1;
    80004f24:	557d                	li	a0,-1
    80004f26:	bfdd                	j	80004f1c <sys_unlink+0x16e>
    iunlockput(ip);
    80004f28:	854a                	mv	a0,s2
    80004f2a:	e48fe0ef          	jal	80003572 <iunlockput>
    goto bad;
    80004f2e:	694e                	ld	s2,208(sp)
    80004f30:	69ae                	ld	s3,200(sp)
    80004f32:	bff1                	j	80004f0e <sys_unlink+0x160>

0000000080004f34 <sys_open>:

uint64
sys_open(void)
{
    80004f34:	7131                	addi	sp,sp,-192
    80004f36:	fd06                	sd	ra,184(sp)
    80004f38:	f922                	sd	s0,176(sp)
    80004f3a:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004f3c:	f4c40593          	addi	a1,s0,-180
    80004f40:	4505                	li	a0,1
    80004f42:	9c5fd0ef          	jal	80002906 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004f46:	08000613          	li	a2,128
    80004f4a:	f5040593          	addi	a1,s0,-176
    80004f4e:	4501                	li	a0,0
    80004f50:	9effd0ef          	jal	8000293e <argstr>
    80004f54:	87aa                	mv	a5,a0
    return -1;
    80004f56:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004f58:	0a07c263          	bltz	a5,80004ffc <sys_open+0xc8>
    80004f5c:	f526                	sd	s1,168(sp)

  begin_op();
    80004f5e:	ca1fe0ef          	jal	80003bfe <begin_op>

  if(omode & O_CREATE){
    80004f62:	f4c42783          	lw	a5,-180(s0)
    80004f66:	2007f793          	andi	a5,a5,512
    80004f6a:	c3d5                	beqz	a5,8000500e <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80004f6c:	4681                	li	a3,0
    80004f6e:	4601                	li	a2,0
    80004f70:	4589                	li	a1,2
    80004f72:	f5040513          	addi	a0,s0,-176
    80004f76:	aa9ff0ef          	jal	80004a1e <create>
    80004f7a:	84aa                	mv	s1,a0
    if(ip == 0){
    80004f7c:	c541                	beqz	a0,80005004 <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004f7e:	04449703          	lh	a4,68(s1)
    80004f82:	478d                	li	a5,3
    80004f84:	00f71763          	bne	a4,a5,80004f92 <sys_open+0x5e>
    80004f88:	0464d703          	lhu	a4,70(s1)
    80004f8c:	47a5                	li	a5,9
    80004f8e:	0ae7ed63          	bltu	a5,a4,80005048 <sys_open+0x114>
    80004f92:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004f94:	fe1fe0ef          	jal	80003f74 <filealloc>
    80004f98:	892a                	mv	s2,a0
    80004f9a:	c179                	beqz	a0,80005060 <sys_open+0x12c>
    80004f9c:	ed4e                	sd	s3,152(sp)
    80004f9e:	a43ff0ef          	jal	800049e0 <fdalloc>
    80004fa2:	89aa                	mv	s3,a0
    80004fa4:	0a054a63          	bltz	a0,80005058 <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004fa8:	04449703          	lh	a4,68(s1)
    80004fac:	478d                	li	a5,3
    80004fae:	0cf70263          	beq	a4,a5,80005072 <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004fb2:	4789                	li	a5,2
    80004fb4:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004fb8:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004fbc:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004fc0:	f4c42783          	lw	a5,-180(s0)
    80004fc4:	0017c713          	xori	a4,a5,1
    80004fc8:	8b05                	andi	a4,a4,1
    80004fca:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004fce:	0037f713          	andi	a4,a5,3
    80004fd2:	00e03733          	snez	a4,a4
    80004fd6:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004fda:	4007f793          	andi	a5,a5,1024
    80004fde:	c791                	beqz	a5,80004fea <sys_open+0xb6>
    80004fe0:	04449703          	lh	a4,68(s1)
    80004fe4:	4789                	li	a5,2
    80004fe6:	08f70d63          	beq	a4,a5,80005080 <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    80004fea:	8526                	mv	a0,s1
    80004fec:	c2afe0ef          	jal	80003416 <iunlock>
  end_op();
    80004ff0:	c79fe0ef          	jal	80003c68 <end_op>

  return fd;
    80004ff4:	854e                	mv	a0,s3
    80004ff6:	74aa                	ld	s1,168(sp)
    80004ff8:	790a                	ld	s2,160(sp)
    80004ffa:	69ea                	ld	s3,152(sp)
}
    80004ffc:	70ea                	ld	ra,184(sp)
    80004ffe:	744a                	ld	s0,176(sp)
    80005000:	6129                	addi	sp,sp,192
    80005002:	8082                	ret
      end_op();
    80005004:	c65fe0ef          	jal	80003c68 <end_op>
      return -1;
    80005008:	557d                	li	a0,-1
    8000500a:	74aa                	ld	s1,168(sp)
    8000500c:	bfc5                	j	80004ffc <sys_open+0xc8>
    if((ip = namei(path)) == 0){
    8000500e:	f5040513          	addi	a0,s0,-176
    80005012:	a31fe0ef          	jal	80003a42 <namei>
    80005016:	84aa                	mv	s1,a0
    80005018:	c11d                	beqz	a0,8000503e <sys_open+0x10a>
    ilock(ip);
    8000501a:	b4efe0ef          	jal	80003368 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    8000501e:	04449703          	lh	a4,68(s1)
    80005022:	4785                	li	a5,1
    80005024:	f4f71de3          	bne	a4,a5,80004f7e <sys_open+0x4a>
    80005028:	f4c42783          	lw	a5,-180(s0)
    8000502c:	d3bd                	beqz	a5,80004f92 <sys_open+0x5e>
      iunlockput(ip);
    8000502e:	8526                	mv	a0,s1
    80005030:	d42fe0ef          	jal	80003572 <iunlockput>
      end_op();
    80005034:	c35fe0ef          	jal	80003c68 <end_op>
      return -1;
    80005038:	557d                	li	a0,-1
    8000503a:	74aa                	ld	s1,168(sp)
    8000503c:	b7c1                	j	80004ffc <sys_open+0xc8>
      end_op();
    8000503e:	c2bfe0ef          	jal	80003c68 <end_op>
      return -1;
    80005042:	557d                	li	a0,-1
    80005044:	74aa                	ld	s1,168(sp)
    80005046:	bf5d                	j	80004ffc <sys_open+0xc8>
    iunlockput(ip);
    80005048:	8526                	mv	a0,s1
    8000504a:	d28fe0ef          	jal	80003572 <iunlockput>
    end_op();
    8000504e:	c1bfe0ef          	jal	80003c68 <end_op>
    return -1;
    80005052:	557d                	li	a0,-1
    80005054:	74aa                	ld	s1,168(sp)
    80005056:	b75d                	j	80004ffc <sys_open+0xc8>
      fileclose(f);
    80005058:	854a                	mv	a0,s2
    8000505a:	fbffe0ef          	jal	80004018 <fileclose>
    8000505e:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005060:	8526                	mv	a0,s1
    80005062:	d10fe0ef          	jal	80003572 <iunlockput>
    end_op();
    80005066:	c03fe0ef          	jal	80003c68 <end_op>
    return -1;
    8000506a:	557d                	li	a0,-1
    8000506c:	74aa                	ld	s1,168(sp)
    8000506e:	790a                	ld	s2,160(sp)
    80005070:	b771                	j	80004ffc <sys_open+0xc8>
    f->type = FD_DEVICE;
    80005072:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    80005076:	04649783          	lh	a5,70(s1)
    8000507a:	02f91223          	sh	a5,36(s2)
    8000507e:	bf3d                	j	80004fbc <sys_open+0x88>
    itrunc(ip);
    80005080:	8526                	mv	a0,s1
    80005082:	bd4fe0ef          	jal	80003456 <itrunc>
    80005086:	b795                	j	80004fea <sys_open+0xb6>

0000000080005088 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005088:	7175                	addi	sp,sp,-144
    8000508a:	e506                	sd	ra,136(sp)
    8000508c:	e122                	sd	s0,128(sp)
    8000508e:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005090:	b6ffe0ef          	jal	80003bfe <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005094:	08000613          	li	a2,128
    80005098:	f7040593          	addi	a1,s0,-144
    8000509c:	4501                	li	a0,0
    8000509e:	8a1fd0ef          	jal	8000293e <argstr>
    800050a2:	02054363          	bltz	a0,800050c8 <sys_mkdir+0x40>
    800050a6:	4681                	li	a3,0
    800050a8:	4601                	li	a2,0
    800050aa:	4585                	li	a1,1
    800050ac:	f7040513          	addi	a0,s0,-144
    800050b0:	96fff0ef          	jal	80004a1e <create>
    800050b4:	c911                	beqz	a0,800050c8 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800050b6:	cbcfe0ef          	jal	80003572 <iunlockput>
  end_op();
    800050ba:	baffe0ef          	jal	80003c68 <end_op>
  return 0;
    800050be:	4501                	li	a0,0
}
    800050c0:	60aa                	ld	ra,136(sp)
    800050c2:	640a                	ld	s0,128(sp)
    800050c4:	6149                	addi	sp,sp,144
    800050c6:	8082                	ret
    end_op();
    800050c8:	ba1fe0ef          	jal	80003c68 <end_op>
    return -1;
    800050cc:	557d                	li	a0,-1
    800050ce:	bfcd                	j	800050c0 <sys_mkdir+0x38>

00000000800050d0 <sys_mknod>:

uint64
sys_mknod(void)
{
    800050d0:	7135                	addi	sp,sp,-160
    800050d2:	ed06                	sd	ra,152(sp)
    800050d4:	e922                	sd	s0,144(sp)
    800050d6:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800050d8:	b27fe0ef          	jal	80003bfe <begin_op>
  argint(1, &major);
    800050dc:	f6c40593          	addi	a1,s0,-148
    800050e0:	4505                	li	a0,1
    800050e2:	825fd0ef          	jal	80002906 <argint>
  argint(2, &minor);
    800050e6:	f6840593          	addi	a1,s0,-152
    800050ea:	4509                	li	a0,2
    800050ec:	81bfd0ef          	jal	80002906 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800050f0:	08000613          	li	a2,128
    800050f4:	f7040593          	addi	a1,s0,-144
    800050f8:	4501                	li	a0,0
    800050fa:	845fd0ef          	jal	8000293e <argstr>
    800050fe:	02054563          	bltz	a0,80005128 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80005102:	f6841683          	lh	a3,-152(s0)
    80005106:	f6c41603          	lh	a2,-148(s0)
    8000510a:	458d                	li	a1,3
    8000510c:	f7040513          	addi	a0,s0,-144
    80005110:	90fff0ef          	jal	80004a1e <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005114:	c911                	beqz	a0,80005128 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005116:	c5cfe0ef          	jal	80003572 <iunlockput>
  end_op();
    8000511a:	b4ffe0ef          	jal	80003c68 <end_op>
  return 0;
    8000511e:	4501                	li	a0,0
}
    80005120:	60ea                	ld	ra,152(sp)
    80005122:	644a                	ld	s0,144(sp)
    80005124:	610d                	addi	sp,sp,160
    80005126:	8082                	ret
    end_op();
    80005128:	b41fe0ef          	jal	80003c68 <end_op>
    return -1;
    8000512c:	557d                	li	a0,-1
    8000512e:	bfcd                	j	80005120 <sys_mknod+0x50>

0000000080005130 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005130:	7135                	addi	sp,sp,-160
    80005132:	ed06                	sd	ra,152(sp)
    80005134:	e922                	sd	s0,144(sp)
    80005136:	e14a                	sd	s2,128(sp)
    80005138:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    8000513a:	fa6fc0ef          	jal	800018e0 <myproc>
    8000513e:	892a                	mv	s2,a0
  
  begin_op();
    80005140:	abffe0ef          	jal	80003bfe <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005144:	08000613          	li	a2,128
    80005148:	f6040593          	addi	a1,s0,-160
    8000514c:	4501                	li	a0,0
    8000514e:	ff0fd0ef          	jal	8000293e <argstr>
    80005152:	04054363          	bltz	a0,80005198 <sys_chdir+0x68>
    80005156:	e526                	sd	s1,136(sp)
    80005158:	f6040513          	addi	a0,s0,-160
    8000515c:	8e7fe0ef          	jal	80003a42 <namei>
    80005160:	84aa                	mv	s1,a0
    80005162:	c915                	beqz	a0,80005196 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005164:	a04fe0ef          	jal	80003368 <ilock>
  if(ip->type != T_DIR){
    80005168:	04449703          	lh	a4,68(s1)
    8000516c:	4785                	li	a5,1
    8000516e:	02f71963          	bne	a4,a5,800051a0 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005172:	8526                	mv	a0,s1
    80005174:	aa2fe0ef          	jal	80003416 <iunlock>
  iput(p->cwd);
    80005178:	15093503          	ld	a0,336(s2)
    8000517c:	b6efe0ef          	jal	800034ea <iput>
  end_op();
    80005180:	ae9fe0ef          	jal	80003c68 <end_op>
  p->cwd = ip;
    80005184:	14993823          	sd	s1,336(s2)
  return 0;
    80005188:	4501                	li	a0,0
    8000518a:	64aa                	ld	s1,136(sp)
}
    8000518c:	60ea                	ld	ra,152(sp)
    8000518e:	644a                	ld	s0,144(sp)
    80005190:	690a                	ld	s2,128(sp)
    80005192:	610d                	addi	sp,sp,160
    80005194:	8082                	ret
    80005196:	64aa                	ld	s1,136(sp)
    end_op();
    80005198:	ad1fe0ef          	jal	80003c68 <end_op>
    return -1;
    8000519c:	557d                	li	a0,-1
    8000519e:	b7fd                	j	8000518c <sys_chdir+0x5c>
    iunlockput(ip);
    800051a0:	8526                	mv	a0,s1
    800051a2:	bd0fe0ef          	jal	80003572 <iunlockput>
    end_op();
    800051a6:	ac3fe0ef          	jal	80003c68 <end_op>
    return -1;
    800051aa:	557d                	li	a0,-1
    800051ac:	64aa                	ld	s1,136(sp)
    800051ae:	bff9                	j	8000518c <sys_chdir+0x5c>

00000000800051b0 <sys_exec>:

uint64
sys_exec(void)
{
    800051b0:	7121                	addi	sp,sp,-448
    800051b2:	ff06                	sd	ra,440(sp)
    800051b4:	fb22                	sd	s0,432(sp)
    800051b6:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800051b8:	e4840593          	addi	a1,s0,-440
    800051bc:	4505                	li	a0,1
    800051be:	f64fd0ef          	jal	80002922 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    800051c2:	08000613          	li	a2,128
    800051c6:	f5040593          	addi	a1,s0,-176
    800051ca:	4501                	li	a0,0
    800051cc:	f72fd0ef          	jal	8000293e <argstr>
    800051d0:	87aa                	mv	a5,a0
    return -1;
    800051d2:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    800051d4:	0c07c463          	bltz	a5,8000529c <sys_exec+0xec>
    800051d8:	f726                	sd	s1,424(sp)
    800051da:	f34a                	sd	s2,416(sp)
    800051dc:	ef4e                	sd	s3,408(sp)
    800051de:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    800051e0:	10000613          	li	a2,256
    800051e4:	4581                	li	a1,0
    800051e6:	e5040513          	addi	a0,s0,-432
    800051ea:	adffb0ef          	jal	80000cc8 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800051ee:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    800051f2:	89a6                	mv	s3,s1
    800051f4:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    800051f6:	02000a13          	li	s4,32
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800051fa:	00391513          	slli	a0,s2,0x3
    800051fe:	e4040593          	addi	a1,s0,-448
    80005202:	e4843783          	ld	a5,-440(s0)
    80005206:	953e                	add	a0,a0,a5
    80005208:	e74fd0ef          	jal	8000287c <fetchaddr>
    8000520c:	02054663          	bltz	a0,80005238 <sys_exec+0x88>
      goto bad;
    }
    if(uarg == 0){
    80005210:	e4043783          	ld	a5,-448(s0)
    80005214:	c3a9                	beqz	a5,80005256 <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005216:	90ffb0ef          	jal	80000b24 <kalloc>
    8000521a:	85aa                	mv	a1,a0
    8000521c:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005220:	cd01                	beqz	a0,80005238 <sys_exec+0x88>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005222:	6605                	lui	a2,0x1
    80005224:	e4043503          	ld	a0,-448(s0)
    80005228:	e9efd0ef          	jal	800028c6 <fetchstr>
    8000522c:	00054663          	bltz	a0,80005238 <sys_exec+0x88>
    if(i >= NELEM(argv)){
    80005230:	0905                	addi	s2,s2,1
    80005232:	09a1                	addi	s3,s3,8
    80005234:	fd4913e3          	bne	s2,s4,800051fa <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005238:	f5040913          	addi	s2,s0,-176
    8000523c:	6088                	ld	a0,0(s1)
    8000523e:	c931                	beqz	a0,80005292 <sys_exec+0xe2>
    kfree(argv[i]);
    80005240:	803fb0ef          	jal	80000a42 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005244:	04a1                	addi	s1,s1,8
    80005246:	ff249be3          	bne	s1,s2,8000523c <sys_exec+0x8c>
  return -1;
    8000524a:	557d                	li	a0,-1
    8000524c:	74ba                	ld	s1,424(sp)
    8000524e:	791a                	ld	s2,416(sp)
    80005250:	69fa                	ld	s3,408(sp)
    80005252:	6a5a                	ld	s4,400(sp)
    80005254:	a0a1                	j	8000529c <sys_exec+0xec>
      argv[i] = 0;
    80005256:	0009079b          	sext.w	a5,s2
    8000525a:	078e                	slli	a5,a5,0x3
    8000525c:	fd078793          	addi	a5,a5,-48
    80005260:	97a2                	add	a5,a5,s0
    80005262:	e807b023          	sd	zero,-384(a5)
  int ret = exec(path, argv);
    80005266:	e5040593          	addi	a1,s0,-432
    8000526a:	f5040513          	addi	a0,s0,-176
    8000526e:	ba8ff0ef          	jal	80004616 <exec>
    80005272:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005274:	f5040993          	addi	s3,s0,-176
    80005278:	6088                	ld	a0,0(s1)
    8000527a:	c511                	beqz	a0,80005286 <sys_exec+0xd6>
    kfree(argv[i]);
    8000527c:	fc6fb0ef          	jal	80000a42 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005280:	04a1                	addi	s1,s1,8
    80005282:	ff349be3          	bne	s1,s3,80005278 <sys_exec+0xc8>
  return ret;
    80005286:	854a                	mv	a0,s2
    80005288:	74ba                	ld	s1,424(sp)
    8000528a:	791a                	ld	s2,416(sp)
    8000528c:	69fa                	ld	s3,408(sp)
    8000528e:	6a5a                	ld	s4,400(sp)
    80005290:	a031                	j	8000529c <sys_exec+0xec>
  return -1;
    80005292:	557d                	li	a0,-1
    80005294:	74ba                	ld	s1,424(sp)
    80005296:	791a                	ld	s2,416(sp)
    80005298:	69fa                	ld	s3,408(sp)
    8000529a:	6a5a                	ld	s4,400(sp)
}
    8000529c:	70fa                	ld	ra,440(sp)
    8000529e:	745a                	ld	s0,432(sp)
    800052a0:	6139                	addi	sp,sp,448
    800052a2:	8082                	ret

00000000800052a4 <sys_pipe>:

uint64
sys_pipe(void)
{
    800052a4:	7139                	addi	sp,sp,-64
    800052a6:	fc06                	sd	ra,56(sp)
    800052a8:	f822                	sd	s0,48(sp)
    800052aa:	f426                	sd	s1,40(sp)
    800052ac:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800052ae:	e32fc0ef          	jal	800018e0 <myproc>
    800052b2:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800052b4:	fd840593          	addi	a1,s0,-40
    800052b8:	4501                	li	a0,0
    800052ba:	e68fd0ef          	jal	80002922 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    800052be:	fc840593          	addi	a1,s0,-56
    800052c2:	fd040513          	addi	a0,s0,-48
    800052c6:	85cff0ef          	jal	80004322 <pipealloc>
    return -1;
    800052ca:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800052cc:	0a054463          	bltz	a0,80005374 <sys_pipe+0xd0>
  fd0 = -1;
    800052d0:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800052d4:	fd043503          	ld	a0,-48(s0)
    800052d8:	f08ff0ef          	jal	800049e0 <fdalloc>
    800052dc:	fca42223          	sw	a0,-60(s0)
    800052e0:	08054163          	bltz	a0,80005362 <sys_pipe+0xbe>
    800052e4:	fc843503          	ld	a0,-56(s0)
    800052e8:	ef8ff0ef          	jal	800049e0 <fdalloc>
    800052ec:	fca42023          	sw	a0,-64(s0)
    800052f0:	06054063          	bltz	a0,80005350 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800052f4:	4691                	li	a3,4
    800052f6:	fc440613          	addi	a2,s0,-60
    800052fa:	fd843583          	ld	a1,-40(s0)
    800052fe:	68a8                	ld	a0,80(s1)
    80005300:	a52fc0ef          	jal	80001552 <copyout>
    80005304:	00054e63          	bltz	a0,80005320 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005308:	4691                	li	a3,4
    8000530a:	fc040613          	addi	a2,s0,-64
    8000530e:	fd843583          	ld	a1,-40(s0)
    80005312:	0591                	addi	a1,a1,4
    80005314:	68a8                	ld	a0,80(s1)
    80005316:	a3cfc0ef          	jal	80001552 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000531a:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000531c:	04055c63          	bgez	a0,80005374 <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    80005320:	fc442783          	lw	a5,-60(s0)
    80005324:	07e9                	addi	a5,a5,26
    80005326:	078e                	slli	a5,a5,0x3
    80005328:	97a6                	add	a5,a5,s1
    8000532a:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000532e:	fc042783          	lw	a5,-64(s0)
    80005332:	07e9                	addi	a5,a5,26
    80005334:	078e                	slli	a5,a5,0x3
    80005336:	94be                	add	s1,s1,a5
    80005338:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000533c:	fd043503          	ld	a0,-48(s0)
    80005340:	cd9fe0ef          	jal	80004018 <fileclose>
    fileclose(wf);
    80005344:	fc843503          	ld	a0,-56(s0)
    80005348:	cd1fe0ef          	jal	80004018 <fileclose>
    return -1;
    8000534c:	57fd                	li	a5,-1
    8000534e:	a01d                	j	80005374 <sys_pipe+0xd0>
    if(fd0 >= 0)
    80005350:	fc442783          	lw	a5,-60(s0)
    80005354:	0007c763          	bltz	a5,80005362 <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    80005358:	07e9                	addi	a5,a5,26
    8000535a:	078e                	slli	a5,a5,0x3
    8000535c:	97a6                	add	a5,a5,s1
    8000535e:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005362:	fd043503          	ld	a0,-48(s0)
    80005366:	cb3fe0ef          	jal	80004018 <fileclose>
    fileclose(wf);
    8000536a:	fc843503          	ld	a0,-56(s0)
    8000536e:	cabfe0ef          	jal	80004018 <fileclose>
    return -1;
    80005372:	57fd                	li	a5,-1
}
    80005374:	853e                	mv	a0,a5
    80005376:	70e2                	ld	ra,56(sp)
    80005378:	7442                	ld	s0,48(sp)
    8000537a:	74a2                	ld	s1,40(sp)
    8000537c:	6121                	addi	sp,sp,64
    8000537e:	8082                	ret

0000000080005380 <kernelvec>:
    80005380:	7111                	addi	sp,sp,-256
    80005382:	e006                	sd	ra,0(sp)
    80005384:	e40a                	sd	sp,8(sp)
    80005386:	e80e                	sd	gp,16(sp)
    80005388:	ec12                	sd	tp,24(sp)
    8000538a:	f016                	sd	t0,32(sp)
    8000538c:	f41a                	sd	t1,40(sp)
    8000538e:	f81e                	sd	t2,48(sp)
    80005390:	e4aa                	sd	a0,72(sp)
    80005392:	e8ae                	sd	a1,80(sp)
    80005394:	ecb2                	sd	a2,88(sp)
    80005396:	f0b6                	sd	a3,96(sp)
    80005398:	f4ba                	sd	a4,104(sp)
    8000539a:	f8be                	sd	a5,112(sp)
    8000539c:	fcc2                	sd	a6,120(sp)
    8000539e:	e146                	sd	a7,128(sp)
    800053a0:	edf2                	sd	t3,216(sp)
    800053a2:	f1f6                	sd	t4,224(sp)
    800053a4:	f5fa                	sd	t5,232(sp)
    800053a6:	f9fe                	sd	t6,240(sp)
    800053a8:	be4fd0ef          	jal	8000278c <kerneltrap>
    800053ac:	6082                	ld	ra,0(sp)
    800053ae:	6122                	ld	sp,8(sp)
    800053b0:	61c2                	ld	gp,16(sp)
    800053b2:	7282                	ld	t0,32(sp)
    800053b4:	7322                	ld	t1,40(sp)
    800053b6:	73c2                	ld	t2,48(sp)
    800053b8:	6526                	ld	a0,72(sp)
    800053ba:	65c6                	ld	a1,80(sp)
    800053bc:	6666                	ld	a2,88(sp)
    800053be:	7686                	ld	a3,96(sp)
    800053c0:	7726                	ld	a4,104(sp)
    800053c2:	77c6                	ld	a5,112(sp)
    800053c4:	7866                	ld	a6,120(sp)
    800053c6:	688a                	ld	a7,128(sp)
    800053c8:	6e6e                	ld	t3,216(sp)
    800053ca:	7e8e                	ld	t4,224(sp)
    800053cc:	7f2e                	ld	t5,232(sp)
    800053ce:	7fce                	ld	t6,240(sp)
    800053d0:	6111                	addi	sp,sp,256
    800053d2:	10200073          	sret
	...

00000000800053de <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800053de:	1141                	addi	sp,sp,-16
    800053e0:	e422                	sd	s0,8(sp)
    800053e2:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800053e4:	0c0007b7          	lui	a5,0xc000
    800053e8:	4705                	li	a4,1
    800053ea:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800053ec:	0c0007b7          	lui	a5,0xc000
    800053f0:	c3d8                	sw	a4,4(a5)
}
    800053f2:	6422                	ld	s0,8(sp)
    800053f4:	0141                	addi	sp,sp,16
    800053f6:	8082                	ret

00000000800053f8 <plicinithart>:

void
plicinithart(void)
{
    800053f8:	1141                	addi	sp,sp,-16
    800053fa:	e406                	sd	ra,8(sp)
    800053fc:	e022                	sd	s0,0(sp)
    800053fe:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005400:	cb4fc0ef          	jal	800018b4 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005404:	0085171b          	slliw	a4,a0,0x8
    80005408:	0c0027b7          	lui	a5,0xc002
    8000540c:	97ba                	add	a5,a5,a4
    8000540e:	40200713          	li	a4,1026
    80005412:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005416:	00d5151b          	slliw	a0,a0,0xd
    8000541a:	0c2017b7          	lui	a5,0xc201
    8000541e:	97aa                	add	a5,a5,a0
    80005420:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005424:	60a2                	ld	ra,8(sp)
    80005426:	6402                	ld	s0,0(sp)
    80005428:	0141                	addi	sp,sp,16
    8000542a:	8082                	ret

000000008000542c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000542c:	1141                	addi	sp,sp,-16
    8000542e:	e406                	sd	ra,8(sp)
    80005430:	e022                	sd	s0,0(sp)
    80005432:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005434:	c80fc0ef          	jal	800018b4 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005438:	00d5151b          	slliw	a0,a0,0xd
    8000543c:	0c2017b7          	lui	a5,0xc201
    80005440:	97aa                	add	a5,a5,a0
  return irq;
}
    80005442:	43c8                	lw	a0,4(a5)
    80005444:	60a2                	ld	ra,8(sp)
    80005446:	6402                	ld	s0,0(sp)
    80005448:	0141                	addi	sp,sp,16
    8000544a:	8082                	ret

000000008000544c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000544c:	1101                	addi	sp,sp,-32
    8000544e:	ec06                	sd	ra,24(sp)
    80005450:	e822                	sd	s0,16(sp)
    80005452:	e426                	sd	s1,8(sp)
    80005454:	1000                	addi	s0,sp,32
    80005456:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005458:	c5cfc0ef          	jal	800018b4 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    8000545c:	00d5151b          	slliw	a0,a0,0xd
    80005460:	0c2017b7          	lui	a5,0xc201
    80005464:	97aa                	add	a5,a5,a0
    80005466:	c3c4                	sw	s1,4(a5)
}
    80005468:	60e2                	ld	ra,24(sp)
    8000546a:	6442                	ld	s0,16(sp)
    8000546c:	64a2                	ld	s1,8(sp)
    8000546e:	6105                	addi	sp,sp,32
    80005470:	8082                	ret

0000000080005472 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005472:	1141                	addi	sp,sp,-16
    80005474:	e406                	sd	ra,8(sp)
    80005476:	e022                	sd	s0,0(sp)
    80005478:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000547a:	479d                	li	a5,7
    8000547c:	04a7ca63          	blt	a5,a0,800054d0 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005480:	0001e797          	auipc	a5,0x1e
    80005484:	4a078793          	addi	a5,a5,1184 # 80023920 <disk>
    80005488:	97aa                	add	a5,a5,a0
    8000548a:	0187c783          	lbu	a5,24(a5)
    8000548e:	e7b9                	bnez	a5,800054dc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005490:	00451693          	slli	a3,a0,0x4
    80005494:	0001e797          	auipc	a5,0x1e
    80005498:	48c78793          	addi	a5,a5,1164 # 80023920 <disk>
    8000549c:	6398                	ld	a4,0(a5)
    8000549e:	9736                	add	a4,a4,a3
    800054a0:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    800054a4:	6398                	ld	a4,0(a5)
    800054a6:	9736                	add	a4,a4,a3
    800054a8:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800054ac:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800054b0:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800054b4:	97aa                	add	a5,a5,a0
    800054b6:	4705                	li	a4,1
    800054b8:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    800054bc:	0001e517          	auipc	a0,0x1e
    800054c0:	47c50513          	addi	a0,a0,1148 # 80023938 <disk+0x18>
    800054c4:	aeffc0ef          	jal	80001fb2 <wakeup>
}
    800054c8:	60a2                	ld	ra,8(sp)
    800054ca:	6402                	ld	s0,0(sp)
    800054cc:	0141                	addi	sp,sp,16
    800054ce:	8082                	ret
    panic("free_desc 1");
    800054d0:	00002517          	auipc	a0,0x2
    800054d4:	1c050513          	addi	a0,a0,448 # 80007690 <etext+0x690>
    800054d8:	abcfb0ef          	jal	80000794 <panic>
    panic("free_desc 2");
    800054dc:	00002517          	auipc	a0,0x2
    800054e0:	1c450513          	addi	a0,a0,452 # 800076a0 <etext+0x6a0>
    800054e4:	ab0fb0ef          	jal	80000794 <panic>

00000000800054e8 <virtio_disk_init>:
{
    800054e8:	1101                	addi	sp,sp,-32
    800054ea:	ec06                	sd	ra,24(sp)
    800054ec:	e822                	sd	s0,16(sp)
    800054ee:	e426                	sd	s1,8(sp)
    800054f0:	e04a                	sd	s2,0(sp)
    800054f2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800054f4:	00002597          	auipc	a1,0x2
    800054f8:	1bc58593          	addi	a1,a1,444 # 800076b0 <etext+0x6b0>
    800054fc:	0001e517          	auipc	a0,0x1e
    80005500:	54c50513          	addi	a0,a0,1356 # 80023a48 <disk+0x128>
    80005504:	e70fb0ef          	jal	80000b74 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005508:	100017b7          	lui	a5,0x10001
    8000550c:	4398                	lw	a4,0(a5)
    8000550e:	2701                	sext.w	a4,a4
    80005510:	747277b7          	lui	a5,0x74727
    80005514:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005518:	18f71063          	bne	a4,a5,80005698 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000551c:	100017b7          	lui	a5,0x10001
    80005520:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    80005522:	439c                	lw	a5,0(a5)
    80005524:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005526:	4709                	li	a4,2
    80005528:	16e79863          	bne	a5,a4,80005698 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000552c:	100017b7          	lui	a5,0x10001
    80005530:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    80005532:	439c                	lw	a5,0(a5)
    80005534:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005536:	16e79163          	bne	a5,a4,80005698 <virtio_disk_init+0x1b0>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    8000553a:	100017b7          	lui	a5,0x10001
    8000553e:	47d8                	lw	a4,12(a5)
    80005540:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005542:	554d47b7          	lui	a5,0x554d4
    80005546:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    8000554a:	14f71763          	bne	a4,a5,80005698 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000554e:	100017b7          	lui	a5,0x10001
    80005552:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005556:	4705                	li	a4,1
    80005558:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000555a:	470d                	li	a4,3
    8000555c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000555e:	10001737          	lui	a4,0x10001
    80005562:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005564:	c7ffe737          	lui	a4,0xc7ffe
    80005568:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdacff>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000556c:	8ef9                	and	a3,a3,a4
    8000556e:	10001737          	lui	a4,0x10001
    80005572:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005574:	472d                	li	a4,11
    80005576:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005578:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    8000557c:	439c                	lw	a5,0(a5)
    8000557e:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005582:	8ba1                	andi	a5,a5,8
    80005584:	12078063          	beqz	a5,800056a4 <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005588:	100017b7          	lui	a5,0x10001
    8000558c:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005590:	100017b7          	lui	a5,0x10001
    80005594:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005598:	439c                	lw	a5,0(a5)
    8000559a:	2781                	sext.w	a5,a5
    8000559c:	10079a63          	bnez	a5,800056b0 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800055a0:	100017b7          	lui	a5,0x10001
    800055a4:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    800055a8:	439c                	lw	a5,0(a5)
    800055aa:	2781                	sext.w	a5,a5
  if(max == 0)
    800055ac:	10078863          	beqz	a5,800056bc <virtio_disk_init+0x1d4>
  if(max < NUM)
    800055b0:	471d                	li	a4,7
    800055b2:	10f77b63          	bgeu	a4,a5,800056c8 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    800055b6:	d6efb0ef          	jal	80000b24 <kalloc>
    800055ba:	0001e497          	auipc	s1,0x1e
    800055be:	36648493          	addi	s1,s1,870 # 80023920 <disk>
    800055c2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800055c4:	d60fb0ef          	jal	80000b24 <kalloc>
    800055c8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800055ca:	d5afb0ef          	jal	80000b24 <kalloc>
    800055ce:	87aa                	mv	a5,a0
    800055d0:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800055d2:	6088                	ld	a0,0(s1)
    800055d4:	10050063          	beqz	a0,800056d4 <virtio_disk_init+0x1ec>
    800055d8:	0001e717          	auipc	a4,0x1e
    800055dc:	35073703          	ld	a4,848(a4) # 80023928 <disk+0x8>
    800055e0:	0e070a63          	beqz	a4,800056d4 <virtio_disk_init+0x1ec>
    800055e4:	0e078863          	beqz	a5,800056d4 <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    800055e8:	6605                	lui	a2,0x1
    800055ea:	4581                	li	a1,0
    800055ec:	edcfb0ef          	jal	80000cc8 <memset>
  memset(disk.avail, 0, PGSIZE);
    800055f0:	0001e497          	auipc	s1,0x1e
    800055f4:	33048493          	addi	s1,s1,816 # 80023920 <disk>
    800055f8:	6605                	lui	a2,0x1
    800055fa:	4581                	li	a1,0
    800055fc:	6488                	ld	a0,8(s1)
    800055fe:	ecafb0ef          	jal	80000cc8 <memset>
  memset(disk.used, 0, PGSIZE);
    80005602:	6605                	lui	a2,0x1
    80005604:	4581                	li	a1,0
    80005606:	6888                	ld	a0,16(s1)
    80005608:	ec0fb0ef          	jal	80000cc8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    8000560c:	100017b7          	lui	a5,0x10001
    80005610:	4721                	li	a4,8
    80005612:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005614:	4098                	lw	a4,0(s1)
    80005616:	100017b7          	lui	a5,0x10001
    8000561a:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    8000561e:	40d8                	lw	a4,4(s1)
    80005620:	100017b7          	lui	a5,0x10001
    80005624:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005628:	649c                	ld	a5,8(s1)
    8000562a:	0007869b          	sext.w	a3,a5
    8000562e:	10001737          	lui	a4,0x10001
    80005632:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005636:	9781                	srai	a5,a5,0x20
    80005638:	10001737          	lui	a4,0x10001
    8000563c:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005640:	689c                	ld	a5,16(s1)
    80005642:	0007869b          	sext.w	a3,a5
    80005646:	10001737          	lui	a4,0x10001
    8000564a:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000564e:	9781                	srai	a5,a5,0x20
    80005650:	10001737          	lui	a4,0x10001
    80005654:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005658:	10001737          	lui	a4,0x10001
    8000565c:	4785                	li	a5,1
    8000565e:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005660:	00f48c23          	sb	a5,24(s1)
    80005664:	00f48ca3          	sb	a5,25(s1)
    80005668:	00f48d23          	sb	a5,26(s1)
    8000566c:	00f48da3          	sb	a5,27(s1)
    80005670:	00f48e23          	sb	a5,28(s1)
    80005674:	00f48ea3          	sb	a5,29(s1)
    80005678:	00f48f23          	sb	a5,30(s1)
    8000567c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005680:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005684:	100017b7          	lui	a5,0x10001
    80005688:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    8000568c:	60e2                	ld	ra,24(sp)
    8000568e:	6442                	ld	s0,16(sp)
    80005690:	64a2                	ld	s1,8(sp)
    80005692:	6902                	ld	s2,0(sp)
    80005694:	6105                	addi	sp,sp,32
    80005696:	8082                	ret
    panic("could not find virtio disk");
    80005698:	00002517          	auipc	a0,0x2
    8000569c:	02850513          	addi	a0,a0,40 # 800076c0 <etext+0x6c0>
    800056a0:	8f4fb0ef          	jal	80000794 <panic>
    panic("virtio disk FEATURES_OK unset");
    800056a4:	00002517          	auipc	a0,0x2
    800056a8:	03c50513          	addi	a0,a0,60 # 800076e0 <etext+0x6e0>
    800056ac:	8e8fb0ef          	jal	80000794 <panic>
    panic("virtio disk should not be ready");
    800056b0:	00002517          	auipc	a0,0x2
    800056b4:	05050513          	addi	a0,a0,80 # 80007700 <etext+0x700>
    800056b8:	8dcfb0ef          	jal	80000794 <panic>
    panic("virtio disk has no queue 0");
    800056bc:	00002517          	auipc	a0,0x2
    800056c0:	06450513          	addi	a0,a0,100 # 80007720 <etext+0x720>
    800056c4:	8d0fb0ef          	jal	80000794 <panic>
    panic("virtio disk max queue too short");
    800056c8:	00002517          	auipc	a0,0x2
    800056cc:	07850513          	addi	a0,a0,120 # 80007740 <etext+0x740>
    800056d0:	8c4fb0ef          	jal	80000794 <panic>
    panic("virtio disk kalloc");
    800056d4:	00002517          	auipc	a0,0x2
    800056d8:	08c50513          	addi	a0,a0,140 # 80007760 <etext+0x760>
    800056dc:	8b8fb0ef          	jal	80000794 <panic>

00000000800056e0 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800056e0:	7159                	addi	sp,sp,-112
    800056e2:	f486                	sd	ra,104(sp)
    800056e4:	f0a2                	sd	s0,96(sp)
    800056e6:	eca6                	sd	s1,88(sp)
    800056e8:	e8ca                	sd	s2,80(sp)
    800056ea:	e4ce                	sd	s3,72(sp)
    800056ec:	e0d2                	sd	s4,64(sp)
    800056ee:	fc56                	sd	s5,56(sp)
    800056f0:	f85a                	sd	s6,48(sp)
    800056f2:	f45e                	sd	s7,40(sp)
    800056f4:	f062                	sd	s8,32(sp)
    800056f6:	ec66                	sd	s9,24(sp)
    800056f8:	1880                	addi	s0,sp,112
    800056fa:	8a2a                	mv	s4,a0
    800056fc:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800056fe:	00c52c83          	lw	s9,12(a0)
    80005702:	001c9c9b          	slliw	s9,s9,0x1
    80005706:	1c82                	slli	s9,s9,0x20
    80005708:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    8000570c:	0001e517          	auipc	a0,0x1e
    80005710:	33c50513          	addi	a0,a0,828 # 80023a48 <disk+0x128>
    80005714:	ce0fb0ef          	jal	80000bf4 <acquire>
  for(int i = 0; i < 3; i++){
    80005718:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    8000571a:	44a1                	li	s1,8
      disk.free[i] = 0;
    8000571c:	0001eb17          	auipc	s6,0x1e
    80005720:	204b0b13          	addi	s6,s6,516 # 80023920 <disk>
  for(int i = 0; i < 3; i++){
    80005724:	4a8d                	li	s5,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005726:	0001ec17          	auipc	s8,0x1e
    8000572a:	322c0c13          	addi	s8,s8,802 # 80023a48 <disk+0x128>
    8000572e:	a8b9                	j	8000578c <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80005730:	00fb0733          	add	a4,s6,a5
    80005734:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005738:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    8000573a:	0207c563          	bltz	a5,80005764 <virtio_disk_rw+0x84>
  for(int i = 0; i < 3; i++){
    8000573e:	2905                	addiw	s2,s2,1
    80005740:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005742:	05590963          	beq	s2,s5,80005794 <virtio_disk_rw+0xb4>
    idx[i] = alloc_desc();
    80005746:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005748:	0001e717          	auipc	a4,0x1e
    8000574c:	1d870713          	addi	a4,a4,472 # 80023920 <disk>
    80005750:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005752:	01874683          	lbu	a3,24(a4)
    80005756:	fee9                	bnez	a3,80005730 <virtio_disk_rw+0x50>
  for(int i = 0; i < NUM; i++){
    80005758:	2785                	addiw	a5,a5,1
    8000575a:	0705                	addi	a4,a4,1
    8000575c:	fe979be3          	bne	a5,s1,80005752 <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005760:	57fd                	li	a5,-1
    80005762:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005764:	01205d63          	blez	s2,8000577e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005768:	f9042503          	lw	a0,-112(s0)
    8000576c:	d07ff0ef          	jal	80005472 <free_desc>
      for(int j = 0; j < i; j++)
    80005770:	4785                	li	a5,1
    80005772:	0127d663          	bge	a5,s2,8000577e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005776:	f9442503          	lw	a0,-108(s0)
    8000577a:	cf9ff0ef          	jal	80005472 <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000577e:	85e2                	mv	a1,s8
    80005780:	0001e517          	auipc	a0,0x1e
    80005784:	1b850513          	addi	a0,a0,440 # 80023938 <disk+0x18>
    80005788:	fdefc0ef          	jal	80001f66 <sleep>
  for(int i = 0; i < 3; i++){
    8000578c:	f9040613          	addi	a2,s0,-112
    80005790:	894e                	mv	s2,s3
    80005792:	bf55                	j	80005746 <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005794:	f9042503          	lw	a0,-112(s0)
    80005798:	00451693          	slli	a3,a0,0x4

  if(write)
    8000579c:	0001e797          	auipc	a5,0x1e
    800057a0:	18478793          	addi	a5,a5,388 # 80023920 <disk>
    800057a4:	00a50713          	addi	a4,a0,10
    800057a8:	0712                	slli	a4,a4,0x4
    800057aa:	973e                	add	a4,a4,a5
    800057ac:	01703633          	snez	a2,s7
    800057b0:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800057b2:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    800057b6:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800057ba:	6398                	ld	a4,0(a5)
    800057bc:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800057be:	0a868613          	addi	a2,a3,168
    800057c2:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    800057c4:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800057c6:	6390                	ld	a2,0(a5)
    800057c8:	00d605b3          	add	a1,a2,a3
    800057cc:	4741                	li	a4,16
    800057ce:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800057d0:	4805                	li	a6,1
    800057d2:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    800057d6:	f9442703          	lw	a4,-108(s0)
    800057da:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800057de:	0712                	slli	a4,a4,0x4
    800057e0:	963a                	add	a2,a2,a4
    800057e2:	058a0593          	addi	a1,s4,88
    800057e6:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    800057e8:	0007b883          	ld	a7,0(a5)
    800057ec:	9746                	add	a4,a4,a7
    800057ee:	40000613          	li	a2,1024
    800057f2:	c710                	sw	a2,8(a4)
  if(write)
    800057f4:	001bb613          	seqz	a2,s7
    800057f8:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800057fc:	00166613          	ori	a2,a2,1
    80005800:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005804:	f9842583          	lw	a1,-104(s0)
    80005808:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000580c:	00250613          	addi	a2,a0,2
    80005810:	0612                	slli	a2,a2,0x4
    80005812:	963e                	add	a2,a2,a5
    80005814:	577d                	li	a4,-1
    80005816:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000581a:	0592                	slli	a1,a1,0x4
    8000581c:	98ae                	add	a7,a7,a1
    8000581e:	03068713          	addi	a4,a3,48
    80005822:	973e                	add	a4,a4,a5
    80005824:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005828:	6398                	ld	a4,0(a5)
    8000582a:	972e                	add	a4,a4,a1
    8000582c:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005830:	4689                	li	a3,2
    80005832:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005836:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000583a:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    8000583e:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005842:	6794                	ld	a3,8(a5)
    80005844:	0026d703          	lhu	a4,2(a3)
    80005848:	8b1d                	andi	a4,a4,7
    8000584a:	0706                	slli	a4,a4,0x1
    8000584c:	96ba                	add	a3,a3,a4
    8000584e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005852:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005856:	6798                	ld	a4,8(a5)
    80005858:	00275783          	lhu	a5,2(a4)
    8000585c:	2785                	addiw	a5,a5,1
    8000585e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005862:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005866:	100017b7          	lui	a5,0x10001
    8000586a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    8000586e:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    80005872:	0001e917          	auipc	s2,0x1e
    80005876:	1d690913          	addi	s2,s2,470 # 80023a48 <disk+0x128>
  while(b->disk == 1) {
    8000587a:	4485                	li	s1,1
    8000587c:	01079a63          	bne	a5,a6,80005890 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005880:	85ca                	mv	a1,s2
    80005882:	8552                	mv	a0,s4
    80005884:	ee2fc0ef          	jal	80001f66 <sleep>
  while(b->disk == 1) {
    80005888:	004a2783          	lw	a5,4(s4)
    8000588c:	fe978ae3          	beq	a5,s1,80005880 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005890:	f9042903          	lw	s2,-112(s0)
    80005894:	00290713          	addi	a4,s2,2
    80005898:	0712                	slli	a4,a4,0x4
    8000589a:	0001e797          	auipc	a5,0x1e
    8000589e:	08678793          	addi	a5,a5,134 # 80023920 <disk>
    800058a2:	97ba                	add	a5,a5,a4
    800058a4:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800058a8:	0001e997          	auipc	s3,0x1e
    800058ac:	07898993          	addi	s3,s3,120 # 80023920 <disk>
    800058b0:	00491713          	slli	a4,s2,0x4
    800058b4:	0009b783          	ld	a5,0(s3)
    800058b8:	97ba                	add	a5,a5,a4
    800058ba:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800058be:	854a                	mv	a0,s2
    800058c0:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800058c4:	bafff0ef          	jal	80005472 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800058c8:	8885                	andi	s1,s1,1
    800058ca:	f0fd                	bnez	s1,800058b0 <virtio_disk_rw+0x1d0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800058cc:	0001e517          	auipc	a0,0x1e
    800058d0:	17c50513          	addi	a0,a0,380 # 80023a48 <disk+0x128>
    800058d4:	bb8fb0ef          	jal	80000c8c <release>
}
    800058d8:	70a6                	ld	ra,104(sp)
    800058da:	7406                	ld	s0,96(sp)
    800058dc:	64e6                	ld	s1,88(sp)
    800058de:	6946                	ld	s2,80(sp)
    800058e0:	69a6                	ld	s3,72(sp)
    800058e2:	6a06                	ld	s4,64(sp)
    800058e4:	7ae2                	ld	s5,56(sp)
    800058e6:	7b42                	ld	s6,48(sp)
    800058e8:	7ba2                	ld	s7,40(sp)
    800058ea:	7c02                	ld	s8,32(sp)
    800058ec:	6ce2                	ld	s9,24(sp)
    800058ee:	6165                	addi	sp,sp,112
    800058f0:	8082                	ret

00000000800058f2 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    800058f2:	1101                	addi	sp,sp,-32
    800058f4:	ec06                	sd	ra,24(sp)
    800058f6:	e822                	sd	s0,16(sp)
    800058f8:	e426                	sd	s1,8(sp)
    800058fa:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800058fc:	0001e497          	auipc	s1,0x1e
    80005900:	02448493          	addi	s1,s1,36 # 80023920 <disk>
    80005904:	0001e517          	auipc	a0,0x1e
    80005908:	14450513          	addi	a0,a0,324 # 80023a48 <disk+0x128>
    8000590c:	ae8fb0ef          	jal	80000bf4 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005910:	100017b7          	lui	a5,0x10001
    80005914:	53b8                	lw	a4,96(a5)
    80005916:	8b0d                	andi	a4,a4,3
    80005918:	100017b7          	lui	a5,0x10001
    8000591c:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    8000591e:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005922:	689c                	ld	a5,16(s1)
    80005924:	0204d703          	lhu	a4,32(s1)
    80005928:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    8000592c:	04f70663          	beq	a4,a5,80005978 <virtio_disk_intr+0x86>
    __sync_synchronize();
    80005930:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005934:	6898                	ld	a4,16(s1)
    80005936:	0204d783          	lhu	a5,32(s1)
    8000593a:	8b9d                	andi	a5,a5,7
    8000593c:	078e                	slli	a5,a5,0x3
    8000593e:	97ba                	add	a5,a5,a4
    80005940:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005942:	00278713          	addi	a4,a5,2
    80005946:	0712                	slli	a4,a4,0x4
    80005948:	9726                	add	a4,a4,s1
    8000594a:	01074703          	lbu	a4,16(a4)
    8000594e:	e321                	bnez	a4,8000598e <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005950:	0789                	addi	a5,a5,2
    80005952:	0792                	slli	a5,a5,0x4
    80005954:	97a6                	add	a5,a5,s1
    80005956:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005958:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000595c:	e56fc0ef          	jal	80001fb2 <wakeup>

    disk.used_idx += 1;
    80005960:	0204d783          	lhu	a5,32(s1)
    80005964:	2785                	addiw	a5,a5,1
    80005966:	17c2                	slli	a5,a5,0x30
    80005968:	93c1                	srli	a5,a5,0x30
    8000596a:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    8000596e:	6898                	ld	a4,16(s1)
    80005970:	00275703          	lhu	a4,2(a4)
    80005974:	faf71ee3          	bne	a4,a5,80005930 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005978:	0001e517          	auipc	a0,0x1e
    8000597c:	0d050513          	addi	a0,a0,208 # 80023a48 <disk+0x128>
    80005980:	b0cfb0ef          	jal	80000c8c <release>
}
    80005984:	60e2                	ld	ra,24(sp)
    80005986:	6442                	ld	s0,16(sp)
    80005988:	64a2                	ld	s1,8(sp)
    8000598a:	6105                	addi	sp,sp,32
    8000598c:	8082                	ret
      panic("virtio_disk_intr status");
    8000598e:	00002517          	auipc	a0,0x2
    80005992:	dea50513          	addi	a0,a0,-534 # 80007778 <etext+0x778>
    80005996:	dfffa0ef          	jal	80000794 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
